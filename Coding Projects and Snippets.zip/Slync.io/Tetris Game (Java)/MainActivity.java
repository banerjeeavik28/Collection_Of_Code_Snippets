package com.example.newtetris;

import android.app.Activity;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.View.*;
import android.view.Window;
import android.view.WindowManager;
import android.widget.*;

public class MainActivity extends Activity {
    public static int score;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        this.requestWindowFeature(Window.FEATURE_NO_TITLE);
        this.setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
        FrameLayout game = new FrameLayout(this);
        final GameView gameView = new GameView (this);
        LinearLayout Layout = new LinearLayout (this);
        final GameState gameState = new GameState(this);
        Button Left = new Button(this);
        Button Right = new Button(this);
        Button Down = new Button(this);
        Button Rotate = new Button(this);
        int generatedid = View.generateViewId();
        gameState.setId(generatedid);

        Left.setWidth(200);

        Left.setY(1600);
        Left.setX(55);
        Left.setText("Left");
        Right.setWidth(200);
        Right.setX(55);
        Right.setY(1600);
        Right.setText("Right");
        Down.setX(55);
        Down.setWidth(200);
        Down.setY(1600);
        Down.setText("Down");
        Rotate.setWidth(200);
        Rotate.setX(55);
        Rotate.setY(1600);
        Rotate.setText("Rotate");





        Layout.addView(Left);
        Layout.addView(Right);
        Layout.addView(Down);
        Layout.addView(Rotate);
        Layout.addView(gameState);
        game.addView(gameView);
        game.addView(Layout);
        gameState.setX(-125);
        gameState.setY(100);
        gameState.setText("SCORE:" + score);




        setContentView(game);

        Left.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                gameView.left = true;

            }
        });
        Right.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                gameView.right = true;

            }
        });
        Rotate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                gameView.rotate = true;

            }
        });

        Down.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                gameView.down = true;

            }
        });


        Thread scorethread = new Thread() {
            @Override
            public void run() {
                try{
                    while(!this.isInterrupted()) {
                        Thread.sleep(1000);
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                score++;
                                gameState.setText("SCORE:" + score);
                            }
                        });
                    }
                }catch (InterruptedException e){

                }
            }
        };

scorethread.start();

    }

//    public void onClick(View v) {
//
//        Intent intent = new Intent(this, MainActivity.class);
//        startActivity(intent);
//
//
//    }
}
