package com.example.newtetris;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Point;
import android.widget.Switch;
import java.lang.Math.*;

import java.util.LinkedList;
import java.util.List;
import java.util.Random;
import java.lang.Math.*;
public class Tetrimino {
    public static Bitmap image;
    public static Bitmap background;
    public static Bitmap background2;
    private static Bitmap[] tetrimino = new Bitmap[4];
    public static boolean[][]  board = new boolean[10][23];
    public static boolean gameend = false;
    public int x,y;
    private Random random = new Random();
    private int rand = random.nextInt();
    private boolean topofscreen = true;
    public int x1, x2, x3;
    public int y1, y2, y3;
    private tetriminotype type = tetriminotype.chooseTetrimino();
    private tetriminotype type1 = tetriminotype.Straight;
    private Paint paint = new Paint();
    public final static int canvasWidth = 500;
    public final static int canvasHeight = 1100;
    public int oldoverlayWidth;
    public int oldoverlayHeight;
    public Coordinates coordinates;
    private rotation rotationindex;
    public int pivotx, pivoty;

    private int check = 1;

    //interaction calls
    public boolean collided = false;
    public boolean rotate = false;
    public boolean left = false;
    public boolean right = false;
    public boolean down = false;
    public boolean isNext = false;
    public boolean shiftDown = false;
    public boolean pieceout = false;
    public boolean piece1out = false;
    public boolean piece2out = false;
    public boolean piece3out = false;

    private enum rotation {
        UP, DOWN, LEFT, RIGHT;

        private rotation rotateNinety() {
            switch(this) {
                case UP: return LEFT;
                case LEFT: return DOWN;
                case DOWN: return RIGHT;
                case RIGHT: return UP;
            }
            return null;
        }
        private static int calculateClockwiseX(int x, int y){
            return (0*x + 1*y);
        }
        private static int calculateClockwiseY(int x, int y){
            return (-1*x + 0*y);
        }
    }



    public static boolean[][] reinitboard(boolean[][] board){
        for (int i = 0; i < board.length; ++i) {
            for (int j = 0; j < board[i].length; ++j) {
                board[i][j] = false;
            }
        }
        return board;
    }

    public Tetrimino(Bitmap image, Bitmap background){
        this.background = background;
        this.image = image;
        this.x = 0;
        this.y = 0;
//        this.colorresult = chosenColor(this.colorchoice);
    }

    public Tetrimino(){

    }

    private boolean checkCollision(int x, int y){
        return board[x/(this.canvasWidth/10)][y/(this.canvasHeight/22)];
    }

    private boolean checkCollisionX(int x, int y, int extra){
        return board[(x+extra)/(this.canvasWidth/10)][(y+((this.canvasHeight/22)-1))/(this.canvasHeight/22)];
    }

    private boolean checkCollisionY(int x, int y, int extra){
        return board[x/(this.canvasWidth/10)][((y+extra) + ((this.canvasHeight/22)-1))/(this.canvasHeight/22)];
    }

    private enum tetriminotype{
        Straight,
        RightL,
        LeftL,
        Block,
        RightStep,
        LeftStep,
        MiddleStep;

        private static tetriminotype chooseTetrimino(){
            Random rand = new Random();
            tetriminotype randomtetrimino = values()[rand.nextInt((values().length))];
            return randomtetrimino; //returns random tetrimino
        }


    }





    public void draw(Canvas canvas){

        if(this.topofscreen == true) {
            this.background2 = background;
            this.background = Bitmap.createScaledBitmap(this.background, canvas.getWidth()-canvasWidth, canvas.getHeight(), true);
            this.background2 = Bitmap.createScaledBitmap(this.background2, canvas.getWidth(), canvas.getHeight()-canvasHeight, true);
            this.image = Bitmap.createScaledBitmap(this.image, canvasWidth / 10, canvasHeight / 22, true);
            this.x = canvasWidth/2;
            this.y = 0;
            switch (this.type){
                case Straight:
                    for (int i =0; i<4; i++) {
                        if(i == 0) {
                            tetrimino[i] = this.image;
                        }else
                        if(i == 1) {
                            tetrimino[i] = this.image;
                            y1 = this.y;
                            x1 = this.x +this.image.getWidth();

                        }else
                        if(i == 2) {
                            tetrimino[i] = this.image;
                            y2 = this.y;
                            x2 = x1 + this.image.getWidth();

                        }else
                        if(i == 3) {
                            tetrimino[i] = this.image;
                            y3 = this.y;
                            x3 = x2 + this.image.getWidth();
                        }

                    }
                    break;
                case RightL:
                    for (int i =0; i<4; i++) {
                        if(i == 0) {
                            tetrimino[i] = this.image;
                        }else
                        if(i == 1) {
                            tetrimino[i] = this.image;
                            y1 = this.y - this.image.getHeight();
                            x1 = this.x;
                        }else
                        if(i == 2) {
                            tetrimino[i] = this.image;
                            y2 = this.y;
                            x2 = this.x + this.image.getWidth();

                        }else
                        if(i == 3) {
                            tetrimino[i] = this.image;
                            y3 = this.y;
                            x3 = x2 + this.image.getWidth();
                        }

                    }
                    break;
                case LeftL:
                    for (int i =0; i<4; i++) {
                        if(i == 0) {
                            tetrimino[i] = this.image;
                        }else
                        if(i == 1) {
                            tetrimino[i] = this.image;
                            y1 = this.y - this.image.getHeight();
                            x1 = this.x;
                        }else
                        if(i == 2) {
                            tetrimino[i] = this.image;
                            y2 = this.y;
                            x2 = this.x - this.image.getWidth();

                        }else
                        if(i == 3) {
                            tetrimino[i] = this.image;
                            y3 = this.y;
                            x3 = x2 - this.image.getWidth();
                        }

                    }
                    break;
                case Block:
                    for (int i =0; i<4; i++) {
                        if(i == 0) {
                            tetrimino[i] = this.image;
                        }else
                        if(i == 1) {
                            tetrimino[i] = this.image;
                            y1 = this.y - this.image.getHeight();
                            x1 = this.x;
                        }else
                        if(i == 2) {
                            tetrimino[i] = this.image;
                            y2 = this.y;
                            x2 = this.x - this.image.getWidth();

                        }else
                        if(i == 3) {
                            tetrimino[i] = this.image;
                            y3 = this.y - this.image.getHeight();
                            x3 = this.x - this.image.getWidth();
                        }

                    }
                    break;
                case RightStep:
                    for (int i =0; i<4; i++) {
                        if(i == 0) {
                            tetrimino[i] = this.image;

                        }else
                        if(i == 1) {
                            tetrimino[i] = this.image;
                            y1 = this.y - this.image.getHeight();
                            x1 = this.x;
                        }else
                        if(i == 2) {
                            tetrimino[i] = this.image;
                            y2 = this.y - this.image.getHeight();
                            x2 = this.x + this.image.getWidth();
                        }else
                        if(i == 3) {
                            tetrimino[i] = this.image;
                            y3 = this.y;
                            x3 = this.x - this.image.getWidth();
                        }

                    }
                    break;
                case LeftStep:
                    for (int i =0; i<4; i++) {
                        if(i == 0) {
                            tetrimino[i] = this.image;

                        }else
                        if(i == 1) {
                            tetrimino[i] = this.image;
                            y1 = this.y - this.image.getHeight();
                            x1 = this.x;
                        }else
                        if(i == 2) {
                            tetrimino[i] = this.image;
                            y2 = this.y - this.image.getHeight();
                            x2 = this.x - this.image.getWidth();
                        }else
                        if(i == 3) {
                            tetrimino[i] = this.image;
                            y3 = this.y;
                            x3 = this.x + this.image.getWidth();
                        }

                    }
                    break;
                case MiddleStep:
                    for (int i =0; i<4; i++) {
                        if(i == 0) {
                            tetrimino[i] = this.image;

                        }else
                        if(i == 1) {
                            tetrimino[i] = this.image;
                            y1 = this.y - this.image.getHeight();
                            x1 = this.x;
                        }else
                        if(i == 2) {
                            tetrimino[i] = this.image;
                            y2 = this.y;
                            x2 = this.x - this.image.getWidth();
                        }else
                        if(i == 3) {
                            tetrimino[i] = this.image;
                            y3 = this.y;
                            x3 = this.x + this.image.getWidth();
                        }

                    }
                    break;
                    default:
                        x1 = x2 = x3 = y1 = y2 = y3 = 0;
            }

            topofscreen = false;
        }



        if (this.y >= canvasHeight-tetrimino[0].getHeight() ) {
            this.collided = true;

            int temp = this.y;
            if (!(pieceout == true)) {
                this.y = temp - (temp - (canvasHeight-tetrimino[0].getHeight()));
            }
            if (!(piece1out == true)) {
                this.y1 = this.y1 - (temp - (canvasHeight - tetrimino[1].getHeight()));
            }
            if (!(piece2out == true)) {
                this.y2 = this.y2 - (temp - (canvasHeight - tetrimino[2].getHeight()));
            }
            if (!(piece3out == true)) {
                this.y3 = this.y3 - (temp - (canvasHeight - tetrimino[3].getHeight()));
            }
        }else
        if (this.y1 >= canvasHeight-tetrimino[1].getHeight() ) {
            this.collided = true;
            int temp = this.y1;
            this.y = temp - (temp - (canvasHeight-tetrimino[0].getHeight()));
            this.y1 = this.y1 - (temp - (canvasHeight-tetrimino[1].getHeight()));
            this.y2 = this.y2 - (temp - (canvasHeight-tetrimino[2].getHeight()));
            this.y3 = this.y3 - (temp - (canvasHeight-tetrimino[3].getHeight()));
        }else
        if (this.y2 >= canvasHeight-tetrimino[2].getHeight() ) {
            this.collided = true;
            int temp = this.y2;
            this.y = temp - (temp - (canvasHeight-tetrimino[0].getHeight()));
            this.y1 = this.y1 - (temp - (canvasHeight-tetrimino[1].getHeight()));
            this.y2 = this.y2 - (temp - (canvasHeight-tetrimino[2].getHeight()));
            this.y3 = this.y3 - (temp - (canvasHeight-tetrimino[3].getHeight()));
        }else
        if (this.y3 >= canvasHeight-tetrimino[3].getHeight() && !shiftDown) {
            this.collided = true;
            int temp = this.y3;
            this.y = temp - (temp - (canvasHeight-tetrimino[0].getHeight()));
            this.y1 = this.y1 - (temp - (canvasHeight-tetrimino[1].getHeight()));
            this.y2 = this.y2 - (temp - (canvasHeight-tetrimino[2].getHeight()));
            this.y3 = this.y3 - (temp - (canvasHeight-tetrimino[3].getHeight()));
        }

        canvas.drawBitmap(background,canvasWidth,0,null);
        canvas.drawBitmap(background2, 0,canvasHeight,null);

        if(isNext == true){
            canvas.drawBitmap(tetrimino[0],x+canvasWidth+image.getWidth(),y+image.getHeight() +canvasHeight/2,null);
            canvas.drawBitmap(tetrimino[1],x1+canvasWidth+image.getWidth(),y1+image.getHeight()+canvasHeight/2,null);
            canvas.drawBitmap(tetrimino[2],x2+canvasWidth+image.getWidth(),y2+image.getHeight()+canvasHeight/2,null);
            canvas.drawBitmap(tetrimino[3],x3+canvasWidth+image.getWidth(),y3+image.getHeight()+canvasHeight/2,null);
        }else{
            if(shiftDown == true) {
                y = y+image.getHeight();
                y1 = y1+image.getHeight();
                y2 = y2+image.getHeight();
                y3 = y3+image.getHeight();
                shiftDown = false;
            }
        if (!(this.y > canvasHeight-tetrimino[0].getHeight() )) {
            canvas.drawBitmap(tetrimino[0], x, y, null);
        }else{
            pieceout = true;
        }
        if (!(this.y1 > canvasHeight-tetrimino[1].getHeight() )) {
            canvas.drawBitmap(tetrimino[1], x1, y1, null);
        }else {
            piece1out = true;
        }
        if (!(this.y2 > canvasHeight-tetrimino[2].getHeight() )) {
            canvas.drawBitmap(tetrimino[2], x2, y2, null);
        }else{
            piece2out = true;
        }
        if (!(this.y3 > canvasHeight-tetrimino[3].getHeight() )) {
            canvas.drawBitmap(tetrimino[3], x3, y3, null);
        }else{
            piece3out = true;
        }


        }

    }
    public void update(){



        if(this.collided == true){
            if(!pieceout) {
                board[x / (canvasWidth / 10)][(y + ((canvasHeight / 22) - 1)) / (canvasHeight / 22)] = true;
            }
            if(!piece1out) {
                board[x1 / (canvasWidth / 10)][(y1 + ((canvasHeight / 22) - 1)) / (canvasHeight / 22)] = true;
            }
            if(!piece2out) {
                board[x2 / (canvasWidth / 10)][(y2 + ((canvasHeight / 22) - 1)) / (canvasHeight / 22)] = true;
            }
            if(!piece3out) {
                board[x3 / (canvasWidth / 10)][(y3 + ((canvasHeight / 22) - 1)) / (canvasHeight / 22)] = true;
            }
            return;
        }else

        if(this.rotate == true){

            switch (this.type){
                case Straight:
                    pivotx = x1 ;
                    pivoty = y1 ;
                case RightL:
                    pivotx = x2 ;
                    pivoty = y2 ;
                case LeftL:
                    pivotx = x2;
                    pivoty = y2;
                case Block:
                    pivotx = x2;
                    pivoty = y2;
                case RightStep:
                    pivotx = x;
                    pivoty = y;
                case LeftStep:
                    pivotx =  (x);
                    pivoty = (y);
                case MiddleStep:
                    pivotx = x;
                    pivoty = y;
            }
            int tempx, tempx1, tempx2, tempx3, tempy, tempy1, tempy2, tempy3;
            int newx, newx1, newx2, newx3, newy, newy1, newy2, newy3;
            int globalx, globalx1, globalx2, globalx3, globaly, globaly1,globaly2,globaly3;
            int scalex = canvasWidth/10;
            int scaley = canvasHeight/22;
            globalx = x;
            globalx1 = x1;
            globalx2 = x2;
            globalx3 = x3;
            globaly = y;
            globaly1 = y1;
            globaly2 = y2;
            globaly3 = y3;
            tempx = ((x) -pivotx);
            tempx1 = ((x1) -pivotx);
            tempx2 = ((x2) -pivotx);
            tempx3 = ((x3) -pivotx);
            tempy = ((y) -pivoty);
            tempy1 = ((y1) -pivoty);
            tempy2 = ((y2) -pivoty);
            tempy3 = ((y3) -pivoty);
            newx = rotationindex.calculateClockwiseX(tempx,tempy);
            newx1 = rotationindex.calculateClockwiseX(tempx1,tempy1);
            newx2 = rotationindex.calculateClockwiseX(tempx2,tempy2);
            newx3 = rotationindex.calculateClockwiseX(tempx3,tempy3);
            newy = rotationindex.calculateClockwiseY(tempx,tempy);
            newy1 = rotationindex.calculateClockwiseY(tempx1,tempy1);
            newy2 = rotationindex.calculateClockwiseY(tempx2,tempy2);
            newy3 = rotationindex.calculateClockwiseY(tempx3,tempy3);
            x = (pivotx + newx);
            x1 = (pivotx+ newx1);
            x2 = (pivotx + newx2);
            x3 = (pivotx + newx3);
            y = (pivoty + newy);
            y1 = (pivoty + newy1);
            y2 = (pivoty + newy2);
            y3 = (pivoty + newy3);
            this.rotate = false;
        }else
        if(this.right == true){
            if (this.x >= canvasWidth -tetrimino[0].getWidth()) {
                this.right = false;
            }else
            if (this.x1 >= canvasWidth-tetrimino[1].getWidth()) {
                this.right = false;
            }else
            if (this.x2 >= canvasWidth-tetrimino[2].getWidth()) {
                this.right = false;
            }else
            if (this.x3 >= canvasWidth-tetrimino[3].getWidth()) {
                this.right = false;
            }else
            if (checkCollisionX(x,y, image.getWidth())) {
                this.left =false;
            }else
            if (checkCollisionX(x1,y1, image.getWidth())) {
                this.left =false;
            }else
            if (checkCollisionX(x2,y2, image.getWidth())) {
                this.left =false;
            }else
            if (checkCollisionX(x3,y3, image.getWidth())) {
                this.left =false;
            }else {


                this.x += image.getWidth();
                this.x1 += image.getWidth();
                this.x2 += image.getWidth();
                this.x3 += image.getWidth();
                this.right = false;
            }
        }else
        if(this.left == true){

            if (this.x <= 0) {
                this.left = false;
            }else
            if (this.x1 <= 0) {
                this.left = false;
            }else
            if (this.x2 <= 0) {
                this.left = false;
            }else
            if (this.x3 <= 0) {
                this.left = false;
            }else
                if (checkCollisionX(x,y, -image.getWidth())) {
                    this.left =false;
                }else
                if (checkCollisionX(x1,y1, -image.getWidth())) {
                    this.left =false;
                }else
                if (checkCollisionX(x2,y2, -image.getWidth())) {
                    this.left =false;
                }else
                if (checkCollisionX(x3,y3, -image.getWidth())) {
                    this.left =false;
                }else {
                this.x -= image.getWidth();
                this.x1 -= image.getWidth();
                this.x2 -= image.getWidth();
                this.x3 -= image.getWidth();
                this.left = false;
            }
        }else
        if(this.down == true){
            if (checkCollisionY(x,y, image.getHeight())) {
                this.down =false;
            }else
            if (checkCollisionY(x1,y1, image.getHeight())) {
                this.down =false;
            }else
            if (checkCollisionY(x2,y2, image.getHeight())) {
                this.down =false;
            }else
            if (checkCollisionY(x3,y3, image.getHeight())) {
                this.down =false;
            }else {
                this.y += image.getHeight();
                this.y1 += image.getHeight();
                this.y2 += image.getHeight();
                this.y3 += image.getHeight();
                this.down = false;
            }
        }
        if (checkCollisionY(x,y, 5)) {
            y = (y + ((this.canvasHeight/22)-1))/(this.canvasHeight/22)*(canvasHeight/22);
            y1 = (y1 + ((this.canvasHeight/22)-1))/(this.canvasHeight/22)*(canvasHeight/22);
            y2 = (y2 + ((this.canvasHeight/22)-1))/(this.canvasHeight/22)*(canvasHeight/22);
            y3 = (y3 + ((this.canvasHeight/22)-1))/(this.canvasHeight/22)*(canvasHeight/22);
            board[x/(canvasWidth/10)][(y+((canvasHeight/22)-1))/(canvasHeight/22)] = true;
            board[x1/(canvasWidth/10)][(y1+((canvasHeight/22)-1))/(canvasHeight/22)] = true;
            board[x2/(canvasWidth/10)][(y2+((canvasHeight/22)-1))/(canvasHeight/22)] = true;
            board[x3/(canvasWidth/10)][(y3+((canvasHeight/22)-1))/(canvasHeight/22)] = true;
            this.collided = true;
            if(y<image.getHeight() || y1< image.getHeight() || y2<image.getHeight() || y3<image.getHeight()){
                gameend = true;
            }
        }else
        if (checkCollisionY(x1,y1, 5)) {
            y = (y + ((this.canvasHeight/22)-1))/(this.canvasHeight/22)*(canvasHeight/22);
            y1 = (y1 + ((this.canvasHeight/22)-1))/(this.canvasHeight/22)*(canvasHeight/22);
            y2 = (y2 + ((this.canvasHeight/22)-1))/(this.canvasHeight/22)*(canvasHeight/22);
            y3 = (y3 + ((this.canvasHeight/22)-1))/(this.canvasHeight/22)*(canvasHeight/22);
            board[x/(canvasWidth/10)][(y+((canvasHeight/22)-1))/(canvasHeight/22)] = true;
            board[x1/(canvasWidth/10)][(y1+((canvasHeight/22)-1))/(canvasHeight/22)] = true;
            board[x2/(canvasWidth/10)][(y2+((canvasHeight/22)-1))/(canvasHeight/22)] = true;
            board[x3/(canvasWidth/10)][(y3+((canvasHeight/22)-1))/(canvasHeight/22)] = true;
            this.collided = true;
            if(y<image.getHeight() || y1< image.getHeight() || y2<image.getHeight() || y3<image.getHeight()){
                gameend = true;
            }
        }else
        if (checkCollisionY(x2,y2, 5)) {
            y = (y + ((this.canvasHeight/22)-1))/(this.canvasHeight/22)*(canvasHeight/22);
            y1 = (y1 + ((this.canvasHeight/22)-1))/(this.canvasHeight/22)*(canvasHeight/22);
            y2 = (y2 + ((this.canvasHeight/22)-1))/(this.canvasHeight/22)*(canvasHeight/22);
            y3 = (y3 + ((this.canvasHeight/22)-1))/(this.canvasHeight/22)*(canvasHeight/22);
            board[x/(canvasWidth/10)][(y+((canvasHeight/22)-1))/(canvasHeight/22)] = true;
            board[x1/(canvasWidth/10)][(y1+((canvasHeight/22)-1))/(canvasHeight/22)] = true;
            board[x2/(canvasWidth/10)][(y2+((canvasHeight/22)-1))/(canvasHeight/22)] = true;
            board[x3/(canvasWidth/10)][(y3+((canvasHeight/22)-1))/(canvasHeight/22)] = true;
            this.collided = true;
            if(y<image.getHeight() || y1< image.getHeight() || y2<image.getHeight() || y3<image.getHeight()){
                gameend = true;
            }
        }else
        if (checkCollisionY(x3,y3, 5)) {
            y = (y + ((this.canvasHeight/22)-1))/(this.canvasHeight/22)*(canvasHeight/22);
            y1 = (y1 + ((this.canvasHeight/22)-1))/(this.canvasHeight/22)*(canvasHeight/22);
            y2 = (y2 + ((this.canvasHeight/22)-1))/(this.canvasHeight/22)*(canvasHeight/22);
            y3 = (y3 + ((this.canvasHeight/22)-1))/(this.canvasHeight/22)*(canvasHeight/22);
            board[x/(canvasWidth/10)][(y+((canvasHeight/22)-1))/(canvasHeight/22)] = true;
            board[x1/(canvasWidth/10)][(y1+((canvasHeight/22)-1))/(canvasHeight/22)] = true;
            board[x2/(canvasWidth/10)][(y2+((canvasHeight/22)-1))/(canvasHeight/22)] = true;
            board[x3/(canvasWidth/10)][(y3+((canvasHeight/22)-1))/(canvasHeight/22)] = true;
            this.collided = true;
            if(y<image.getHeight() || y1< image.getHeight() || y2<image.getHeight() || y3<image.getHeight()){
                gameend = true;
            }
        }else {
            this.y += 5;
            this.y1 += 5;
            this.y2 += 5;
            this.y3 += 5;
        }

    }

    public void removeRow(){

    }
}
