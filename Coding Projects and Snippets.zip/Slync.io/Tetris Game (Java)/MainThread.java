package com.example.newtetris;

import android.graphics.Canvas;
import android.view.SurfaceHolder;

public class MainThread extends Thread implements Runnable {
    private SurfaceHolder holder;
    private GameView gameView;
    private boolean running;
    public static Canvas canvas;


    public MainThread(SurfaceHolder holder, GameView gameView){
        super();
        this.holder = holder;
        this.gameView = gameView;
    }

    public void setRunning(boolean isRunning){
        running = isRunning;
    }
    public void run() {
        while (running) {
            canvas = null;

            try {
                canvas = this.holder.lockCanvas();
                synchronized (holder) {
                    this.gameView.update();
                    this.gameView.draw(canvas);


                }
            } catch (Exception e) {
            } finally {
                if (canvas != null) {
                    try {
                        holder.unlockCanvasAndPost(canvas);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            }
        }
    }
}
