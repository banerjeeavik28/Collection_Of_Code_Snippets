package com.example.newtetris;

public class Coordinates {
    public static int[] coordx = new int[10];
    public static int[] coordy = new int[22];
    public int canvasWidth, canvasHeight;
    public static boolean[][] location;

    public Coordinates() {

    }



    public static boolean[][] initBoard(boolean[][] location){
        location = new boolean[coordx.length][coordy.length];
        for(int i=0;i<location.length; i++){
            for(int j=0; j<location[i].length; j++){
                location[i][j]= false;
            }

        }
        return location;
    }
    public boolean checkCollision(int x, int y){
        boolean result = false;
        return result;
    }



//    public int getX() {
//        return x;
//    }
//
//    public void setX(int x) {
//        this.x = x;
//    }
//
//
//
//    public int getY() {
//        return y;
//    }
//
//    public void setY(int y) {
//        this.y = y;
//    }

}
