package com.example.newtetris;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.view.SurfaceView;
import android.view.SurfaceHolder;

import java.util.ArrayList;
import java.util.Random;
import java.lang.Runnable;

public class GameView extends SurfaceView implements SurfaceHolder.Callback {
    private MainThread mainThread;
    public ArrayList<Tetrimino> tetrimino = new ArrayList<>();
    public Coordinates board;
    public GameState gameState;
    public boolean rotate = false;
    public boolean left = false;
    public boolean right = false;
    public boolean down = false;
    public int incremnttetremino = 0;
    public int canvasWidth;
    public int canvasHeight;
    private int z;
    public boolean shiftdown;
    public int score;
    private boolean[] rowtobechanged = new boolean[22];
    private boolean firstdraw = true;
    public GameView(Context context) {
        super(context);
        getHolder().addCallback(this);

        mainThread = new MainThread(getHolder(), this);
        setFocusable(true);
    }

    private enum TColor {
        Red,
        Blue,
        Green,
        Yellow;

        private static TColor chooseColor() {
            Random rand = new Random();
            TColor randomcolor = values()[rand.nextInt((values().length))];
            return randomcolor; //returns random color
        }
    }

    private static int chosenColor(TColor color) {
        int result = 0;
        switch (color) {
            case Red:
                result = R.drawable.red;
                break;
            case Blue:
                result = R.drawable.blue;
                break;
            case Green:
                result = R.drawable.green;
                break;
            case Yellow:
                result = R.drawable.yellow;
                break;
            default:
                result = 0;
        }
        return result;
    }


    @Override
    public void surfaceChanged(SurfaceHolder holder, int format, int width, int height) {

    }

    @Override
    public void surfaceCreated(SurfaceHolder holder) {
        score = 0;

        board.location = Coordinates.initBoard(board.location);

        tetrimino.add(new Tetrimino(BitmapFactory.decodeResource(getResources(), chosenColor(TColor.chooseColor())),BitmapFactory.decodeResource(getResources(), R.drawable.grey)));
//        for (int i = 0; i<board.coordx.length; i++) {
//            board.coordx[i] = i*(tetrimino.get(0).canvasWidth/board.coordx.length);
//            int x = board.coordx[i];
//        }
//        for(int j = 0; j<board.coordy.length; j++) {
//            board.coordy[j] = j*(tetrimino.get(0).canvasHeight/board.coordy.length);
//        }
        tetrimino.add(new Tetrimino(BitmapFactory.decodeResource(getResources(), chosenColor(TColor.chooseColor())),BitmapFactory.decodeResource(getResources(), R.drawable.grey)));
        tetrimino.get(tetrimino.size()-1).isNext = true;
        mainThread.setRunning(true);
        mainThread.start();
    }

    @Override
    public void surfaceDestroyed(SurfaceHolder holder) {
        boolean retry = true;
        while (retry) {
            try {
                mainThread.setRunning(false);
                mainThread.join();
            } catch (InterruptedException e) { // if thread interrupted by another thread it will retry the loop
                e.printStackTrace();
            }
            retry = false;
        }
    }

    public void update() {
        z = 0;
        if (this.down == true) {
            tetrimino.get(this.incremnttetremino).down = true;
            this.down = false;
        }
        if (this.left == true) {
            tetrimino.get(this.incremnttetremino).left = true;
            this.left = false;
        }
        if (this.right == true) {
            tetrimino.get(this.incremnttetremino).right = true;
            this.right = false;
        }
        if (this.rotate == true) {
            tetrimino.get(this.incremnttetremino).rotate = true;
            this.rotate = false;
        }

//        for(int i=0; i<incremnttetremino; i++) {
//            tetrimino.get(i).update();
//        }

        tetrimino.get(incremnttetremino).update();

//            if(tetrimino.get(incremnttetremino).gameend){
//                mainThread.interrupt();
//            }
//        if (tetrimino.get(incremnttetremino-1).collided == true) {
//            for (int i = 0; i < 10; i++) {
//                if (tetrimino.get(incremnttetremino).board[i][22] == true) {
//                    z++;
//                }
//            }
//            if (z == 9) {
//                shiftdown = true;
//            }
//        }
    }

    @Override
    public void draw(Canvas canvas) {
        super.draw(canvas);
        if (canvas != null) {
            if (!(tetrimino.get(incremnttetremino).gameend)){
            score++;
            tetrimino.get(tetrimino.size() - 1).isNext = true;
//            canvas.drawColor(Color.WHITE);
//            Paint paint = new Paint();
//            paint.setColor(Color.rgb(250, 0, 0));
//            canvas.drawRect(100, 100, 200, 200, paint);
            canvasWidth = canvas.getWidth();
            canvasHeight = canvas.getHeight();
            canvas.drawColor(Color.WHITE);
            if(shiftdown){
                tetrimino.get(incremnttetremino).reinitboard(tetrimino.get(incremnttetremino).board);
            }

                if (tetrimino.get(incremnttetremino).collided == true) {

//                for(int i =0; i<board.coordy.length; i++){
//
//                    z = 0;
//                    for(int j =0; j<board.coordx.length; j++){
//                        if(board.location[i][j] == true){
//                            z++;
//                        }
//                        if(z == 10){
//                            rowtobechanged[i]= true;
//                        }
//                    }
//                }
//                for(int i=0; i<rowtobechanged.length; i++) {
//                    for (int j = 0; j < tetrimino.size() - 2; j++) {
//                        if (rowtobechanged[i] == true) {
//                            tetrimino.get(j).shiftDown = true;
//
//                        }
//                        tetrimino.get(j).draw(canvas);
//                    }
//                }
                    this.incremnttetremino++;
                    tetrimino.get(tetrimino.size() - 1).isNext = false;
                    tetrimino.add(new Tetrimino(BitmapFactory.decodeResource(getResources(), chosenColor(TColor.chooseColor())), BitmapFactory.decodeResource(getResources(), R.drawable.grey)));
                }
            for (int i = 0; i < tetrimino.size() - 1; i++) {
                if(shiftdown == true){
                    if(i!=tetrimino.size()-1) {
                        tetrimino.get(i).shiftDown = true;
//                        tetrimino.get(i).y += tetrimino.get(i).image.getHeight();
//                        tetrimino.get(i).y1 += tetrimino.get(i).image.getHeight();
//                        tetrimino.get(i).y2 += tetrimino.get(i).image.getHeight();
//                        tetrimino.get(i).y3 += tetrimino.get(i).image.getHeight();

                    }
                }
                tetrimino.get(i).draw(canvas);
                if (tetrimino.get(tetrimino.size() - 1).isNext == true) {
                    tetrimino.get(tetrimino.size() - 1);
                    tetrimino.get(tetrimino.size() - 1).draw(canvas);
                }


            }
            shiftdown = false;
        }

        }
    }


}
