package com.example.newtetris;


import android.content.Context;
import android.support.v7.widget.AppCompatTextView;



public class GameState extends AppCompatTextView {
    public static int score = 0;
    GameState(Context context){
        super(context);

    }


}
