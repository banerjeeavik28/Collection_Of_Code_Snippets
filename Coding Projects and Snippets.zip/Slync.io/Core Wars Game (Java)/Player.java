package com.company;

public class Player {
    int  pc = 0;
    boolean status = true;
}
