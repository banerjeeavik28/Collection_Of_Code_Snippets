package com.company;

public class Board {
    Instructions[] inst = new Instructions[8000];
    public Instructions[] createBoard(Instructions[] inst){
        for(int i = 0; i<inst.length; i++){
            inst[i] = new Instructions();
        }
        return inst;
    }
}
