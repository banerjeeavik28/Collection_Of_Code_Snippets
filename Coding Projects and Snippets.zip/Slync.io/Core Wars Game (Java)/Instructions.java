package com.company;

public class Instructions {
    String fullinst = "DAT 0";
    String inst = "DAT";
    String a = "0";
    String b = "0";
    char a2 = 'd';
    char b2 = 'd';
    char a3 = 'd';
    char b3 = 'd';



    public int chooseInstruction(String fullinst, String instr, Board board, int pc, String a, String b, char a2, char b2, char a3, char b3){
        switch(instr) {
            case "DAT":
                board.inst[pc].a = "0";
                return pc;
            case "MOV":
                MOV(fullinst,instr, board, pc, a2, a3, a, b2, b3, b);
                return checkCircular(pc+1);
            case "ADD":
                ADD(fullinst,instr, board, pc, a2, a3, a, b2, b3, b);
                return checkCircular(pc+1);
            case "SUB":
                SUB(fullinst,instr, board, pc, a2, a3, a, b2, b3, b);
                return checkCircular(pc+1);
            case "JMP":
                board.inst[pc].b = "0";
                pc = JMP(fullinst,instr,board,pc,a2,a3,a);
                return pc;
            case "JMZ":
                pc = JMZ(fullinst,instr, board, pc, a2, a3, a, b2, b3, b);
                return pc;
            case "DJN":
                pc = DJN(fullinst,instr, board, pc, a2, a3, a, b2, b3, b);
                return pc;
            case "CMP":
                pc = CMP(fullinst,instr, board, pc, a2, a3, a, b2, b3, b);
                return pc;
            case "SPL":
                board.inst[pc].b = "0";
                pc = SPL(fullinst,instr, board, pc, a2, a3, a);
                return pc;
            default:
                return pc;
        }
    }


////////////////////////////////////////////////////////////////////////////////////////////////

    public void MOV(String fullinst, String inst, Board board, int pc, char a2, char a3, String a, char b2, char b3, String b) {
        if((a2 == '#' || a2 == '*' || a2 == 'd') && (b2 == 'd' || b2 == '@') && (a3 == '-' || a3 == 'd') && (b3 == '-' || b3 == 'd')) {
            String result =  " ";
            // a3 = d and b3 = d
            if(a2 == '#' && b2 == 'd' && a3 == 'd' && b3 == 'd'){
                int c = Integer.parseInt(b);

                board.inst[checkCircular(pc+c)].b= board.inst[pc].a;
                int f = checkCircular(pc+c);
                result = changeValues(board.inst[f].fullinst, board.inst[f].inst, board, f, board.inst[f].a2, board.inst[f].a3, board.inst[f].a, board.inst[f].b2, board.inst[f].b3, board.inst[f].b);
            }
            if(a2 == '#' && b2 == '@' && a3 == 'd' && b3 == 'd'){
                int c = Integer.parseInt(b);

                String e = board.inst[checkCircular(pc+c)].b;
                int g = Integer.parseInt(e);
                if (board.inst[checkCircular(pc+c)].b3 == '-'){
                    g = -g;
                }
                board.inst[checkCircular(pc+c+g)].b = board.inst[pc].a;
                int f = checkCircular(pc+c+g);
                result = changeValues(board.inst[f].fullinst, board.inst[f].inst, board, f, board.inst[f].a2, board.inst[f].a3, board.inst[f].a, board.inst[f].b2, board.inst[f].b3, board.inst[f].b);
            }
            if(a2 == '*' && b2 == 'd' && a3 == 'd' && b3 == 'd'){
                int c = Integer.parseInt(b);

                String e = board.inst[checkCircular(pc+c)].b;
                int f = checkCircular(pc+c);

                int c1 = Integer.parseInt(a);

                String e1 = board.inst[checkCircular(pc+c1)].a;
                int g1 = Integer.parseInt(e1);
                if (board.inst[checkCircular(pc+c1)].a3 == '-'){
                    g1 = -g1;
                }
                int f1 = checkCircular(pc+c1+g1);

                board.inst[f].fullinst = board.inst[f1].fullinst;

                board.inst[f].inst = board.inst[f1].inst;
                board.inst[f].a2 = board.inst[f1].a2;
                board.inst[f].a3 = board.inst[f1].a3;
                board.inst[f].a = board.inst[f1].a;
                board.inst[f].b2 = board.inst[f1].b2;
                board.inst[f].b3 = board.inst[f1].b3;
                board.inst[f].b = board.inst[f1].b;
                result = changeValues(board.inst[f].fullinst, board.inst[f].inst, board, f, board.inst[f].a2, board.inst[f].a3, board.inst[f].a, board.inst[f].b2, board.inst[f].b3, board.inst[f].b);

            }
            if(a2 == '*' && b2 == '@' && a3 == 'd' && b3 == 'd'){
                int c = Integer.parseInt(b);

                String e = board.inst[checkCircular(pc+c)].b;
                int g = Integer.parseInt(e);
                if (board.inst[checkCircular(pc+c)].b3 == '-'){
                    g = -g;
                }
                int f = checkCircular(pc+c+g);

                int c1 = Integer.parseInt(a);

                String e1 = board.inst[checkCircular(pc+c1)].a;
                int g1 = Integer.parseInt(e1);
                if (board.inst[checkCircular(pc+c1)].a3 == '-'){
                    g1 = -g1;
                }
                int f1 = checkCircular(pc+c1+g1);

                board.inst[f].fullinst = board.inst[f1].fullinst;
                board.inst[f].inst = board.inst[f1].inst;
                board.inst[f].a2 = board.inst[f1].a2;
                board.inst[f].a3 = board.inst[f1].a3;
                board.inst[f].a = board.inst[f1].a;
                board.inst[f].b2 = board.inst[f1].b2;
                board.inst[f].b3 = board.inst[f1].b3;
                board.inst[f].b = board.inst[f1].b;
                result = changeValues(board.inst[f].fullinst, board.inst[f].inst, board, f, board.inst[f].a2, board.inst[f].a3, board.inst[f].a, board.inst[f].b2, board.inst[f].b3, board.inst[f].b);

            }
            if(a2 == 'd' && b2 == 'd' && a3 == 'd' && b3 == 'd'){
                int c = Integer.parseInt(b);
                String e = board.inst[checkCircular(pc+c)].b;
                int f = checkCircular(pc+c);

                int c1 = Integer.parseInt(a);

                String e1 = board.inst[checkCircular(pc+c1)].a;
                int f1 = checkCircular(pc+c1);
                board.inst[f].fullinst = board.inst[f1].fullinst;
                board.inst[f].inst = board.inst[f1].inst;
                board.inst[f].a2 = board.inst[f1].a2;
                board.inst[f].a3 = board.inst[f1].a3;
                board.inst[f].a = board.inst[f1].a;
                board.inst[f].b2 = board.inst[f1].b2;
                board.inst[f].b3 = board.inst[f1].b3;
                board.inst[f].b = board.inst[f1].b;
                result = changeValues(board.inst[f].fullinst, board.inst[f].inst, board, f, board.inst[f].a2, board.inst[f].a3, board.inst[f].a, board.inst[f].b2, board.inst[f].b3, board.inst[f].b);

            }
            if(a2 == 'd' && b2 == '@' && a3 == 'd' && b3 == 'd'){
                int c = Integer.parseInt(b);

                String e = board.inst[checkCircular(pc+c)].b;
                int g = Integer.parseInt(e);
                if (board.inst[checkCircular(pc+c)].b3 == '-'){
                    g = -g;
                }
                int f = checkCircular(pc+c+g);

                int c1 = Integer.parseInt(a);

                String e1 = board.inst[checkCircular(pc+c1)].a;
                int f1 = checkCircular(pc+c1);

                board.inst[f].fullinst = board.inst[f1].fullinst;
                board.inst[f].inst = board.inst[f1].inst;
                board.inst[f].a2 = board.inst[f1].a2;
                board.inst[f].a3 = board.inst[f1].a3;
                board.inst[f].a = board.inst[f1].a;
                board.inst[f].b2 = board.inst[f1].b2;
                board.inst[f].b3 = board.inst[f1].b3;
                board.inst[f].b = board.inst[f1].b;
                result = changeValues(board.inst[f].fullinst, board.inst[f].inst, board, f, board.inst[f].a2, board.inst[f].a3, board.inst[f].a, board.inst[f].b2, board.inst[f].b3, board.inst[f].b);

            }

            // a3 = - and b3 = d
            if(a2 == '#' && b2 == 'd' && a3 == '-' && b3 == 'd'){
                int c = Integer.parseInt(b);
                board.inst[checkCircular(pc+c)].b= board.inst[pc].a;
                board.inst[checkCircular(pc+c)].b3 = a3;
                result = changeValues(board.inst[checkCircular(pc+c)].fullinst, board.inst[checkCircular(pc+c)].inst, board, checkCircular(pc+c), board.inst[checkCircular(pc+c)].a2, board.inst[checkCircular(pc+c)].a3, board.inst[checkCircular(pc+c)].a, board.inst[checkCircular(pc+c)].b2, board.inst[checkCircular(pc+c)].b3, board.inst[checkCircular(pc+c)].b);
            }
            if(a2 == '#' && b2 == '@' && a3 == '-' && b3 == 'd'){
                int c = Integer.parseInt(b);

                String e = board.inst[checkCircular(pc+c)].b;
                int g = Integer.parseInt(e);
                if (board.inst[checkCircular(pc+c)].b3 == '-'){
                    g = -g;
                }
                board.inst[checkCircular(pc+c+g)].b = board.inst[pc].a;
                int f = checkCircular(pc+c+g);
                board.inst[f].b3 = a3;
                result = changeValues(board.inst[f].fullinst, board.inst[f].inst, board, f, board.inst[f].a2, board.inst[f].a3, board.inst[f].a, board.inst[f].b2, board.inst[f].b3, board.inst[f].b);
            }
            if(a2 == '*' && b2 == 'd' && a3 == '-' && b3 == 'd'){
                int c = Integer.parseInt(b);

                String e = board.inst[checkCircular(pc+c)].b;
                int f = checkCircular(pc+c);

                int c1 = Integer.parseInt(a);
                if (board.inst[pc].a3 == '-'){
                    c1 = -c1;
                }
                String e1 = board.inst[checkCircular(pc+c1)].a;
                int g1 = Integer.parseInt(e1);
                if (board.inst[checkCircular(pc+c1)].a3 == '-'){
                    g1 = -g1;
                }
                int f1 = checkCircular(pc+c1+g1);

                board.inst[f].fullinst = board.inst[f1].fullinst;
                board.inst[f].inst = board.inst[f1].inst;
                board.inst[f].a2 = board.inst[f1].a2;
                board.inst[f].a3 = board.inst[f1].a3;
                board.inst[f].a = board.inst[f1].a;
                board.inst[f].b2 = board.inst[f1].b2;
                board.inst[f].b3 = board.inst[f1].b3;
                board.inst[f].b = board.inst[f1].b;
                result = changeValues(board.inst[f].fullinst, board.inst[f].inst, board, f, board.inst[f].a2, board.inst[f].a3, board.inst[f].a, board.inst[f].b2, board.inst[f].b3, board.inst[f].b);

            }
            if(a2 == '*' && b2 == '@' && a3 == '-' && b3 == 'd'){
                int c = Integer.parseInt(b);

                String e = board.inst[checkCircular(pc+c)].b;
                int g = Integer.parseInt(e);
                if (board.inst[checkCircular(pc+c)].b3 == '-'){
                    g = -g;
                }
                int f = checkCircular(pc+c+g);

                int c1 = Integer.parseInt(a);
                if (board.inst[pc].a3 == '-'){
                    c1 = -c1;
                }
                String e1 = board.inst[checkCircular(pc+c1)].a;
                int g1 = Integer.parseInt(e1);
                if (board.inst[checkCircular(pc+c1)].a3 == '-'){
                    g1 = -g1;
                }
                int f1 = checkCircular(pc+c1+g1);

                board.inst[f].fullinst = board.inst[f1].fullinst;
                board.inst[f].inst = board.inst[f1].inst;
                board.inst[f].a2 = board.inst[f1].a2;
                board.inst[f].a3 = board.inst[f1].a3;
                board.inst[f].a = board.inst[f1].a;
                board.inst[f].b2 = board.inst[f1].b2;
                board.inst[f].b3 = board.inst[f1].b3;
                board.inst[f].b = board.inst[f1].b;
                result = changeValues(board.inst[f].fullinst, board.inst[f].inst, board, f, board.inst[f].a2, board.inst[f].a3, board.inst[f].a, board.inst[f].b2, board.inst[f].b3, board.inst[f].b);

            }
            if(a2 == 'd' && b2 == 'd' && a3 == '-' && b3 == 'd'){
                int c = Integer.parseInt(b);

                String e = board.inst[checkCircular(pc+c)].b;
                int f = checkCircular(pc+c);

                int c1 = Integer.parseInt(a);
                if (board.inst[pc].a3 == '-'){
                    c1 = -c1;
                }

                String e1 = board.inst[checkCircular(pc+c1)].a;
                int f1 = checkCircular(pc+c1);

                board.inst[f].fullinst = board.inst[f1].fullinst;
                board.inst[f].inst = board.inst[f1].inst;
                board.inst[f].a2 = board.inst[f1].a2;
                board.inst[f].a3 = board.inst[f1].a3;
                board.inst[f].a = board.inst[f1].a;
                board.inst[f].b2 = board.inst[f1].b2;
                board.inst[f].b3 = board.inst[f1].b3;
                board.inst[f].b = board.inst[f1].b;
                result = changeValues(board.inst[f].fullinst, board.inst[f].inst, board, f, board.inst[f].a2, board.inst[f].a3, board.inst[f].a, board.inst[f].b2, board.inst[f].b3, board.inst[f].b);

            }
            if(a2 == 'd' && b2 == '@' && a3 == '-' && b3 == 'd'){
                int c = Integer.parseInt(b);

                String e = board.inst[checkCircular(pc+c)].b;
                int g = Integer.parseInt(e);
                if (board.inst[checkCircular(pc+c)].b3 == '-'){
                    g = -g;
                }
                int f = checkCircular(pc+c+g);

                int c1 = Integer.parseInt(a);
                if (board.inst[pc].a3 == '-'){
                    c1 = -c1;
                }
                String e1 = board.inst[checkCircular(pc+c1)].a;
                int f1 = checkCircular(pc+c1);

                board.inst[f].fullinst = board.inst[f1].fullinst;
                board.inst[f].inst = board.inst[f1].inst;
                board.inst[f].a2 = board.inst[f1].a2;
                board.inst[f].a3 = board.inst[f1].a3;
                board.inst[f].a = board.inst[f1].a;
                board.inst[f].b2 = board.inst[f1].b2;
                board.inst[f].b3 = board.inst[f1].b3;
                board.inst[f].b = board.inst[f1].b;
                result = changeValues(board.inst[f].fullinst, board.inst[f].inst, board, f, board.inst[f].a2, board.inst[f].a3, board.inst[f].a, board.inst[f].b2, board.inst[f].b3, board.inst[f].b);

            }

            // a3 = d and b3 = -
            if(a2 == '#' && b2 == 'd' && a3 == 'd' && b3 == '-'){
                int c = Integer.parseInt(b);
                if (board.inst[pc].b3 == '-'){
                    c = -c;
                }
                board.inst[checkCircular(pc+c)].b= board.inst[pc].a;
                result = changeValues(board.inst[checkCircular(pc+c)].fullinst, board.inst[checkCircular(pc+c)].inst, board, checkCircular(pc+c), board.inst[checkCircular(pc+c)].a2, board.inst[checkCircular(pc+c)].a3, board.inst[checkCircular(pc+c)].a, board.inst[checkCircular(pc+c)].b2, board.inst[checkCircular(pc+c)].b3, board.inst[checkCircular(pc+c)].b);
            }
            if(a2 == '#' && b2 == '@' && a3 == 'd' && b3 == '-'){
                int c = Integer.parseInt(b);
                if (board.inst[pc].b3 == '-'){
                    c = -c;
                }
                String e = board.inst[checkCircular(pc+c)].b;
                int g = Integer.parseInt(e);
                if (board.inst[checkCircular(pc+c)].b3 == '-'){
                    g = -g;
                }
                board.inst[checkCircular(pc+c+g)].b = board.inst[pc].a;
                int f = checkCircular(pc+c+g);
                result = changeValues(board.inst[f].fullinst, board.inst[f].inst, board, f, board.inst[f].a2, board.inst[f].a3, board.inst[f].a, board.inst[f].b2, board.inst[f].b3, board.inst[f].b);

            }
            if(a2 == '*' && b2 == 'd' && a3 == 'd' && b3 == '-'){
                int c = Integer.parseInt(b);
                if (board.inst[pc].b3 == '-'){
                    c = -c;
                }
                String e = board.inst[checkCircular(pc+c)].b;
                int f = checkCircular(pc+c);

                int c1 = Integer.parseInt(a);
                String e1 = board.inst[checkCircular(pc+c1)].a;
                int g1 = Integer.parseInt(e1);
                if (board.inst[checkCircular(pc+c1)].a3 == '-'){
                    g1 = -g1;
                }
                int f1 = checkCircular(pc+c1+g1);

                board.inst[f].fullinst = board.inst[f1].fullinst;
                board.inst[f].inst = board.inst[f1].inst;
                board.inst[f].a2 = board.inst[f1].a2;
                board.inst[f].a3 = board.inst[f1].a3;
                board.inst[f].a = board.inst[f1].a;
                board.inst[f].b2 = board.inst[f1].b2;
                board.inst[f].b3 = board.inst[f1].b3;
                board.inst[f].b = board.inst[f1].b;
                result = changeValues(board.inst[f].fullinst, board.inst[f].inst, board, f, board.inst[f].a2, board.inst[f].a3, board.inst[f].a, board.inst[f].b2, board.inst[f].b3, board.inst[f].b);
            }
            if(a2 == '*' && b2 == '@' && a3 == 'd' && b3 == '-'){
                int c = Integer.parseInt(b);
                if (board.inst[pc].b3 == '-'){
                    c = -c;
                }
                String e = board.inst[checkCircular(pc+c)].b;
                int g = Integer.parseInt(e);
                if (board.inst[checkCircular(pc+c)].b3 == '-'){
                    g = -g;
                }
                int f = checkCircular(pc+c+g);

                int c1 = Integer.parseInt(a);
                String e1 = board.inst[checkCircular(pc+c1)].a;
                int g1 = Integer.parseInt(e1);
                if (board.inst[checkCircular(pc+c1)].a3 == '-'){
                    g1 = -g1;
                }
                int f1 = checkCircular(pc+c1+g1);

                board.inst[f].fullinst = board.inst[f1].fullinst;
                board.inst[f].inst = board.inst[f1].inst;
                board.inst[f].a2 = board.inst[f1].a2;
                board.inst[f].a3 = board.inst[f1].a3;
                board.inst[f].a = board.inst[f1].a;
                board.inst[f].b2 = board.inst[f1].b2;
                board.inst[f].b3 = board.inst[f1].b3;
                board.inst[f].b = board.inst[f1].b;
                result = changeValues(board.inst[f].fullinst, board.inst[f].inst, board, f, board.inst[f].a2, board.inst[f].a3, board.inst[f].a, board.inst[f].b2, board.inst[f].b3, board.inst[f].b);
            }
            if(a2 == 'd' && b2 == 'd' && a3 == 'd' && b3 == '-'){
                int c = Integer.parseInt(b);
                if (board.inst[pc].b3 == '-'){
                    c = -c;
                }
                String e = board.inst[checkCircular(pc+c)].b;
                int f = checkCircular(pc+c);

                int c1 = Integer.parseInt(a);
                String e1 = board.inst[checkCircular(pc+c)].a;
                int f1 = checkCircular(pc+c1);

                board.inst[f].fullinst = board.inst[f1].fullinst;
                board.inst[f].inst = board.inst[f1].inst;
                board.inst[f].a2 = board.inst[f1].a2;
                board.inst[f].a3 = board.inst[f1].a3;
                board.inst[f].a = board.inst[f1].a;
                board.inst[f].b2 = board.inst[f1].b2;
                board.inst[f].b3 = board.inst[f1].b3;
                board.inst[f].b = board.inst[f1].b;
                result = changeValues(board.inst[f].fullinst, board.inst[f].inst, board, f, board.inst[f].a2, board.inst[f].a3, board.inst[f].a, board.inst[f].b2, board.inst[f].b3, board.inst[f].b);
            }
            if(a2 == 'd' && b2 == '@' && a3 == 'd' && b3 == '-'){
                int c = Integer.parseInt(b);
                if (board.inst[pc].b3 == '-'){
                    c = -c;
                }
                String e = board.inst[checkCircular(pc+c)].b;
                int g = Integer.parseInt(e);
                if (board.inst[checkCircular(pc+c)].b3 == '-'){
                    g = -g;
                }
                int f = checkCircular(pc+c+g);

                int c1 = Integer.parseInt(a);
                String e1 = board.inst[checkCircular(pc+c1)].a;
                int f1 = checkCircular(pc+c1);

                board.inst[f].fullinst = board.inst[f1].fullinst;
                board.inst[f].inst = board.inst[f1].inst;
                board.inst[f].a2 = board.inst[f1].a2;
                board.inst[f].a3 = board.inst[f1].a3;
                board.inst[f].a = board.inst[f1].a;
                board.inst[f].b2 = board.inst[f1].b2;
                board.inst[f].b3 = board.inst[f1].b3;
                board.inst[f].b = board.inst[f1].b;
                result = changeValues(board.inst[f].fullinst, board.inst[f].inst, board, f, board.inst[f].a2, board.inst[f].a3, board.inst[f].a, board.inst[f].b2, board.inst[f].b3, board.inst[f].b);
            }

            // a3 = - and b3 = -
            if(a2 == '#' && b2 == 'd' && a3 == '-' && b3 == '-'){
                int c = Integer.parseInt(b);
                if (board.inst[pc].b3 == '-'){
                    c = -c;
                }
                board.inst[checkCircular(pc+c)].b= board.inst[pc].a;
                board.inst[checkCircular(pc+c)].b3 = a3;
                result = changeValues(board.inst[checkCircular(pc+c)].fullinst, board.inst[checkCircular(pc+c)].inst, board, checkCircular(pc+c), board.inst[checkCircular(pc+c)].a2, board.inst[checkCircular(pc+c)].a3, board.inst[checkCircular(pc+c)].a, board.inst[checkCircular(pc+c)].b2, board.inst[checkCircular(pc+c)].b3, board.inst[checkCircular(pc+c)].b);
            }
            if(a2 == '#' && b2 == '@' && a3 == '-' && b3 == '-'){
                int c = Integer.parseInt(b);
                if (board.inst[pc].b3 == '-'){
                    c = -c;
                }
                String e = board.inst[checkCircular(pc+c)].b;
                int g = Integer.parseInt(e);
                if (board.inst[checkCircular(pc+c)].b3 == '-'){
                    g = -g;
                }
                board.inst[checkCircular(pc+c+g)].b = board.inst[pc].a;
                int f = checkCircular(pc+c+g);
                board.inst[f].b3 = a3;
                result = changeValues(board.inst[f].fullinst, board.inst[f].inst, board, f, board.inst[f].a2, board.inst[f].a3, board.inst[f].a, board.inst[f].b2, board.inst[f].b3, board.inst[f].b);

            }
            if(a2 == '*' && b2 == 'd' && a3 == '-' && b3 == '-'){
                int c = Integer.parseInt(b);
                if (board.inst[pc].b3 == '-'){
                    c = -c;
                }
                String e = board.inst[checkCircular(pc+c)].b;
                int f = checkCircular(pc+c);

                int c1 = Integer.parseInt(a);
                if (board.inst[pc].a3 == '-'){
                    c1 = -c1;
                }
                String e1 = board.inst[checkCircular(pc+c1)].a;
                int g1 = Integer.parseInt(e1);
                if (board.inst[checkCircular(pc+c1)].a3 == '-'){
                    g1 = -g1;
                }
                int f1 = checkCircular(pc+c1+g1);

                board.inst[f].fullinst = board.inst[f1].fullinst;
                board.inst[f].inst = board.inst[f1].inst;
                board.inst[f].a2 = board.inst[f1].a2;
                board.inst[f].a3 = board.inst[f1].a3;
                board.inst[f].a = board.inst[f1].a;
                board.inst[f].b2 = board.inst[f1].b2;
                board.inst[f].b3 = board.inst[f1].b3;
                board.inst[f].b = board.inst[f1].b;
                result = changeValues(board.inst[f].fullinst, board.inst[f].inst, board, f, board.inst[f].a2, board.inst[f].a3, board.inst[f].a, board.inst[f].b2, board.inst[f].b3, board.inst[f].b);
            }
            if(a2 == '*' && b2 == '@' && a3 == '-' && b3 == '-'){
                int c = Integer.parseInt(b);
                if (board.inst[pc].b3 == '-'){
                    c = -c;
                }
                String e = board.inst[checkCircular(pc+c)].b;
                int g = Integer.parseInt(e);
                if (board.inst[checkCircular(pc+c)].b3 == '-'){
                    g = -g;
                }
                int f = checkCircular(pc+c+g);

                int c1 = Integer.parseInt(a);
                if (board.inst[pc].a3 == '-'){
                    c1 = -c1;
                }
                String e1 = board.inst[checkCircular(pc+c1)].a;
                int g1 = Integer.parseInt(e1);
                if (board.inst[checkCircular(pc+c1)].a3 == '-'){
                    g1 = -g1;
                }
                int f1 = checkCircular(pc+c1+g1);

                board.inst[f].fullinst = board.inst[f1].fullinst;
                board.inst[f].inst = board.inst[f1].inst;
                board.inst[f].a2 = board.inst[f1].a2;
                board.inst[f].a3 = board.inst[f1].a3;
                board.inst[f].a = board.inst[f1].a;
                board.inst[f].b2 = board.inst[f1].b2;
                board.inst[f].b3 = board.inst[f1].b3;
                board.inst[f].b = board.inst[f1].b;
                result = changeValues(board.inst[f].fullinst, board.inst[f].inst, board, f, board.inst[f].a2, board.inst[f].a3, board.inst[f].a, board.inst[f].b2, board.inst[f].b3, board.inst[f].b);
            }
            if(a2 == 'd' && b2 == 'd' && a3 == '-' && b3 == '-'){
                int c = Integer.parseInt(b);
                if (board.inst[pc].b3 == '-'){
                    c = -c;
                }
                String e = board.inst[checkCircular(pc+c)].b;
                int f = checkCircular(pc+c);

                int c1 = Integer.parseInt(a);
                if (board.inst[pc].a3 == '-'){
                    c1 = -c1;
                }

                String e1 = board.inst[checkCircular(pc+c1)].a;
                int f1 = checkCircular(pc+c1);

                board.inst[f].fullinst = board.inst[f1].fullinst;
                board.inst[f].inst = board.inst[f1].inst;
                board.inst[f].a2 = board.inst[f1].a2;
                board.inst[f].a3 = board.inst[f1].a3;
                board.inst[f].a = board.inst[f1].a;
                board.inst[f].b2 = board.inst[f1].b2;
                board.inst[f].b3 = board.inst[f1].b3;
                board.inst[f].b = board.inst[f1].b;
                result = changeValues(board.inst[f].fullinst, board.inst[f].inst, board, f, board.inst[f].a2, board.inst[f].a3, board.inst[f].a, board.inst[f].b2, board.inst[f].b3, board.inst[f].b);
            }
            if(a2 == 'd' && b2 == '@' && a3 == '-' && b3 == '-'){
                int c = Integer.parseInt(b);
                if (board.inst[pc].b3 == '-'){
                    c = -c;
                }
                String e = board.inst[checkCircular(pc+c)].b;
                int g = Integer.parseInt(e);
                if (board.inst[checkCircular(pc+c)].b3 == '-'){
                    g = -g;
                }
                int f = checkCircular(pc+c+g);

                int c1 = Integer.parseInt(a);
                if (board.inst[pc].a3 == '-'){
                    c1 = -c1;
                }
                String e1 = board.inst[checkCircular(pc+c1)].a;
                int f1 = checkCircular(pc+c1);

                board.inst[f].fullinst = board.inst[f1].fullinst;
                board.inst[f].inst = board.inst[f1].inst;
                board.inst[f].a2 = board.inst[f1].a2;
                board.inst[f].a3 = board.inst[f1].a3;
                board.inst[f].a = board.inst[f1].a;
                board.inst[f].b2 = board.inst[f1].b2;
                board.inst[f].b3 = board.inst[f1].b3;
                board.inst[f].b = board.inst[f1].b;
                result = changeValues(board.inst[f].fullinst, board.inst[f].inst, board, f, board.inst[f].a2, board.inst[f].a3, board.inst[f].a, board.inst[f].b2, board.inst[f].b3, board.inst[f].b);
            }
        }
        else {
            System.out.println("Error");
        }
    }

////////////////////////////////////////////////////////////////////////////////////////////////

    public void ADD(String fullinst, String inst, Board board, int pc, char a2, char a3, String a, char b2, char b3, String b) {
        if((a2 == '#' || a2 == '*' || a2 == 'd') && (b2 == 'd' || b2 == '@') && (a3 == '-' || a3 == 'd') && (b3 == '-' || b3 == 'd')) {
            String result = " ";
            // a3 = d and b3 = d
            if(a2 == '#' && b2 == 'd' && a3 == 'd' && b3 == 'd'){
                int c1 = Integer.parseInt(a);

                int c = Integer.parseInt(b);
                int e = Integer.parseInt(board.inst[checkCircular(pc+c)].b);
                if(board.inst[checkCircular(pc+c)].b3 == '-'){
                    e = -e;
                }
                int g = (c1 +e);
                if (g<0){
                    g = -(g);
                    board.inst[checkCircular(pc+c)].b3 = '-';
                }else{
                    board.inst[checkCircular(pc+c)].b3 = 'd';
                }
                String added = Integer.toString(g);
                board.inst[checkCircular(pc+c)].b= added;
                result = changeValues(board.inst[checkCircular(pc+c)].fullinst, board.inst[checkCircular(pc+c)].inst, board, checkCircular(pc+c), board.inst[checkCircular(pc+c)].a2, board.inst[checkCircular(pc+c)].a3, board.inst[checkCircular(pc+c)].a, board.inst[checkCircular(pc+c)].b2, board.inst[checkCircular(pc+c)].b3, board.inst[checkCircular(pc+c)].b);
            }
            if(a2 == '#' && b2 == '@' && a3 == 'd' && b3 == 'd'){

                int c1 = Integer.parseInt(a);

                int c = Integer.parseInt(b);
                int e = Integer.parseInt(board.inst[checkCircular(pc+c)].b);
                if(board.inst[checkCircular(pc+c)].b3 == '-'){
                    e = -e;
                }
                int g = Integer.parseInt(board.inst[checkCircular(pc+c+e)].b);
                if(board.inst[checkCircular(pc+c+e)].b3 == '-'){
                    g = -g;
                }
                int h = c1 + g;
                if(h<0){
                    h = -(h);
                    board.inst[checkCircular(pc+c+e)].b3 = '-';
                }else{
                    board.inst[checkCircular(pc+c+e)].b3 = 'd';
                }

                String added = Integer.toString(h);
                int f = checkCircular(pc+c+e);
                board.inst[f].b = added;
                result = changeValues(board.inst[f].fullinst, board.inst[f].inst, board, f, board.inst[f].a2, board.inst[f].a3, board.inst[f].a, board.inst[f].b2, board.inst[f].b3, board.inst[f].b);

            }
            if(a2 == '*' && b2 == 'd' && a3 == 'd' && b3 == 'd'){
                int c = Integer.parseInt(b);
                int d = Integer.parseInt(a);
                int e = Integer.parseInt(board.inst[checkCircular(pc+d)].a);
                if(board.inst[checkCircular(pc+d)].a3 == '-'){
                    e = -e;
                }
                int g = Integer.parseInt(board.inst[checkCircular(pc+d+e)].a);
                int i = Integer.parseInt(board.inst[checkCircular(pc+d+e)].b);
                int j = Integer.parseInt(board.inst[checkCircular(pc+c)].a);
                int k = Integer.parseInt(board.inst[checkCircular(pc+c)].b);
                if(board.inst[checkCircular(pc+d+e)].a3 == '-'){
                    g = -g;
                }
                if(board.inst[checkCircular(pc+d+e)].b3 == '-'){
                    i = -i;
                }
                if(board.inst[checkCircular(pc+c)].a3 == '-'){
                    j = -j;
                }
                if(board.inst[checkCircular(pc+c)].b3 == '-'){
                    k = -k;
                }

                int h = Math.abs(j+g);
                String add1 = Integer.toString(h);
                if((j+g) < 0){
                    h = -h;
                    board.inst[checkCircular(pc+c)].a3 = '-';
                }
                else{
                    board.inst[checkCircular(pc+c)].a3 = 'd';
                }

                int l = Math.abs(k+i);
                String add2 = Integer.toString(l);
                if((k+i) < 0){
                    l= -l;
                    board.inst[checkCircular(pc+c)].b3 = '-';
                }
                else{
                    board.inst[checkCircular(pc+c)].b3 = 'd';
                }

                int f = checkCircular(pc+c);
                board.inst[f].a = add1;
                board.inst[f].b = add2;
                result = changeValues(board.inst[f].fullinst, board.inst[f].inst, board, f, board.inst[f].a2, board.inst[f].a3, board.inst[f].a, board.inst[f].b2, board.inst[f].b3, board.inst[f].b);
            }
            if(a2 == '*' && b2 == '@' && a3 == 'd' && b3 == 'd'){
                int c = Integer.parseInt(b);
                int d = Integer.parseInt(a);
                int e = Integer.parseInt(board.inst[checkCircular(pc+d)].a);
                if(board.inst[checkCircular(pc+d)].a3 == '-'){
                    e = -e;
                }
                int g = Integer.parseInt(board.inst[checkCircular(pc+d+e)].a);
                if(board.inst[checkCircular(pc+d+e)].a3 == '-'){
                    g = -g;
                }
                int i = Integer.parseInt(board.inst[checkCircular(pc+d+e)].b);
                if(board.inst[checkCircular(pc+d+e)].b3 == '-'){
                    i = -i;
                }
                int k = Integer.parseInt(board.inst[checkCircular(pc+c)].b);
                if(board.inst[checkCircular(pc+c)].b3 == '-'){
                    k = -k;
                }
                int m = Integer.parseInt(board.inst[checkCircular(pc+c+k)].a);
                if(board.inst[checkCircular(pc+c+k)].a3 == '-'){
                    m = -m;
                }
                int n = Integer.parseInt(board.inst[checkCircular(pc+c+k)].b);
                if(board.inst[checkCircular(pc+c+k)].b3 == '-'){
                    n = -n;
                }

                int h = Math.abs(m+g);
                String add1 = Integer.toString(h);
                if((m+g) < 0){
                    h = -h;
                    board.inst[checkCircular(pc+c+k)].a3 = '-';
                }
                else{
                    board.inst[checkCircular(pc+c+k)].a3 = 'd';
                }

                int l = Math.abs(n+i);
                String add2 = Integer.toString(l);
                if((n+i) < 0){
                    l= -l;
                    board.inst[checkCircular(pc+c+k)].b3 = '-';
                }
                else{
                    board.inst[checkCircular(pc+c+k)].b3 = 'd';
                }

                int f = checkCircular(pc+c+k);
                board.inst[f].a = add1;
                board.inst[f].b = add2;
                result = changeValues(board.inst[f].fullinst, board.inst[f].inst, board, f, board.inst[f].a2, board.inst[f].a3, board.inst[f].a, board.inst[f].b2, board.inst[f].b3, board.inst[f].b);
            }
            if(a2 == 'd' && b2 == 'd' && a3 == 'd' && b3 == 'd'){
                int c = Integer.parseInt(b);
                int d = Integer.parseInt(a);
                int e = Integer.parseInt(board.inst[checkCircular(pc+d)].a);
                if(board.inst[checkCircular(pc+d)].a3 == '-'){
                    e = -e;
                }
                int g = Integer.parseInt(board.inst[checkCircular(pc+d)].b);
                if(board.inst[checkCircular(pc+d)].b3 == '-'){
                    g = -g;
                }
                int k = Integer.parseInt(board.inst[checkCircular(pc+c)].b);
                if(board.inst[checkCircular(pc+c)].b3 == '-'){
                    k = -k;
                }
                int l = Integer.parseInt(board.inst[checkCircular(pc+c)].a);
                if(board.inst[checkCircular(pc+c)].a3 == '-'){
                    l = -l;
                }

                int h = Math.abs(l+e);
                String add1 = Integer.toString(h);
                if((l+e) < 0){
                    h = -h;
                    board.inst[checkCircular(pc+c)].a3 = '-';
                }
                else{
                    board.inst[checkCircular(pc+c)].a3 = 'd';
                }

                int i = Math.abs(k+g);
                String add2 = Integer.toString(i);
                if((k+g) < 0){
                    l= -l;
                    board.inst[checkCircular(pc+c)].b3 = '-';
                }
                else{
                    board.inst[checkCircular(pc+c)].b3 = 'd';
                }

                int f = checkCircular(pc+c);
                board.inst[f].a = add1;
                board.inst[f].b = add2;
                result = changeValues(board.inst[f].fullinst, board.inst[f].inst, board, f, board.inst[f].a2, board.inst[f].a3, board.inst[f].a, board.inst[f].b2, board.inst[f].b3, board.inst[f].b);
            }
            if(a2 == 'd' && b2 == '@' && a3 == 'd' && b3 == 'd'){
                int c = Integer.parseInt(b);
                int d = Integer.parseInt(a);
                int e = Integer.parseInt(board.inst[checkCircular(pc+c)].b);
                if(board.inst[checkCircular(pc+c)].b3 == '-'){
                    e = -e;
                }
                int g = Integer.parseInt(board.inst[checkCircular(pc+c+e)].a);
                int i = Integer.parseInt(board.inst[checkCircular(pc+c+e)].b);
                int j = Integer.parseInt(board.inst[checkCircular(pc+d)].a);
                int k = Integer.parseInt(board.inst[checkCircular(pc+d)].b);
                if(board.inst[checkCircular(pc+c+e)].a3 == '-'){
                    g = -g;
                }
                if(board.inst[checkCircular(pc+c+e)].b3 == '-'){
                    i = -i;
                }
                if(board.inst[checkCircular(pc+d)].a3 == '-'){
                    j = -j;
                }
                if(board.inst[checkCircular(pc+d)].b3 == '-'){
                    k = -k;
                }

                int h = Math.abs(g+j);
                String add1 = Integer.toString(h);
                if((g+j) < 0){
                    h = -h;
                    board.inst[checkCircular(pc+c+e)].a3 = '-';
                }
                else{
                    board.inst[checkCircular(pc+c+e)].a3 = 'd';
                }

                int l = Math.abs(i+k);
                String add2 = Integer.toString(l);
                if((i+k) < 0){
                    l= -l;
                    board.inst[checkCircular(pc+c+e)].b3 = '-';
                }
                else{
                    board.inst[checkCircular(pc+c+e)].b3 = 'd';
                }

                int f = checkCircular(pc+c+e);
                board.inst[f].a = add1;
                board.inst[f].b = add2;
                result = changeValues(board.inst[f].fullinst, board.inst[f].inst, board, f, board.inst[f].a2, board.inst[f].a3, board.inst[f].a, board.inst[f].b2, board.inst[f].b3, board.inst[f].b);
            }

            // a3 = - and b3 = d
            if(a2 == '#' && b2 == 'd' && a3 == '-' && b3 == 'd'){
                int c1 = Integer.parseInt(a);
                if(board.inst[pc].a3 == '-'){
                    c1 = -c1;
                }
                int c = Integer.parseInt(b);
                int e = Integer.parseInt(board.inst[checkCircular(pc+c)].b);
                if(board.inst[checkCircular(pc+c)].b3 == '-'){
                    e = -e;
                }
                int g = (c1 +e);
                if (g<0){
                    g = -(g);
                    board.inst[checkCircular(pc+c)].b3 = '-';
                }else{
                    board.inst[checkCircular(pc+c)].b3 = 'd';
                }
                String added = Integer.toString(g);
                board.inst[checkCircular(pc+c)].b= added;
                result = changeValues(board.inst[checkCircular(pc+c)].fullinst, board.inst[checkCircular(pc+c)].inst, board, checkCircular(pc+c), board.inst[checkCircular(pc+c)].a2, board.inst[checkCircular(pc+c)].a3, board.inst[checkCircular(pc+c)].a, board.inst[checkCircular(pc+c)].b2, board.inst[checkCircular(pc+c)].b3, board.inst[checkCircular(pc+c)].b);
            }
            if(a2 == '#' && b2 == '@' && a3 == '-' && b3 == 'd'){
                int c1 = Integer.parseInt(a);
                if(board.inst[pc].a3 == '-'){
                    c1 = -c1;
                }
                int c = Integer.parseInt(b);
                int e = Integer.parseInt(board.inst[checkCircular(pc+c)].b);
                if(board.inst[checkCircular(pc+c)].b3 == '-'){
                    e = -e;
                }
                int g = Integer.parseInt(board.inst[checkCircular(pc+c+e)].b);
                if(board.inst[checkCircular(pc+c+e)].b3 == '-'){
                    g = -g;
                }
                int h = c1 + g;
                if(h<0){
                    h = -(h);
                    board.inst[checkCircular(pc+c+e)].b3 = '-';
                }else{
                    board.inst[checkCircular(pc+c+e)].b3 = 'd';
                }

                String added = Integer.toString(h);
                int f = checkCircular(pc+c+e);
                board.inst[f].b = added;
                result = changeValues(board.inst[f].fullinst, board.inst[f].inst, board, f, board.inst[f].a2, board.inst[f].a3, board.inst[f].a, board.inst[f].b2, board.inst[f].b3, board.inst[f].b);

            }
            if(a2 == '*' && b2 == 'd' && a3 == '-' && b3 == 'd'){
                int c = Integer.parseInt(b);
                int d = Integer.parseInt(a);
                if(board.inst[pc].a3 == '-'){
                    d = -d;
                }
                int e = Integer.parseInt(board.inst[checkCircular(pc+d)].a);
                if(board.inst[checkCircular(pc+d)].a3 == '-'){
                    e = -e;
                }
                int g = Integer.parseInt(board.inst[checkCircular(pc+d+e)].a);
                int i = Integer.parseInt(board.inst[checkCircular(pc+d+e)].b);
                int j = Integer.parseInt(board.inst[checkCircular(pc+c)].a);
                int k = Integer.parseInt(board.inst[checkCircular(pc+c)].b);
                if(board.inst[checkCircular(pc+d+e)].a3 == '-'){
                    g = -g;
                }
                if(board.inst[checkCircular(pc+d+e)].b3 == '-'){
                    i = -i;
                }
                if(board.inst[checkCircular(pc+c)].a3 == '-'){
                    j = -j;
                }
                if(board.inst[checkCircular(pc+c)].b3 == '-'){
                    k = -k;
                }

                int h = Math.abs(j+g);
                String add1 = Integer.toString(h);
                if((j+g) < 0){
                    h = -h;
                    board.inst[checkCircular(pc+c)].a3 = '-';
                }
                else{
                    board.inst[checkCircular(pc+c)].a3 = 'd';
                }

                int l = Math.abs(k+i);
                String add2 = Integer.toString(l);
                if((k+i) < 0){
                    l= -l;
                    board.inst[checkCircular(pc+c)].b3 = '-';
                }
                else{
                    board.inst[checkCircular(pc+c)].b3 = 'd';
                }

                int f = checkCircular(pc+c);
                board.inst[f].a = add1;
                board.inst[f].b = add2;
                result = changeValues(board.inst[f].fullinst, board.inst[f].inst, board, f, board.inst[f].a2, board.inst[f].a3, board.inst[f].a, board.inst[f].b2, board.inst[f].b3, board.inst[f].b);
            }
            if(a2 == '*' && b2 == '@' && a3 == '-' && b3 == 'd'){
                int c = Integer.parseInt(b);
                int d = Integer.parseInt(a);
                if(board.inst[pc].a3 == '-'){
                    d = -d;
                }
                int e = Integer.parseInt(board.inst[checkCircular(pc+d)].a);
                if(board.inst[checkCircular(pc+d)].a3 == '-'){
                    e = -e;
                }
                int g = Integer.parseInt(board.inst[checkCircular(pc+d+e)].a);
                if(board.inst[checkCircular(pc+d+e)].a3 == '-'){
                    g = -g;
                }
                int i = Integer.parseInt(board.inst[checkCircular(pc+d+e)].b);
                if(board.inst[checkCircular(pc+d+e)].b3 == '-'){
                    i = -i;
                }
                int k = Integer.parseInt(board.inst[checkCircular(pc+c)].b);
                if(board.inst[checkCircular(pc+c)].b3 == '-'){
                    k = -k;
                }
                int m = Integer.parseInt(board.inst[checkCircular(pc+c+k)].a);
                if(board.inst[checkCircular(pc+c+k)].a3 == '-'){
                    m = -m;
                }
                int n = Integer.parseInt(board.inst[checkCircular(pc+c+k)].b);
                if(board.inst[checkCircular(pc+c+k)].b3 == '-'){
                    n = -n;
                }

                int h = Math.abs(m+g);
                String add1 = Integer.toString(h);
                if((m+g) < 0){
                    h = -h;
                    board.inst[checkCircular(pc+c+k)].a3 = '-';
                }
                else{
                    board.inst[checkCircular(pc+c+k)].a3 = 'd';
                }

                int l = Math.abs(n+i);
                String add2 = Integer.toString(l);
                if((n+i) < 0){
                    l= -l;
                    board.inst[checkCircular(pc+c+k)].b3 = '-';
                }
                else{
                    board.inst[checkCircular(pc+c+k)].b3 = 'd';
                }

                int f = checkCircular(pc+c+k);
                board.inst[f].a = add1;
                board.inst[f].b = add2;
                result = changeValues(board.inst[f].fullinst, board.inst[f].inst, board, f, board.inst[f].a2, board.inst[f].a3, board.inst[f].a, board.inst[f].b2, board.inst[f].b3, board.inst[f].b);
            }
            if(a2 == 'd' && b2 == 'd' && a3 == '-' && b3 == 'd'){
                int c = Integer.parseInt(b);
                int d = Integer.parseInt(a);
                if(board.inst[pc].a3 == '-'){
                    d = -d;
                }
                int e = Integer.parseInt(board.inst[checkCircular(pc+d)].a);
                if(board.inst[checkCircular(pc+d)].a3 == '-'){
                    e = -e;
                }
                int g = Integer.parseInt(board.inst[checkCircular(pc+d)].b);
                if(board.inst[checkCircular(pc+d)].b3 == '-'){
                    g = -g;
                }
                int k = Integer.parseInt(board.inst[checkCircular(pc+c)].b);
                if(board.inst[checkCircular(pc+c)].b3 == '-'){
                    k = -k;
                }
                int l = Integer.parseInt(board.inst[checkCircular(pc+c)].a);
                if(board.inst[checkCircular(pc+c)].a3 == '-'){
                    l = -l;
                }

                int h = Math.abs(l+e);
                String add1 = Integer.toString(h);
                if((l+e) < 0){
                    h = -h;
                    board.inst[checkCircular(pc+c)].a3 = '-';
                }
                else{
                    board.inst[checkCircular(pc+c)].a3 = 'd';
                }

                int i = Math.abs(k+g);
                String add2 = Integer.toString(i);
                if((k+g) < 0){
                    l= -l;
                    board.inst[checkCircular(pc+c)].b3 = '-';
                }
                else{
                    board.inst[checkCircular(pc+c)].b3 = 'd';
                }

                int f = checkCircular(pc+c);
                board.inst[f].a = add1;
                board.inst[f].b = add2;
                result = changeValues(board.inst[f].fullinst, board.inst[f].inst, board, f, board.inst[f].a2, board.inst[f].a3, board.inst[f].a, board.inst[f].b2, board.inst[f].b3, board.inst[f].b);
            }
            if(a2 == 'd' && b2 == '@' && a3 == '-' && b3 == 'd'){
                int c = Integer.parseInt(b);
                int d = Integer.parseInt(a);
                if(board.inst[pc].a3 == '-'){
                    d = -d;
                }
                int e = Integer.parseInt(board.inst[checkCircular(pc+c)].b);
                if(board.inst[checkCircular(pc+c)].b3 == '-'){
                    e = -e;
                }
                int g = Integer.parseInt(board.inst[checkCircular(pc+c+e)].a);
                int i = Integer.parseInt(board.inst[checkCircular(pc+c+e)].b);
                int j = Integer.parseInt(board.inst[checkCircular(pc+d)].a);
                int k = Integer.parseInt(board.inst[checkCircular(pc+d)].b);
                if(board.inst[checkCircular(pc+c+e)].a3 == '-'){
                    g = -g;
                }
                if(board.inst[checkCircular(pc+c+e)].b3 == '-'){
                    i = -i;
                }
                if(board.inst[checkCircular(pc+d)].a3 == '-'){
                    j = -j;
                }
                if(board.inst[checkCircular(pc+d)].b3 == '-'){
                    k = -k;
                }

                int h = Math.abs(g+j);
                String add1 = Integer.toString(h);
                if((g+j) < 0){
                    h = -h;
                    board.inst[checkCircular(pc+c+e)].a3 = '-';
                }
                else{
                    board.inst[checkCircular(pc+c+e)].a3 = 'd';
                }

                int l = Math.abs(i+k);
                String add2 = Integer.toString(l);
                if((i+k) < 0){
                    l= -l;
                    board.inst[checkCircular(pc+c+e)].b3 = '-';
                }
                else{
                    board.inst[checkCircular(pc+c+e)].b3 = 'd';
                }

                int f = checkCircular(pc+c+e);
                board.inst[f].a = add1;
                board.inst[f].b = add2;
                result = changeValues(board.inst[f].fullinst, board.inst[f].inst, board, f, board.inst[f].a2, board.inst[f].a3, board.inst[f].a, board.inst[f].b2, board.inst[f].b3, board.inst[f].b);
            }

            // a3 = d and b3 = -
            if(a2 == '#' && b2 == 'd' && a3 == 'd' && b3 == '-'){
                int c1 = Integer.parseInt(a);
                int c = Integer.parseInt(b);
                if(board.inst[pc].b3 == '-'){
                    c = -c;
                }
                int e = Integer.parseInt(board.inst[checkCircular(pc+c)].b);
                if(board.inst[checkCircular(pc+c)].b3 == '-'){
                    e = -e;
                }
                int g = (c1 +e);
                if (g<0){
                    g = -(g);
                    board.inst[checkCircular(pc+c)].b3 = '-';
                }else{
                    board.inst[checkCircular(pc+c)].b3 = 'd';
                }
                String added = Integer.toString(g);
                board.inst[checkCircular(pc+c)].b= added;
                result = changeValues(board.inst[checkCircular(pc+c)].fullinst, board.inst[checkCircular(pc+c)].inst, board, checkCircular(pc+c), board.inst[checkCircular(pc+c)].a2, board.inst[checkCircular(pc+c)].a3, board.inst[checkCircular(pc+c)].a, board.inst[checkCircular(pc+c)].b2, board.inst[checkCircular(pc+c)].b3, board.inst[checkCircular(pc+c)].b);
            }
            if(a2 == '#' && b2 == '@' && a3 == 'd' && b3 == '-'){
                int c1 = Integer.parseInt(a);
                int c = Integer.parseInt(b);
                if(board.inst[pc].b3 == '-'){
                    c = -c;
                }
                int e = Integer.parseInt(board.inst[checkCircular(pc+c)].b);
                if(board.inst[checkCircular(pc+c)].b3 == '-'){
                    e = -e;
                }
                int g = Integer.parseInt(board.inst[checkCircular(pc+c+e)].b);
                if(board.inst[checkCircular(pc+c+e)].b3 == '-'){
                    g = -g;
                }
                int h = c1 + g;
                if(h<0){
                    h = -(h);
                    board.inst[checkCircular(pc+c+e)].b3 = '-';
                }else{
                    board.inst[checkCircular(pc+c+e)].b3 = 'd';
                }

                String added = Integer.toString(h);
                int f = checkCircular(pc+c+e);
                board.inst[f].b = added;
                result = changeValues(board.inst[f].fullinst, board.inst[f].inst, board, f, board.inst[f].a2, board.inst[f].a3, board.inst[f].a, board.inst[f].b2, board.inst[f].b3, board.inst[f].b);
            }
            if(a2 == '*' && b2 == 'd' && a3 == 'd' && b3 == '-'){
                int c = Integer.parseInt(b);
                if(board.inst[pc].b3 == '-'){
                    c = -c;
                }
                int d = Integer.parseInt(a);
                int e = Integer.parseInt(board.inst[checkCircular(pc+d)].a);
                if(board.inst[checkCircular(pc+d)].a3 == '-'){
                    e = -e;
                }
                int g = Integer.parseInt(board.inst[checkCircular(pc+d+e)].a);
                int i = Integer.parseInt(board.inst[checkCircular(pc+d+e)].b);
                int j = Integer.parseInt(board.inst[checkCircular(pc+c)].a);
                int k = Integer.parseInt(board.inst[checkCircular(pc+c)].b);
                if(board.inst[checkCircular(pc+d+e)].a3 == '-'){
                    g = -g;
                }
                if(board.inst[checkCircular(pc+d+e)].b3 == '-'){
                    i = -i;
                }
                if(board.inst[checkCircular(pc+c)].a3 == '-'){
                    j = -j;
                }
                if(board.inst[checkCircular(pc+c)].b3 == '-'){
                    k = -k;
                }

                int h = Math.abs(j+g);
                String add1 = Integer.toString(h);
                if((j+g) < 0){
                    h = -h;
                    board.inst[checkCircular(pc+c)].a3 = '-';
                }
                else{
                    board.inst[checkCircular(pc+c)].a3 = 'd';
                }

                int l = Math.abs(k+i);
                String add2 = Integer.toString(l);
                if((k+i) < 0){
                    l= -l;
                    board.inst[checkCircular(pc+c)].b3 = '-';
                }
                else{
                    board.inst[checkCircular(pc+c)].b3 = 'd';
                }

                int f = checkCircular(pc+c);
                board.inst[f].a = add1;
                board.inst[f].b = add2;
                result = changeValues(board.inst[f].fullinst, board.inst[f].inst, board, f, board.inst[f].a2, board.inst[f].a3, board.inst[f].a, board.inst[f].b2, board.inst[f].b3, board.inst[f].b);
            }
            if(a2 == '*' && b2 == '@' && a3 == 'd' && b3 == '-'){
                int c = Integer.parseInt(b);
                if(board.inst[pc].b3 == '-'){
                    c = -c;
                }
                int d = Integer.parseInt(a);
                int e = Integer.parseInt(board.inst[checkCircular(pc+d)].a);
                if(board.inst[checkCircular(pc+d)].a3 == '-'){
                    e = -e;
                }
                int g = Integer.parseInt(board.inst[checkCircular(pc+d+e)].a);
                if(board.inst[checkCircular(pc+d+e)].a3 == '-'){
                    g = -g;
                }
                int i = Integer.parseInt(board.inst[checkCircular(pc+d+e)].b);
                if(board.inst[checkCircular(pc+d+e)].b3 == '-'){
                    i = -i;
                }
                int k = Integer.parseInt(board.inst[checkCircular(pc+c)].b);
                if(board.inst[checkCircular(pc+c)].b3 == '-'){
                    k = -k;
                }
                int m = Integer.parseInt(board.inst[checkCircular(pc+c+k)].a);
                if(board.inst[checkCircular(pc+c+k)].a3 == '-'){
                    m = -m;
                }
                int n = Integer.parseInt(board.inst[checkCircular(pc+c+k)].b);
                if(board.inst[checkCircular(pc+c+k)].b3 == '-'){
                    n = -n;
                }

                int h = Math.abs(m+g);
                String add1 = Integer.toString(h);
                if((m+g) < 0){
                    h = -h;
                    board.inst[checkCircular(pc+c+k)].a3 = '-';
                }
                else{
                    board.inst[checkCircular(pc+c+k)].a3 = 'd';
                }

                int l = Math.abs(n+i);
                String add2 = Integer.toString(l);
                if((n+i) < 0){
                    l= -l;
                    board.inst[checkCircular(pc+c+k)].b3 = '-';
                }
                else{
                    board.inst[checkCircular(pc+c+k)].b3 = 'd';
                }

                int f = checkCircular(pc+c+k);
                board.inst[f].a = add1;
                board.inst[f].b = add2;
                result = changeValues(board.inst[f].fullinst, board.inst[f].inst, board, f, board.inst[f].a2, board.inst[f].a3, board.inst[f].a, board.inst[f].b2, board.inst[f].b3, board.inst[f].b);
            }
            if(a2 == 'd' && b2 == 'd' && a3 == 'd' && b3 == '-'){
                int c = Integer.parseInt(b);
                if(board.inst[pc].b3 == '-'){
                    c = -c;
                }
                int d = Integer.parseInt(a);
                int e = Integer.parseInt(board.inst[checkCircular(pc+d)].a);
                if(board.inst[checkCircular(pc+d)].a3 == '-'){
                    e = -e;
                }
                int g = Integer.parseInt(board.inst[checkCircular(pc+d)].b);
                if(board.inst[checkCircular(pc+d)].b3 == '-'){
                    g = -g;
                }
                int k = Integer.parseInt(board.inst[checkCircular(pc+c)].b);
                if(board.inst[checkCircular(pc+c)].b3 == '-'){
                    k = -k;
                }
                int l = Integer.parseInt(board.inst[checkCircular(pc+c)].a);
                if(board.inst[checkCircular(pc+c)].a3 == '-'){
                    l = -l;
                }

                int h = Math.abs(l+e);
                String add1 = Integer.toString(h);
                if((l+e) < 0){
                    h = -h;
                    board.inst[checkCircular(pc+c)].a3 = '-';
                }
                else{
                    board.inst[checkCircular(pc+c)].a3 = 'd';
                }

                int i = Math.abs(k+g);
                String add2 = Integer.toString(i);
                if((k+g) < 0){
                    l= -l;
                    board.inst[checkCircular(pc+c)].b3 = '-';
                }
                else{
                    board.inst[checkCircular(pc+c)].b3 = 'd';
                }

                int f = checkCircular(pc+c);
                board.inst[f].a = add1;
                board.inst[f].b = add2;
                result = changeValues(board.inst[f].fullinst, board.inst[f].inst, board, f, board.inst[f].a2, board.inst[f].a3, board.inst[f].a, board.inst[f].b2, board.inst[f].b3, board.inst[f].b);
            }
            if(a2 == 'd' && b2 == '@' && a3 == 'd' && b3 == '-'){
                int c = Integer.parseInt(b);
                if(board.inst[pc].b3 == '-'){
                    c = -c;
                }
                int d = Integer.parseInt(a);
                int e = Integer.parseInt(board.inst[checkCircular(pc+c)].b);
                if(board.inst[checkCircular(pc+c)].b3 == '-'){
                    e = -e;
                }
                int g = Integer.parseInt(board.inst[checkCircular(pc+c+e)].a);
                int i = Integer.parseInt(board.inst[checkCircular(pc+c+e)].b);
                int j = Integer.parseInt(board.inst[checkCircular(pc+d)].a);
                int k = Integer.parseInt(board.inst[checkCircular(pc+d)].b);
                if(board.inst[checkCircular(pc+c+e)].a3 == '-'){
                    g = -g;
                }
                if(board.inst[checkCircular(pc+c+e)].b3 == '-'){
                    i = -i;
                }
                if(board.inst[checkCircular(pc+d)].a3 == '-'){
                    j = -j;
                }
                if(board.inst[checkCircular(pc+d)].b3 == '-'){
                    k = -k;
                }

                int h = Math.abs(g+j);
                String add1 = Integer.toString(h);
                if((g+j) < 0){
                    h = -h;
                    board.inst[checkCircular(pc+c+e)].a3 = '-';
                }
                else{
                    board.inst[checkCircular(pc+c+e)].a3 = 'd';
                }

                int l = Math.abs(i+k);
                String add2 = Integer.toString(l);
                if((i+k) < 0){
                    l= -l;
                    board.inst[checkCircular(pc+c+e)].b3 = '-';
                }
                else{
                    board.inst[checkCircular(pc+c+e)].b3 = 'd';
                }

                int f = checkCircular(pc+c+e);
                board.inst[f].a = add1;
                board.inst[f].b = add2;
                result = changeValues(board.inst[f].fullinst, board.inst[f].inst, board, f, board.inst[f].a2, board.inst[f].a3, board.inst[f].a, board.inst[f].b2, board.inst[f].b3, board.inst[f].b);
            }

            // a3 = - and b3 = -
            if(a2 == '#' && b2 == 'd' && a3 == '-' && b3 == '-'){
                int c1 = Integer.parseInt(a);
                if(board.inst[pc].a3 == '-'){
                    c1 = -c1;
                }
                int c = Integer.parseInt(b);
                if(board.inst[pc].b3 == '-'){
                    c = -c;
                }
                int e = Integer.parseInt(board.inst[checkCircular(pc+c)].b);
                if(board.inst[checkCircular(pc+c)].b3 == '-'){
                    e = -e;
                }
                int g = (c1 +e);
                if (g<0){
                    g = -(g);
                    board.inst[checkCircular(pc+c)].b3 = '-';
                }else{
                    board.inst[checkCircular(pc+c)].b3 = 'd';
                }
                String added = Integer.toString(g);
                board.inst[checkCircular(pc+c)].b= added;
                result = changeValues(board.inst[checkCircular(pc+c)].fullinst, board.inst[checkCircular(pc+c)].inst, board, checkCircular(pc+c), board.inst[checkCircular(pc+c)].a2, board.inst[checkCircular(pc+c)].a3, board.inst[checkCircular(pc+c)].a, board.inst[checkCircular(pc+c)].b2, board.inst[checkCircular(pc+c)].b3, board.inst[checkCircular(pc+c)].b);
            }
            if(a2 == '#' && b2 == '@' && a3 == '-' && b3 == '-'){
                int c1 = Integer.parseInt(a);
                if(board.inst[pc].a3 == '-'){
                    c1 = -c1;
                }
                int c = Integer.parseInt(b);
                if(board.inst[pc].b3 == '-'){
                    c = -c;
                }
                int e = Integer.parseInt(board.inst[checkCircular(pc+c)].b);
                if(board.inst[checkCircular(pc+c)].b3 == '-'){
                    e = -e;
                }
                int g = Integer.parseInt(board.inst[checkCircular(pc+c+e)].b);
                if(board.inst[checkCircular(pc+c+e)].b3 == '-'){
                    g = -g;
                }
                int h = c1 + g;
                if(h<0){
                    h = -(h);
                    board.inst[checkCircular(pc+c+e)].b3 = '-';
                }else{
                    board.inst[checkCircular(pc+c+e)].b3 = 'd';
                }

                String added = Integer.toString(h);
                int f = checkCircular(pc+c+e);
                board.inst[f].b = added;
                result = changeValues(board.inst[f].fullinst, board.inst[f].inst, board, f, board.inst[f].a2, board.inst[f].a3, board.inst[f].a, board.inst[f].b2, board.inst[f].b3, board.inst[f].b);
            }
            if(a2 == '*' && b2 == 'd' && a3 == '-' && b3 == '-'){
                int c = Integer.parseInt(b);
                if(board.inst[pc].b3 == '-'){
                    c = -c;
                }
                int d = Integer.parseInt(a);
                if(board.inst[pc].a3 == '-'){
                    d = -d;
                }
                int e = Integer.parseInt(board.inst[checkCircular(pc+d)].a);
                if(board.inst[checkCircular(pc+d)].a3 == '-'){
                    e = -e;
                }
                int g = Integer.parseInt(board.inst[checkCircular(pc+d+e)].a);
                int i = Integer.parseInt(board.inst[checkCircular(pc+d+e)].b);
                int j = Integer.parseInt(board.inst[checkCircular(pc+c)].a);
                int k = Integer.parseInt(board.inst[checkCircular(pc+c)].b);
                if(board.inst[checkCircular(pc+d+e)].a3 == '-'){
                    g = -g;
                }
                if(board.inst[checkCircular(pc+d+e)].b3 == '-'){
                    i = -i;
                }
                if(board.inst[checkCircular(pc+c)].a3 == '-'){
                    j = -j;
                }
                if(board.inst[checkCircular(pc+c)].b3 == '-'){
                    k = -k;
                }

                int h = Math.abs(j+g);
                String add1 = Integer.toString(h);
                if((j+g) < 0){
                    h = -h;
                    board.inst[checkCircular(pc+c)].a3 = '-';
                }
                else{
                    board.inst[checkCircular(pc+c)].a3 = 'd';
                }

                int l = Math.abs(k+i);
                String add2 = Integer.toString(l);
                if((k+i) < 0){
                    l= -l;
                    board.inst[checkCircular(pc+c)].b3 = '-';
                }
                else{
                    board.inst[checkCircular(pc+c)].b3 = 'd';
                }

                int f = checkCircular(pc+c);
                board.inst[f].a = add1;
                board.inst[f].b = add2;
                result = changeValues(board.inst[f].fullinst, board.inst[f].inst, board, f, board.inst[f].a2, board.inst[f].a3, board.inst[f].a, board.inst[f].b2, board.inst[f].b3, board.inst[f].b);
            }
            if(a2 == '*' && b2 == '@' && a3 == '-' && b3 == '-'){
                int c = Integer.parseInt(b);
                if(board.inst[pc].b3 == '-'){
                    c = -c;
                }
                int d = Integer.parseInt(a);
                if(board.inst[pc].a3 == '-'){
                    d = -d;
                }
                int e = Integer.parseInt(board.inst[checkCircular(pc+d)].a);
                if(board.inst[checkCircular(pc+d)].a3 == '-'){
                    e = -e;
                }
                int g = Integer.parseInt(board.inst[checkCircular(pc+d+e)].a);
                if(board.inst[checkCircular(pc+d+e)].a3 == '-'){
                    g = -g;
                }
                int i = Integer.parseInt(board.inst[checkCircular(pc+d+e)].b);
                if(board.inst[checkCircular(pc+d+e)].b3 == '-'){
                    i = -i;
                }
                int k = Integer.parseInt(board.inst[checkCircular(pc+c)].b);
                if(board.inst[checkCircular(pc+c)].b3 == '-'){
                    k = -k;
                }
                int m = Integer.parseInt(board.inst[checkCircular(pc+c+k)].a);
                if(board.inst[checkCircular(pc+c+k)].a3 == '-'){
                    m = -m;
                }
                int n = Integer.parseInt(board.inst[checkCircular(pc+c+k)].b);
                if(board.inst[checkCircular(pc+c+k)].b3 == '-'){
                    n = -n;
                }

                int h = Math.abs(m+g);
                String add1 = Integer.toString(h);
                if((m+g) < 0){
                    h = -h;
                    board.inst[checkCircular(pc+c+k)].a3 = '-';
                }
                else{
                    board.inst[checkCircular(pc+c+k)].a3 = 'd';
                }

                int l = Math.abs(n+i);
                String add2 = Integer.toString(l);
                if((n+i) < 0){
                    l= -l;
                    board.inst[checkCircular(pc+c+k)].b3 = '-';
                }
                else{
                    board.inst[checkCircular(pc+c+k)].b3 = 'd';
                }

                int f = checkCircular(pc+c+k);
                board.inst[f].a = add1;
                board.inst[f].b = add2;
                result = changeValues(board.inst[f].fullinst, board.inst[f].inst, board, f, board.inst[f].a2, board.inst[f].a3, board.inst[f].a, board.inst[f].b2, board.inst[f].b3, board.inst[f].b);
            }
            if(a2 == 'd' && b2 == 'd' && a3 == '-' && b3 == '-'){
                int c = Integer.parseInt(b);
                if(board.inst[pc].b3 == '-'){
                    c = -c;
                }
                int d = Integer.parseInt(a);
                if(board.inst[pc].a3 == '-'){
                    d = -d;
                }
                int e = Integer.parseInt(board.inst[checkCircular(pc+d)].a);
                if(board.inst[checkCircular(pc+d)].a3 == '-'){
                    e = -e;
                }
                int g = Integer.parseInt(board.inst[checkCircular(pc+d)].b);
                if(board.inst[checkCircular(pc+d)].b3 == '-'){
                    g = -g;
                }
                int k = Integer.parseInt(board.inst[checkCircular(pc+c)].b);
                if(board.inst[checkCircular(pc+c)].b3 == '-'){
                    k = -k;
                }
                int l = Integer.parseInt(board.inst[checkCircular(pc+c)].a);
                if(board.inst[checkCircular(pc+c)].a3 == '-'){
                    l = -l;
                }

                int h = Math.abs(l+e);
                String add1 = Integer.toString(h);
                if((l+e) < 0){
                    h = -h;
                    board.inst[checkCircular(pc+c)].a3 = '-';
                }
                else{
                    board.inst[checkCircular(pc+c)].a3 = 'd';
                }

                int i = Math.abs(k+g);
                String add2 = Integer.toString(i);
                if((k+g) < 0){
                    l= -l;
                    board.inst[checkCircular(pc+c)].b3 = '-';
                }
                else{
                    board.inst[checkCircular(pc+c)].b3 = 'd';
                }

                int f = checkCircular(pc+c);
                board.inst[f].a = add1;
                board.inst[f].b = add2;
                result = changeValues(board.inst[f].fullinst, board.inst[f].inst, board, f, board.inst[f].a2, board.inst[f].a3, board.inst[f].a, board.inst[f].b2, board.inst[f].b3, board.inst[f].b);
            }
            if(a2 == 'd' && b2 == '@' && a3 == '-' && b3 == '-'){
                int c = Integer.parseInt(b);
                if(board.inst[pc].b3 == '-'){
                    c = -c;
                }
                int d = Integer.parseInt(a);
                if(board.inst[pc].a3 == '-'){
                    d = -d;
                }
                int e = Integer.parseInt(board.inst[checkCircular(pc+c)].b);
                if(board.inst[checkCircular(pc+c)].b3 == '-'){
                    e = -e;
                }
                int g = Integer.parseInt(board.inst[checkCircular(pc+c+e)].a);
                int i = Integer.parseInt(board.inst[checkCircular(pc+c+e)].b);
                int j = Integer.parseInt(board.inst[checkCircular(pc+d)].a);
                int k = Integer.parseInt(board.inst[checkCircular(pc+d)].b);
                if(board.inst[checkCircular(pc+c+e)].a3 == '-'){
                    g = -g;
                }
                if(board.inst[checkCircular(pc+c+e)].b3 == '-'){
                    i = -i;
                }
                if(board.inst[checkCircular(pc+d)].a3 == '-'){
                    j = -j;
                }
                if(board.inst[checkCircular(pc+d)].b3 == '-'){
                    k = -k;
                }

                int h = Math.abs(g+j);
                String add1 = Integer.toString(h);
                if((g+j) < 0){
                    h = -h;
                    board.inst[checkCircular(pc+c+e)].a3 = '-';
                }
                else{
                    board.inst[checkCircular(pc+c+e)].a3 = 'd';
                }

                int l = Math.abs(i+k);
                String add2 = Integer.toString(l);
                if((i+k) < 0){
                    l= -l;
                    board.inst[checkCircular(pc+c+e)].b3 = '-';
                }
                else{
                    board.inst[checkCircular(pc+c+e)].b3 = 'd';
                }

                int f = checkCircular(pc+c+e);
                board.inst[f].a = add1;
                board.inst[f].b = add2;
                result = changeValues(board.inst[f].fullinst, board.inst[f].inst, board, f, board.inst[f].a2, board.inst[f].a3, board.inst[f].a, board.inst[f].b2, board.inst[f].b3, board.inst[f].b);
            }

        }
        else {
            System.out.println("Error");
        }
    }

////////////////////////////////////////////////////////////////////////////////////////////////

    public void SUB(String fullinst, String inst, Board board, int pc, char a2, char a3, String a, char b2, char b3, String b) {
        if((a2 == '#' || a2 == '*' || a2 == 'd') && (b2 == 'd' || b2 == '@') && (a3 == '-' || a3 == 'd') && (b3 == '-' || b3 == 'd')) {
            String result = " ";

            // a3 = d and b3 = d
            if(a2 == '#' && b2 == 'd' && a3 == 'd' && b3 == 'd'){
                int c1 = Integer.parseInt(a);

                int c = Integer.parseInt(b);
                int e = Integer.parseInt(board.inst[checkCircular(pc+c)].b);
                if(board.inst[checkCircular(pc+c)].b3 == '-'){
                    e = -e;
                }
                int g = (e - c1);
                if (g<0){
                    g = -(g);
                    board.inst[checkCircular(pc+c)].b3 = '-';
                }else{
                    board.inst[checkCircular(pc+c)].b3 = 'd';
                }
                String subtract = Integer.toString(g);
                board.inst[checkCircular(pc+c)].b= subtract;
                result = changeValues(board.inst[checkCircular(pc+c)].fullinst, board.inst[checkCircular(pc+c)].inst, board, checkCircular(pc+c), board.inst[checkCircular(pc+c)].a2, board.inst[checkCircular(pc+c)].a3, board.inst[checkCircular(pc+c)].a, board.inst[checkCircular(pc+c)].b2, board.inst[checkCircular(pc+c)].b3, board.inst[checkCircular(pc+c)].b);
            }

            if(a2 == '#' && b2 == '@' && a3 == 'd' && b3 == 'd'){
                int c = Integer.parseInt(b);
                int d = Integer.parseInt(a);
                int e = Integer.parseInt(board.inst[checkCircular(pc+c)].b);
                if(board.inst[checkCircular(pc+c)].b3 == '-'){
                    e = -e;
                }
                int g = Integer.parseInt(board.inst[checkCircular(pc+c+e)].b);
                if(board.inst[checkCircular(pc+c+e)].b3 == '-'){
                    g = -g;
                }
                int h = Math.abs(g-d);
                String subtract = Integer.toString(h);
                if((g-d) < 0){
                    h = -h;
                    board.inst[checkCircular(pc+c+e)].b3 = '-';
                }
                else{
                    board.inst[checkCircular(pc+c+e)].b3 = 'd';
                }
                int f = checkCircular(pc+c+e);
                board.inst[f].b = subtract;
                result = changeValues(board.inst[f].fullinst, board.inst[f].inst, board, f, board.inst[f].a2, board.inst[f].a3, board.inst[f].a, board.inst[f].b2, board.inst[f].b3, board.inst[f].b);
            }

            if(a2 == '*' && b2 == 'd' && a3 == 'd' && b3 == 'd'){
                int c = Integer.parseInt(b);
                int d = Integer.parseInt(a);
                int e = Integer.parseInt(board.inst[checkCircular(pc+d)].a);
                if(board.inst[checkCircular(pc+d)].a3 == '-'){
                    e = -e;
                }
                int g = Integer.parseInt(board.inst[checkCircular(pc+d+e)].a);
                int i = Integer.parseInt(board.inst[checkCircular(pc+d+e)].b);
                int j = Integer.parseInt(board.inst[checkCircular(pc+c)].a);
                int k = Integer.parseInt(board.inst[checkCircular(pc+c)].b);
                if(board.inst[checkCircular(pc+d+e)].a3 == '-'){
                    g = -g;
                }
                if(board.inst[checkCircular(pc+d+e)].b3 == '-'){
                    i = -i;
                }
                if(board.inst[checkCircular(pc+c)].a3 == '-'){
                    j = -j;
                }
                if(board.inst[checkCircular(pc+c)].b3 == '-'){
                    k = -k;
                }

                int h = Math.abs(j-g);
                String subtract1 = Integer.toString(h);
                if((j-g) < 0){
                    h = -h;
                    board.inst[checkCircular(pc+c)].a3 = '-';
                }
                else{
                    board.inst[checkCircular(pc+c)].a3 = 'd';
                }

                int l = Math.abs(k-i);
                String subtract2 = Integer.toString(l);
                if((k-i) < 0){
                    l= -l;
                    board.inst[checkCircular(pc+c)].b3 = '-';
                }
                else{
                    board.inst[checkCircular(pc+c)].b3 = 'd';
                }

                int f = checkCircular(pc+c);
                board.inst[f].a = subtract1;
                board.inst[f].b = subtract2;
                result = changeValues(board.inst[f].fullinst, board.inst[f].inst, board, f, board.inst[f].a2, board.inst[f].a3, board.inst[f].a, board.inst[f].b2, board.inst[f].b3, board.inst[f].b);

            }

            if(a2 == '*' && b2 == '@' && a3 == 'd' && b3 == 'd'){

                int c = Integer.parseInt(b);
                int d = Integer.parseInt(a);
                int e = Integer.parseInt(board.inst[checkCircular(pc+d)].a);
                if(board.inst[checkCircular(pc+d)].a3 == '-'){
                    e = -e;
                }
                int g = Integer.parseInt(board.inst[checkCircular(pc+d+e)].a);
                if(board.inst[checkCircular(pc+d+e)].a3 == '-'){
                    g = -g;
                }
                int i = Integer.parseInt(board.inst[checkCircular(pc+d+e)].b);
                if(board.inst[checkCircular(pc+d+e)].b3 == '-'){
                    i = -i;
                }
                int k = Integer.parseInt(board.inst[checkCircular(pc+c)].b);
                if(board.inst[checkCircular(pc+c)].b3 == '-'){
                    k = -k;
                }
                int m = Integer.parseInt(board.inst[checkCircular(pc+c+k)].a);
                if(board.inst[checkCircular(pc+c+k)].a3 == '-'){
                    m = -m;
                }
                int n = Integer.parseInt(board.inst[checkCircular(pc+c+k)].b);
                if(board.inst[checkCircular(pc+c+k)].b3 == '-'){
                    n = -n;
                }

                int h = Math.abs(m-g);
                String subtract1 = Integer.toString(h);
                if((m-g) < 0){
                    h = -h;
                    board.inst[checkCircular(pc+c+k)].a3 = '-';
                }
                else{
                    board.inst[checkCircular(pc+c+k)].a3 = 'd';
                }

                int l = Math.abs(n-i);
                String subtract2 = Integer.toString(l);
                if((n-i) < 0){
                    l= -l;
                    board.inst[checkCircular(pc+c+k)].b3 = '-';
                }
                else{
                    board.inst[checkCircular(pc+c+k)].b3 = 'd';
                }

                int f = checkCircular(pc+c+k);
                board.inst[f].a = subtract1;
                board.inst[f].b = subtract2;
                result = changeValues(board.inst[f].fullinst, board.inst[f].inst, board, f, board.inst[f].a2, board.inst[f].a3, board.inst[f].a, board.inst[f].b2, board.inst[f].b3, board.inst[f].b);
            }

            if(a2 == 'd' && b2 == 'd' && a3 == 'd' && b3 == 'd'){
                int c = Integer.parseInt(b);
                int d = Integer.parseInt(a);
                int e = Integer.parseInt(board.inst[checkCircular(pc+d)].a);
                if(board.inst[checkCircular(pc+d)].a3 == '-'){
                    e = -e;
                }
                int g = Integer.parseInt(board.inst[checkCircular(pc+d)].b);
                if(board.inst[checkCircular(pc+d)].b3 == '-'){
                    g = -g;
                }
                int k = Integer.parseInt(board.inst[checkCircular(pc+d)].b);
                if(board.inst[checkCircular(pc+d)].b3 == '-'){
                    k = -k;
                }
                int l = Integer.parseInt(board.inst[checkCircular(pc+c)].a);
                if(board.inst[checkCircular(pc+c)].a3 == '-'){
                    l = -l;
                }

                int h = Math.abs(l-e);
                String subtract1 = Integer.toString(h);
                if((l-e) < 0){
                    h = -h;
                    board.inst[checkCircular(pc+c)].a3 = '-';
                }
                else{
                    board.inst[checkCircular(pc+c)].a3 = 'd';
                }

                int i = Math.abs(k-g);
                String subtract2 = Integer.toString(i);
                if((k-g) < 0){
                    l= -l;
                    board.inst[checkCircular(pc+c)].b3 = '-';
                }
                else{
                    board.inst[checkCircular(pc+c)].b3 = 'd';
                }

                int f = checkCircular(pc+c);
                board.inst[f].a = subtract1;
                board.inst[f].b = subtract2;
                result = changeValues(board.inst[f].fullinst, board.inst[f].inst, board, f, board.inst[f].a2, board.inst[f].a3, board.inst[f].a, board.inst[f].b2, board.inst[f].b3, board.inst[f].b);

            }
            if(a2 == 'd' && b2 == '@' && a3 == 'd' && b3 == 'd'){
                int c = Integer.parseInt(b);
                int d = Integer.parseInt(a);
                int e = Integer.parseInt(board.inst[checkCircular(pc+c)].b);
                if(board.inst[checkCircular(pc+c)].b3 == '-'){
                    e = -e;
                }
                int g = Integer.parseInt(board.inst[checkCircular(pc+c+e)].a);
                int i = Integer.parseInt(board.inst[checkCircular(pc+c+e)].b);
                int j = Integer.parseInt(board.inst[checkCircular(pc+d)].a);
                int k = Integer.parseInt(board.inst[checkCircular(pc+d)].b);
                if(board.inst[checkCircular(pc+c+e)].a3 == '-'){
                    g = -g;
                }
                if(board.inst[checkCircular(pc+c+e)].b3 == '-'){
                    i = -i;
                }
                if(board.inst[checkCircular(pc+d)].a3 == '-'){
                    j = -j;
                }
                if(board.inst[checkCircular(pc+d)].b3 == '-'){
                    k = -k;
                }

                int h = Math.abs(g-j);
                String subtract1 = Integer.toString(h);
                if((g-j) < 0){
                    h = -h;
                    board.inst[checkCircular(pc+c+e)].a3 = '-';
                }
                else{
                    board.inst[checkCircular(pc+c+e)].a3 = 'd';
                }

                int l = Math.abs(i-k);
                String subtract2 = Integer.toString(l);
                if((i-k) < 0){
                    l= -l;
                    board.inst[checkCircular(pc+c+e)].b3 = '-';
                }
                else{
                    board.inst[checkCircular(pc+c+e)].b3 = 'd';
                }

                int f = checkCircular(pc+c+e);
                board.inst[f].a = subtract1;
                board.inst[f].b = subtract2;
                result = changeValues(board.inst[f].fullinst, board.inst[f].inst, board, f, board.inst[f].a2, board.inst[f].a3, board.inst[f].a, board.inst[f].b2, board.inst[f].b3, board.inst[f].b);
            }

            // a3 = - and b3 = d
            if(a2 == '#' && b2 == 'd' && a3 == '-' && b3 == 'd'){
                int c1 = Integer.parseInt(a);
                if(board.inst[pc].a3 == '-'){
                    c1 = -c1;
                }
                int c = Integer.parseInt(b);
                int e = Integer.parseInt(board.inst[checkCircular(pc+c)].b);
                if(board.inst[checkCircular(pc+c)].b3 == '-'){
                    e = -e;
                }

                int g = (e - c1);

                if (g<0){
                    g = -g;
                    board.inst[checkCircular(pc+c)].b3 = '-';
                }else{
                    board.inst[checkCircular(pc+c)].b3 = 'd';
                }
                String subtract = Integer.toString(g);
                board.inst[checkCircular(pc+c)].b= subtract;
                result = changeValues(board.inst[checkCircular(pc+c)].fullinst, board.inst[checkCircular(pc+c)].inst, board, checkCircular(pc+c), board.inst[checkCircular(pc+c)].a2, board.inst[checkCircular(pc+c)].a3, board.inst[checkCircular(pc+c)].a, board.inst[checkCircular(pc+c)].b2, board.inst[checkCircular(pc+c)].b3, board.inst[checkCircular(pc+c)].b);
            }
            if(a2 == '#' && b2 == '@' && a3 == '-' && b3 == 'd'){
                int c = Integer.parseInt(b);
                int d = Integer.parseInt(a);
                if(board.inst[pc].a3 == '-'){
                    d = -d;
                }
                int e = Integer.parseInt(board.inst[checkCircular(pc+c)].b);
                if(board.inst[checkCircular(pc+c)].b3 == '-'){
                    e = -e;
                }
                int g = Integer.parseInt(board.inst[checkCircular(pc+c+e)].b);
                if(board.inst[checkCircular(pc+c+e)].b3 == '-'){
                    g = -g;
                }

                int h = Math.abs(g-d);
                String subtract = Integer.toString(h);
                if((g-d) < 0){
                    h = -h;
                    board.inst[checkCircular(pc+c+e)].b3 = '-';
                }
                else{
                    board.inst[checkCircular(pc+c+e)].b3 = 'd';
                }
                int f = checkCircular(pc+c+e);
                board.inst[f].b = subtract;
                result = changeValues(board.inst[f].fullinst, board.inst[f].inst, board, f, board.inst[f].a2, board.inst[f].a3, board.inst[f].a, board.inst[f].b2, board.inst[f].b3, board.inst[f].b);
            }
            if(a2 == '*' && b2 == 'd' && a3 == '-' && b3 == 'd'){
                int c = Integer.parseInt(b);
                int d = Integer.parseInt(a);
                if(board.inst[pc].a3 == '-'){
                    d = -d;
                }
                int e = Integer.parseInt(board.inst[checkCircular(pc+d)].a);
                if(board.inst[checkCircular(pc+d)].a3 == '-'){
                    e = -e;
                }
                int g = Integer.parseInt(board.inst[checkCircular(pc+d+e)].a);
                int i = Integer.parseInt(board.inst[checkCircular(pc+d+e)].b);
                int j = Integer.parseInt(board.inst[checkCircular(pc+c)].a);
                int k = Integer.parseInt(board.inst[checkCircular(pc+c)].b);
                if(board.inst[checkCircular(pc+d+e)].a3 == '-'){
                    g = -g;
                }
                if(board.inst[checkCircular(pc+d+e)].b3 == '-'){
                    i = -i;
                }
                if(board.inst[checkCircular(pc+c)].a3 == '-'){
                    j = -j;
                }
                if(board.inst[checkCircular(pc+c)].b3 == '-'){
                    k = -k;
                }

                int h = Math.abs(j-g);
                String subtract1 = Integer.toString(h);
                if((j-g) < 0){
                    h = -h;
                    board.inst[checkCircular(pc+c)].a3 = '-';
                }
                else{
                    board.inst[checkCircular(pc+c)].a3 = 'd';
                }

                int l = Math.abs(k-i);
                String subtract2 = Integer.toString(l);
                if((k-i) < 0){
                    l= -l;
                    board.inst[checkCircular(pc+c)].b3 = '-';
                }
                else{
                    board.inst[checkCircular(pc+c)].b3 = 'd';
                }

                int f = checkCircular(pc+c);
                board.inst[f].a = subtract1;
                board.inst[f].b = subtract2;
                result = changeValues(board.inst[f].fullinst, board.inst[f].inst, board, f, board.inst[f].a2, board.inst[f].a3, board.inst[f].a, board.inst[f].b2, board.inst[f].b3, board.inst[f].b);
            }
            if(a2 == '*' && b2 == '@' && a3 == '-' && b3 == 'd'){
                int c = Integer.parseInt(b);
                int d = Integer.parseInt(a);
                if(board.inst[pc].a3 == '-'){
                    d = -d;
                }
                int e = Integer.parseInt(board.inst[checkCircular(pc+d)].a);
                if(board.inst[checkCircular(pc+d)].a3 == '-'){
                    e = -e;
                }
                int g = Integer.parseInt(board.inst[checkCircular(pc+d+e)].a);
                if(board.inst[checkCircular(pc+d+e)].a3 == '-'){
                    g = -g;
                }
                int i = Integer.parseInt(board.inst[checkCircular(pc+d+e)].b);
                if(board.inst[checkCircular(pc+d+e)].b3 == '-'){
                    i = -i;
                }
                int k = Integer.parseInt(board.inst[checkCircular(pc+c)].b);
                if(board.inst[checkCircular(pc+c)].b3 == '-'){
                    k = -k;
                }
                int m = Integer.parseInt(board.inst[checkCircular(pc+c+k)].a);
                if(board.inst[checkCircular(pc+c+k)].a3 == '-'){
                    m = -m;
                }
                int n = Integer.parseInt(board.inst[pc+c+k].b);
                if(board.inst[checkCircular(pc+c+k)].b3 == '-'){
                    n = -n;
                }

                int h = Math.abs(m-g);
                String subtract1 = Integer.toString(h);
                if((m-g) < 0){
                    h = -h;
                    board.inst[checkCircular(pc+c+k)].a3 = '-';
                }
                else{
                    board.inst[checkCircular(pc+c+k)].a3 = 'd';
                }

                int l = Math.abs(n-i);
                String subtract2 = Integer.toString(l);
                if((n-i) < 0){
                    l= -l;
                    board.inst[checkCircular(pc+c+k)].b3 = '-';
                }
                else{
                    board.inst[checkCircular(pc+c+k)].b3 = 'd';
                }

                int f = checkCircular(pc+c+k);
                board.inst[f].a = subtract1;
                board.inst[f].b = subtract2;
                result = changeValues(board.inst[f].fullinst, board.inst[f].inst, board, f, board.inst[f].a2, board.inst[f].a3, board.inst[f].a, board.inst[f].b2, board.inst[f].b3, board.inst[f].b);
            }
            if(a2 == 'd' && b2 == 'd' && a3 == '-' && b3 == 'd'){
                int c = Integer.parseInt(b);
                int d = Integer.parseInt(a);
                if(board.inst[pc].a3 == '-'){
                    d = -d;
                }
                int e = Integer.parseInt(board.inst[checkCircular(pc+d)].a);
                if(board.inst[checkCircular(pc+d)].a3 == '-'){
                    e = -e;
                }
                int g = Integer.parseInt(board.inst[checkCircular(pc+d)].b);
                if(board.inst[checkCircular(pc+d)].b3 == '-'){
                    g = -g;
                }
                int k = Integer.parseInt(board.inst[checkCircular(pc+c)].b);
                if(board.inst[checkCircular(pc+c)].b3 == '-'){
                    k = -k;
                }
                int l = Integer.parseInt(board.inst[checkCircular(pc+c)].a);
                if(board.inst[checkCircular(pc+c)].a3 == '-'){
                    l = -l;
                }

                int h = Math.abs(l-e);
                String subtract1 = Integer.toString(h);
                if((l-e) < 0){
                    h = -h;
                    board.inst[checkCircular(pc+c)].a3 = '-';
                }
                else{
                    board.inst[checkCircular(pc+c)].a3 = 'd';
                }

                int i = Math.abs(k-g);
                String subtract2 = Integer.toString(i);
                if((k-g) < 0){
                    l= -l;
                    board.inst[checkCircular(pc+c)].b3 = '-';
                }
                else{
                    board.inst[checkCircular(pc+c)].b3 = 'd';
                }

                int f = checkCircular(pc+c);
                board.inst[f].a = subtract1;
                board.inst[f].b = subtract2;
                result = changeValues(board.inst[f].fullinst, board.inst[f].inst, board, f, board.inst[f].a2, board.inst[f].a3, board.inst[f].a, board.inst[f].b2, board.inst[f].b3, board.inst[f].b);
            }
            if(a2 == 'd' && b2 == '@' && a3 == '-' && b3 == 'd'){
                int c = Integer.parseInt(b);
                int d = Integer.parseInt(a);
                if(board.inst[pc].a3 == '-'){
                    d = -d;
                }
                int e = Integer.parseInt(board.inst[checkCircular(pc+c)].b);
                if(board.inst[checkCircular(pc+c)].b3 == '-'){
                    e = -e;
                }
                int g = Integer.parseInt(board.inst[checkCircular(pc+c+e)].a);
                int i = Integer.parseInt(board.inst[checkCircular(pc+c+e)].b);
                int j = Integer.parseInt(board.inst[checkCircular(pc+d)].a);
                int k = Integer.parseInt(board.inst[checkCircular(pc+d)].b);
                if(board.inst[checkCircular(pc+c+e)].a3 == '-'){
                    g = -g;
                }
                if(board.inst[checkCircular(pc+c+e)].b3 == '-'){
                    i = -i;
                }
                if(board.inst[checkCircular(pc+d)].a3 == '-'){
                    j = -j;
                }
                if(board.inst[checkCircular(pc+d)].b3 == '-'){
                    k = -k;
                }

                int h = Math.abs(g-j);
                String subtract1 = Integer.toString(h);
                if((g-j) < 0){
                    h = -h;
                    board.inst[checkCircular(pc+c+e)].a3 = '-';
                }
                else{
                    board.inst[checkCircular(pc+c+e)].a3 = 'd';
                }

                int l = Math.abs(i-k);
                String subtract2 = Integer.toString(l);
                if((i-k) < 0){
                    l= -l;
                    board.inst[checkCircular(pc+c+e)].b3 = '-';
                }
                else{
                    board.inst[checkCircular(pc+c+e)].b3 = 'd';
                }

                int f = checkCircular(pc+c+e);
                board.inst[f].a = subtract1;
                board.inst[f].b = subtract2;
                result = changeValues(board.inst[f].fullinst, board.inst[f].inst, board, f, board.inst[f].a2, board.inst[f].a3, board.inst[f].a, board.inst[f].b2, board.inst[f].b3, board.inst[f].b);
            }

            // a3 = d and b3 = -
            if(a2 == '#' && b2 == 'd' && a3 == 'd' && b3 == '-'){
                int c1 = Integer.parseInt(a);
                int c = Integer.parseInt(b);
                if(board.inst[pc].b3 == '-'){
                    c = -c;
                }
                int e = Integer.parseInt(board.inst[checkCircular(pc+c)].b);
                if(board.inst[checkCircular(pc+c)].b3 == '-'){
                    e = -e;
                }

                int g = (e - c1);

                if (g<0){
                    g = -(g);
                    board.inst[checkCircular(pc+c)].b3 = '-';
                }
                else{
                    board.inst[checkCircular(pc+c)].b3 = 'd';
                }
                String subtract = Integer.toString(g);
                board.inst[checkCircular(pc+c)].b= subtract;
                result = changeValues(board.inst[checkCircular(pc+c)].fullinst, board.inst[checkCircular(pc+c)].inst, board, checkCircular(pc+c), board.inst[checkCircular(pc+c)].a2, board.inst[checkCircular(pc+c)].a3, board.inst[checkCircular(pc+c)].a, board.inst[checkCircular(pc+c)].b2, board.inst[checkCircular(pc+c)].b3, board.inst[checkCircular(pc+c)].b);
            }
            if(a2 == '#' && b2 == '@' && a3 == 'd' && b3 == '-'){
                int c = Integer.parseInt(b);
                if(board.inst[pc].b3 == '-'){
                    c = -c;
                }
                int d = Integer.parseInt(a);
                int e = Integer.parseInt(board.inst[checkCircular(pc+c)].b);
                if(board.inst[checkCircular(pc+c)].b3 == '-'){
                    e = -e;
                }
                int g = Integer.parseInt(board.inst[checkCircular(pc+c+e)].b);
                if(board.inst[checkCircular(pc+c+e)].b3 == '-'){
                    g = -g;
                }
                int h = Math.abs(g-d);
                String subtract = Integer.toString(h);
                if((g-d) < 0){
                    h = -h;
                    board.inst[checkCircular(pc+c+e)].b3 = '-';
                }
                else{
                    board.inst[checkCircular(pc+c+e)].b3 = 'd';
                }
                int f = checkCircular(pc+c+e);
                board.inst[f].b = subtract;
                result = changeValues(board.inst[f].fullinst, board.inst[f].inst, board, f, board.inst[f].a2, board.inst[f].a3, board.inst[f].a, board.inst[f].b2, board.inst[f].b3, board.inst[f].b);
            }
            if(a2 == '*' && b2 == 'd' && a3 == 'd' && b3 == '-'){
                int c = Integer.parseInt(b);
                if(board.inst[pc].b3 == '-'){
                    c = -c;
                }
                int d = Integer.parseInt(a);
                int e = Integer.parseInt(board.inst[checkCircular(pc+d)].a);
                if(board.inst[checkCircular(pc+d)].a3 == '-'){
                    e = -e;
                }
                int g = Integer.parseInt(board.inst[checkCircular(pc+d+e)].a);
                int i = Integer.parseInt(board.inst[checkCircular(pc+d+e)].b);
                int j = Integer.parseInt(board.inst[checkCircular(pc+c)].a);
                int k = Integer.parseInt(board.inst[checkCircular(pc+c)].b);
                if(board.inst[checkCircular(pc+d+e)].a3 == '-'){
                    g = -g;
                }
                if(board.inst[checkCircular(pc+d+e)].b3 == '-'){
                    i = -i;
                }
                if(board.inst[checkCircular(pc+c)].a3 == '-'){
                    j = -j;
                }
                if(board.inst[checkCircular(pc+c)].b3 == '-'){
                    k = -k;
                }

                int h = Math.abs(j-g);
                String subtract1 = Integer.toString(h);
                if((j-g) < 0){
                    h = -h;
                    board.inst[checkCircular(pc+c)].a3 = '-';
                }
                else{
                    board.inst[checkCircular(pc+c)].a3 = 'd';
                }

                int l = Math.abs(k-i);
                String subtract2 = Integer.toString(l);
                if((k-i) < 0){
                    l= -l;
                    board.inst[checkCircular(pc+c)].b3 = '-';
                }
                else{
                    board.inst[checkCircular(pc+c)].b3 = 'd';
                }

                int f = checkCircular(pc+c);
                board.inst[f].a = subtract1;
                board.inst[f].b = subtract2;
                result = changeValues(board.inst[f].fullinst, board.inst[f].inst, board, f, board.inst[f].a2, board.inst[f].a3, board.inst[f].a, board.inst[f].b2, board.inst[f].b3, board.inst[f].b);
            }
            if(a2 == '*' && b2 == '@' && a3 == 'd' && b3 == '-'){
                int c = Integer.parseInt(b);
                if(board.inst[pc].b3 == '-'){
                    c = -c;
                }
                int d = Integer.parseInt(a);
                int e = Integer.parseInt(board.inst[checkCircular(pc+d)].a);
                if(board.inst[checkCircular(pc+d)].a3 == '-'){
                    e = -e;
                }
                int g = Integer.parseInt(board.inst[checkCircular(pc+d+e)].a);
                if(board.inst[checkCircular(pc+d+e)].a3 == '-'){
                    g = -g;
                }
                int i = Integer.parseInt(board.inst[checkCircular(pc+d+e)].b);
                if(board.inst[checkCircular(pc+d+e)].b3 == '-'){
                    i = -i;
                }
                int k = Integer.parseInt(board.inst[checkCircular(pc+c)].b);
                if(board.inst[checkCircular(pc+c)].b3 == '-'){
                    k = -k;
                }
                int m = Integer.parseInt(board.inst[checkCircular(pc+c+k)].a);
                if(board.inst[checkCircular(pc+c+k)].a3 == '-'){
                    m = -m;
                }
                int n = Integer.parseInt(board.inst[checkCircular(pc+c+k)].b);
                if(board.inst[checkCircular(pc+c+k)].b3 == '-'){
                    n = -n;
                }

                int h = Math.abs(m-g);
                String subtract1 = Integer.toString(h);
                if((m-g) < 0){
                    h = -h;
                    board.inst[checkCircular(pc+c+k)].a3 = '-';
                }
                else{
                    board.inst[checkCircular(pc+c+k)].a3 = 'd';
                }

                int l = Math.abs(n-i);
                String subtract2 = Integer.toString(l);
                if((n-i) < 0){
                    l= -l;
                    board.inst[checkCircular(pc+c+k)].b3 = '-';
                }
                else{
                    board.inst[checkCircular(pc+c+k)].b3 = 'd';
                }

                int f = checkCircular(pc+c+k);
                board.inst[f].a = subtract1;
                board.inst[f].b = subtract2;
                result = changeValues(board.inst[f].fullinst, board.inst[f].inst, board, f, board.inst[f].a2, board.inst[f].a3, board.inst[f].a, board.inst[f].b2, board.inst[f].b3, board.inst[f].b);
            }
            if(a2 == 'd' && b2 == 'd' && a3 == 'd' && b3 == '-'){
                int c = Integer.parseInt(b);
                if(board.inst[pc].b3 == '-'){
                    c = -c;
                }
                int d = Integer.parseInt(a);
                int e = Integer.parseInt(board.inst[checkCircular(pc+d)].a);
                if(board.inst[checkCircular(pc+d)].a3 == '-'){
                    e = -e;
                }
                int g = Integer.parseInt(board.inst[checkCircular(pc+d)].b);
                if(board.inst[checkCircular(pc+d)].b3 == '-'){
                    g = -g;
                }
                int k = Integer.parseInt(board.inst[checkCircular(pc+c)].b);
                if(board.inst[checkCircular(pc+c)].b3 == '-'){
                    k = -k;
                }
                int l = Integer.parseInt(board.inst[checkCircular(pc+c)].a);
                if(board.inst[checkCircular(pc+c)].a3 == '-'){
                    l = -l;
                }

                int h = Math.abs(l-e);
                String subtract1 = Integer.toString(h);
                if((l-e) < 0){
                    h = -h;
                    board.inst[checkCircular(pc+c)].a3 = '-';
                }
                else{
                    board.inst[checkCircular(pc+c)].a3 = 'd';
                }

                int i = Math.abs(k-g);
                String subtract2 = Integer.toString(i);
                if((k-g) < 0){
                    l= -l;
                    board.inst[checkCircular(pc+c)].b3 = '-';
                }
                else{
                    board.inst[checkCircular(pc+c)].b3 = 'd';
                }

                int f = checkCircular(pc+c);
                board.inst[f].a = subtract1;
                board.inst[f].b = subtract2;
                result = changeValues(board.inst[f].fullinst, board.inst[f].inst, board, f, board.inst[f].a2, board.inst[f].a3, board.inst[f].a, board.inst[f].b2, board.inst[f].b3, board.inst[f].b);
            }
            if(a2 == 'd' && b2 == '@' && a3 == 'd' && b3 == '-'){
                int c = Integer.parseInt(b);
                if(board.inst[pc].b3 == '-'){
                    c = -c;
                }
                int d = Integer.parseInt(a);
                int e = Integer.parseInt(board.inst[checkCircular(pc+c)].b);
                if(board.inst[checkCircular(pc+c)].b3 == '-'){
                    e = -e;
                }
                int g = Integer.parseInt(board.inst[checkCircular(pc+c+e)].a);
                int i = Integer.parseInt(board.inst[checkCircular(pc+c+e)].b);
                int j = Integer.parseInt(board.inst[checkCircular(pc+d)].a);
                int k = Integer.parseInt(board.inst[checkCircular(pc+d)].b);
                if(board.inst[checkCircular(pc+c+e)].a3 == '-'){
                    g = -g;
                }
                if(board.inst[checkCircular(pc+c+e)].b3 == '-'){
                    i = -i;
                }
                if(board.inst[checkCircular(pc+d)].a3 == '-'){
                    j = -j;
                }
                if(board.inst[checkCircular(pc+d)].b3 == '-'){
                    k = -k;
                }

                int h = Math.abs(g-j);
                String subtract1 = Integer.toString(h);
                if((g-j) < 0){
                    h = -h;
                    board.inst[checkCircular(pc+c+e)].a3 = '-';
                }
                else{
                    board.inst[checkCircular(pc+c+e)].a3 = 'd';
                }

                int l = Math.abs(i-k);
                String subtract2 = Integer.toString(l);
                if((i-k) < 0){
                    l= -l;
                    board.inst[checkCircular(pc+c+e)].b3 = '-';
                }
                else{
                    board.inst[checkCircular(pc+c+e)].b3 = 'd';
                }

                int f = checkCircular(pc+c+e);
                board.inst[f].a = subtract1;
                board.inst[f].b = subtract2;
                result = changeValues(board.inst[f].fullinst, board.inst[f].inst, board, f, board.inst[f].a2, board.inst[f].a3, board.inst[f].a, board.inst[f].b2, board.inst[f].b3, board.inst[f].b);
            }

            // a3 = - and b3 = -
            if(a2 == '#' && b2 == 'd' && a3 == '-' && b3 == '-'){
                int c1 = Integer.parseInt(a);
                if(board.inst[pc].b3 == '-'){
                    c1 = -c1;
                }
                int c = Integer.parseInt(b);
                if(board.inst[pc].b3 == '-'){
                    c = -c;
                }
                int e = Integer.parseInt(board.inst[checkCircular(pc+c)].b);
                if(board.inst[checkCircular(pc+c)].b3 == '-'){
                    e = -e;
                }

                int g = (e - c1);

                if (g<0){
                    g = -(g);
                    board.inst[checkCircular(pc+c)].b3 = '-';
                }
                else{
                    board.inst[checkCircular(pc+c)].b3 = 'd';
                }
                String subtract = Integer.toString(g);
                board.inst[checkCircular(pc+c)].b= subtract;
                result = changeValues(board.inst[checkCircular(pc+c)].fullinst, board.inst[checkCircular(pc+c)].inst, board, checkCircular(pc+c), board.inst[checkCircular(pc+c)].a2, board.inst[checkCircular(pc+c)].a3, board.inst[checkCircular(pc+c)].a, board.inst[checkCircular(pc+c)].b2, board.inst[checkCircular(pc+c)].b3, board.inst[checkCircular(pc+c)].b);

            }
            if(a2 == '#' && b2 == '@' && a3 == '-' && b3 == '-'){
                int c = Integer.parseInt(b);
                if(board.inst[pc].b3 == '-'){
                    c = -c;
                }
                int d = Integer.parseInt(a);
                if(board.inst[pc].a3 == '-'){
                    d = -d;
                }
                int e = Integer.parseInt(board.inst[checkCircular(pc+c)].b);
                if(board.inst[checkCircular(pc+c)].b3 == '-'){
                    e = -e;
                }
                int g = Integer.parseInt(board.inst[checkCircular(pc+c+e)].b);
                if(board.inst[checkCircular(pc+c+e)].b3 == '-'){
                    g = -g;
                }
                int h = Math.abs(g-d);
                String subtract = Integer.toString(h);
                if((g-d) < 0){
                    h = -h;
                    board.inst[checkCircular(pc+c+e)].b3 = '-';
                }
                else{
                    board.inst[checkCircular(pc+c+e)].b3 = 'd';
                }
                int f = checkCircular(pc+c+e);
                board.inst[f].b = subtract;
                result = changeValues(board.inst[f].fullinst, board.inst[f].inst, board, f, board.inst[f].a2, board.inst[f].a3, board.inst[f].a, board.inst[f].b2, board.inst[f].b3, board.inst[f].b);
            }
            if(a2 == '*' && b2 == 'd' && a3 == '-' && b3 == '-'){
                int c = Integer.parseInt(b);
                if(board.inst[pc].b3 == '-'){
                    c = -c;
                }
                int d = Integer.parseInt(a);
                if(board.inst[pc].a3 == '-'){
                    d = -d;
                }
                int e = Integer.parseInt(board.inst[checkCircular(pc+d)].a);
                if(board.inst[checkCircular(pc+d)].a3 == '-'){
                    e = -e;
                }
                int g = Integer.parseInt(board.inst[checkCircular(pc+d+e)].a);
                int i = Integer.parseInt(board.inst[checkCircular(pc+d+e)].b);
                int j = Integer.parseInt(board.inst[checkCircular(pc+c)].a);
                int k = Integer.parseInt(board.inst[checkCircular(pc+c)].b);
                if(board.inst[checkCircular(pc+d+e)].a3 == '-'){
                    g = -g;
                }
                if(board.inst[checkCircular(pc+d+e)].b3 == '-'){
                    i = -i;
                }
                if(board.inst[checkCircular(pc+c)].a3 == '-'){
                    j = -j;
                }
                if(board.inst[checkCircular(pc+c)].b3 == '-'){
                    k = -k;
                }

                int h = Math.abs(j-g);
                String subtract1 = Integer.toString(h);
                if((j-g) < 0){
                    h = -h;
                    board.inst[checkCircular(pc+c)].a3 = '-';
                }
                else{
                    board.inst[checkCircular(pc+c)].a3 = 'd';
                }

                int l = Math.abs(k-i);
                String subtract2 = Integer.toString(l);
                if((k-i) < 0){
                    l= -l;
                    board.inst[checkCircular(pc+c)].b3 = '-';
                }
                else{
                    board.inst[checkCircular(pc+c)].b3 = 'd';
                }

                int f = checkCircular(pc+c);
                board.inst[f].a = subtract1;
                board.inst[f].b = subtract2;
                result = changeValues(board.inst[f].fullinst, board.inst[f].inst, board, f, board.inst[f].a2, board.inst[f].a3, board.inst[f].a, board.inst[f].b2, board.inst[f].b3, board.inst[f].b);
            }
            if(a2 == '*' && b2 == '@' && a3 == '-' && b3 == '-'){
                int c = Integer.parseInt(b);
                if(board.inst[pc].b3 == '-'){
                    c = -c;
                }
                int d = Integer.parseInt(a);
                if(board.inst[pc].a3 == '-'){
                    d = -d;
                }
                int e = Integer.parseInt(board.inst[checkCircular(pc+d)].a);
                if(board.inst[checkCircular(pc+d)].a3 == '-'){
                    e = -e;
                }
                int g = Integer.parseInt(board.inst[checkCircular(pc+d+e)].a);
                if(board.inst[checkCircular(pc+d+e)].a3 == '-'){
                    g = -g;
                }
                int i = Integer.parseInt(board.inst[checkCircular(pc+d+e)].b);
                if(board.inst[checkCircular(pc+d+e)].b3 == '-'){
                    i = -i;
                }
                int k = Integer.parseInt(board.inst[checkCircular(pc+c)].b);
                if(board.inst[checkCircular(pc+c)].b3 == '-'){
                    k = -k;
                }
                int m = Integer.parseInt(board.inst[checkCircular(pc+c+k)].a);
                if(board.inst[checkCircular(pc+c+k)].a3 == '-'){
                    m = -m;
                }
                int n = Integer.parseInt(board.inst[checkCircular(pc+c+k)].b);
                if(board.inst[checkCircular(pc+c+k)].b3 == '-'){
                    n = -n;
                }

                int h = Math.abs(m-g);
                String subtract1 = Integer.toString(h);
                if((m-g) < 0){
                    h = -h;
                    board.inst[checkCircular(pc+c+k)].a3 = '-';
                }
                else{
                    board.inst[checkCircular(pc+c+k)].a3 = 'd';
                }

                int l = Math.abs(n-i);
                String subtract2 = Integer.toString(l);
                if((n-i) < 0){
                    l= -l;
                    board.inst[checkCircular(pc+c+k)].b3 = '-';
                }
                else{
                    board.inst[checkCircular(pc+c+k)].b3 = 'd';
                }

                int f = checkCircular(pc+c+k);
                board.inst[f].a = subtract1;
                board.inst[f].b = subtract2;
                result = changeValues(board.inst[f].fullinst, board.inst[f].inst, board, f, board.inst[f].a2, board.inst[f].a3, board.inst[f].a, board.inst[f].b2, board.inst[f].b3, board.inst[f].b);
            }
            if(a2 == 'd' && b2 == 'd' && a3 == '-' && b3 == '-'){
                int c = Integer.parseInt(b);
                if(board.inst[pc].b3 == '-'){
                    c = -c;
                }
                int d = Integer.parseInt(a);
                if(board.inst[pc].a3 == '-'){
                    d = -d;
                }
                int e = Integer.parseInt(board.inst[checkCircular(pc+d)].a);
                if(board.inst[checkCircular(pc+d)].a3 == '-'){
                    e = -e;
                }
                int g = Integer.parseInt(board.inst[checkCircular(pc+d)].b);
                if(board.inst[checkCircular(pc+d)].b3 == '-'){
                    g = -g;
                }
                int k = Integer.parseInt(board.inst[checkCircular(pc+c)].b);
                if(board.inst[checkCircular(pc+c)].b3 == '-'){
                    k = -k;
                }
                int l = Integer.parseInt(board.inst[checkCircular(pc+c)].a);
                if(board.inst[checkCircular(pc+c)].a3 == '-'){
                    l = -l;
                }

                int h = Math.abs(l-e);
                String subtract1 = Integer.toString(h);
                if((l-e) < 0){
                    h = -h;
                    board.inst[checkCircular(pc+c)].a3 = '-';
                }
                else{
                    board.inst[checkCircular(pc+c)].a3 = 'd';
                }

                int i = Math.abs(k-g);
                String subtract2 = Integer.toString(i);
                if((k-g) < 0){
                    l= -l;
                    board.inst[checkCircular(pc+c)].b3 = '-';
                }
                else{
                    board.inst[checkCircular(pc+c)].b3 = 'd';
                }

                int f = checkCircular(pc+c);
                board.inst[f].a = subtract1;
                board.inst[f].b = subtract2;
                result = changeValues(board.inst[f].fullinst, board.inst[f].inst, board, f, board.inst[f].a2, board.inst[f].a3, board.inst[f].a, board.inst[f].b2, board.inst[f].b3, board.inst[f].b);
            }
            if(a2 == 'd' && b2 == '@' && a3 == '-' && b3 == '-'){
                int c = Integer.parseInt(b);
                if(board.inst[pc].a3 == '-'){
                    c = -c;
                }
                int d = Integer.parseInt(a);
                if(board.inst[pc].a3 == '-'){
                    d = -d;
                }
                int e = Integer.parseInt(board.inst[checkCircular(pc+c)].b);
                if(board.inst[checkCircular(pc+c)].b3 == '-'){
                    e = -e;
                }
                int g = Integer.parseInt(board.inst[checkCircular(pc+c+e)].a);
                int i = Integer.parseInt(board.inst[checkCircular(pc+c+e)].b);
                int j = Integer.parseInt(board.inst[checkCircular(pc+d)].a);
                int k = Integer.parseInt(board.inst[checkCircular(pc+d)].b);
                if(board.inst[checkCircular(pc+c+e)].a3 == '-'){
                    g = -g;
                }
                if(board.inst[checkCircular(pc+c+e)].b3 == '-'){
                    i = -i;
                }
                if(board.inst[checkCircular(pc+d)].a3 == '-'){
                    j = -j;
                }
                if(board.inst[checkCircular(pc+d)].b3 == '-'){
                    k = -k;
                }

                int h = Math.abs(g-j);
                String subtract1 = Integer.toString(h);
                if((g-j) < 0){
                    h = -h;
                    board.inst[checkCircular(pc+c+e)].a3 = '-';
                }
                else{
                    board.inst[checkCircular(pc+c+e)].a3 = 'd';
                }

                int l = Math.abs(i-k);
                String subtract2 = Integer.toString(l);
                if((i-k) < 0){
                    l= -l;
                    board.inst[checkCircular(pc+c+e)].b3 = '-';
                }
                else{
                    board.inst[checkCircular(pc+c+e)].b3 = 'd';
                }

                int f = checkCircular(pc+c+e);
                board.inst[f].a = subtract1;
                board.inst[f].b = subtract2;
                result = changeValues(board.inst[f].fullinst, board.inst[f].inst, board, f, board.inst[f].a2, board.inst[f].a3, board.inst[f].a, board.inst[f].b2, board.inst[f].b3, board.inst[f].b);
            }
        }
        else {
            System.out.println("Error");
        }
    }

////////////////////////////////////////////////////////////////////////////////////////////////

    public int JMP(String fullinst, String inst, Board board, int pc, char a2, char a3, String a) {
        if((a2 == '*' || a2 == 'd') && (a3 == '-' || a3 == 'd')){

            // a3 = d
            if(a2 == '*' && a3 == 'd'){
                int c = Integer.parseInt(a);
                int d = Integer.parseInt(board.inst[checkCircular(pc+c)].a);
                if (board.inst[checkCircular(pc+c)].a3 == '-'){
                    d = -d;
                }
                pc = checkCircular(pc+d);
            }
            if(a2 == 'd' && a3 == 'd'){
                int c = Integer.parseInt(a);
                pc = checkCircular(pc+c);
            }

            // a3 = -
            if(a2 == '*' && a3 == '-'){
                int c = Integer.parseInt(a);
                if (board.inst[pc].a3 == '-'){
                    c = -c;
                }
                int d = Integer.parseInt(board.inst[checkCircular(pc+c)].a);
                if (board.inst[checkCircular(pc+c)].a3 == '-'){
                    d = -d;
                }
                pc = checkCircular(pc+d);
            }
            if(a2 == 'd' && a3 == '-'){
                int c = Integer.parseInt(a);
                if (board.inst[pc].a3 == '-'){
                    c = -c;
                }
                pc = checkCircular(pc+c);
            }
            return pc;
        }
        else {
            System.out.println("Error");
        }
        return pc;
    }

////////////////////////////////////////////////////////////////////////////////////////////////

    public int JMZ(String fullinst, String inst, Board board, int pc, char a2, char a3, String a, char b2, char b3, String b) {
        if((a2 == '*' || a2 == 'd') && (b2 == '#' || b2 == 'd' || b2 == '@') && (a3 == '-' || a3 == 'd') && (b3 == '-' || b3 == 'd')) {

            // a3 = d and b3 = d
            if(a2 == '*' && b2 == '#' && a3 == 'd' && b3 == 'd'){
                if(b == "0") {
                    int c = Integer.parseInt(a);
                    int d = Integer.parseInt(board.inst[checkCircular(pc+c)].a);
                    if (board.inst[checkCircular(pc+c)].a3 == '-') {
                        d = -d;
                    }
                    pc = checkCircular(pc+d);
                }else{
                    pc = checkCircular(pc+1);
                }

            }
            if(a2 == '*' && b2 == 'd' && a3 == 'd' && b3 == 'd'){
                int c1 = Integer.parseInt(b);
                if(board.inst[checkCircular(pc+c1)].b == "0") {
                    int c = Integer.parseInt(a);
                    int d = Integer.parseInt(board.inst[checkCircular(pc+c)].a);
                    if (board.inst[checkCircular(pc+c)].a3 == '-') {
                        d = -d;
                    }
                    pc = checkCircular(pc+d);
                }else{
                    pc = checkCircular(pc+1);
                }

            }
            if(a2 == '*' && b2 == '@' && a3 == 'd' && b3 == 'd'){
                int c1 = Integer.parseInt(b);
                int d1 = Integer.parseInt(board.inst[checkCircular(pc+c1)].b);
                if(board.inst[checkCircular(pc+c1)].b3 == '-'){
                    d1 = -d1;
                }
                if(board.inst[checkCircular(pc+d1)].b == "0") {
                    int c = Integer.parseInt(a);
                    int d = Integer.parseInt(board.inst[checkCircular(pc+c)].a);
                    if (board.inst[checkCircular(pc+c)].a3 == '-') {
                        d = -d;
                    }
                    pc = checkCircular(pc+d);
                }else {
                    pc = checkCircular(pc+1);
                }

            }
            if(a2 == 'd' && b2 == '#' && a3 == 'd' && b3 == 'd'){
                if(b == "0") {
                    int c = Integer.parseInt(a);
                    pc = checkCircular(pc+c);
                }else{
                    pc = checkCircular(pc+1);
                }

            }
            if(a2 == 'd' && b2 == 'd' && a3 == 'd' && b3 == 'd'){

                int c1 = Integer.parseInt(b);
                if(board.inst[checkCircular(pc+c1)].b == "0") {
                    int c = Integer.parseInt(a);
                    pc = checkCircular(pc+c);
                }else{
                    pc = checkCircular(pc+1);
                }
            }
            if(a2 == 'd' && b2 == '@' && a3 == 'd' && b3 == 'd'){
                int c1 = Integer.parseInt(b);
                int d1 = Integer.parseInt(board.inst[checkCircular(pc+c1)].b);
                if(board.inst[checkCircular(pc+c1)].b3 == '-'){
                    d1 = -d1;
                }
                if(board.inst[checkCircular(pc+d1)].b == "0") {
                    int c = Integer.parseInt(a);
                    pc = checkCircular(pc+c);
                }else {
                    pc = checkCircular(pc+1);
                }
            }

            // a3 = - and b3 = d
            if(a2 == '*' && b2 == '#' && a3 == '-' && b3 == 'd'){
                if(b == "0") {
                    int c = Integer.parseInt(a);
                    if(a3 == '-'){
                        c = -c;
                    }
                    int d = Integer.parseInt(board.inst[checkCircular(pc+c)].a);
                    if (board.inst[checkCircular(pc+c)].a3 == '-') {
                        d = -d;
                    }
                    pc = checkCircular(pc+d);
                }else {
                    pc = checkCircular(pc+1);
                }
            }
            if(a2 == '*' && b2 == 'd' && a3 == '-' && b3 == 'd'){
                int c1 = Integer.parseInt(b);
                if(board.inst[checkCircular(pc+c1)].b == "0") {
                    int c = Integer.parseInt(a);
                    if(a3 == '-'){
                        c = -c;
                    }
                    int d = Integer.parseInt(board.inst[checkCircular(pc+c)].a);
                    if (board.inst[checkCircular(pc+c)].a3 == '-') {
                        d = -d;
                    }
                    pc = checkCircular(pc+d);
                }else {
                    pc = checkCircular(pc+1);
                }
            }
            if(a2 == '*' && b2 == '@' && a3 == '-' && b3 == 'd'){
                int c1 = Integer.parseInt(b);
                int d1 = Integer.parseInt(board.inst[checkCircular(pc+c1)].b);
                if(board.inst[checkCircular(pc+c1)].b3 == '-'){
                    d1 = -d1;
                }
                if(board.inst[checkCircular(pc+d1)].b == "0") {
                    int c = Integer.parseInt(a);
                    if(a3 == '-'){
                        c = -c;
                    }
                    int d = Integer.parseInt(board.inst[checkCircular(pc+c)].a);
                    if (board.inst[checkCircular(pc+c)].a3 == '-') {
                        d = -d;
                    }
                    pc = checkCircular(pc+d);
                }else {
                    pc = checkCircular(pc+1);
                }

            }
            if(a2 == 'd' && b2 == '#' && a3 == '-' && b3 == 'd'){
                if(b == "0") {
                    int c = Integer.parseInt(a);
                    if(a3 == '-'){
                        c = -c;
                    }
                    pc = checkCircular(pc+c);
                }else {
                    pc = checkCircular(pc+1);
                }
            }
            if(a2 == 'd' && b2 == 'd' && a3 == '-' && b3 == 'd'){
                int c1 = Integer.parseInt(b);
                if(board.inst[checkCircular(pc+c1)].b == "0") {
                    int c = Integer.parseInt(a);
                    if(a3 == '-'){
                        c = -c;
                    }
                    pc = checkCircular(pc+c);
                }else {
                    pc = checkCircular(pc+1);
                }
            }
            if(a2 == 'd' && b2 == '@' && a3 == '-' && b3 == 'd'){
                int c1 = Integer.parseInt(b);
                int d1 = Integer.parseInt(board.inst[checkCircular(pc+c1)].b);
                if(board.inst[checkCircular(pc+c1)].b3 == '-'){
                    d1 = -d1;
                }
                if(board.inst[checkCircular(pc+d1)].b == "0") {
                    int c = Integer.parseInt(a);
                    if(a3 == '-'){
                        c = -c;
                    }
                    pc = checkCircular(pc+c);
                }else {
                    pc = checkCircular(pc+1);
                }
            }

            // a3 = d and b3 = -
            if(a2 == '*' && b2 == '#' && a3 == 'd' && b3 == '-'){
                if(b == "0") {
                    int c = Integer.parseInt(a);
                    int d = Integer.parseInt(board.inst[checkCircular(pc+c)].a);
                    if (board.inst[checkCircular(pc+c)].a3 == '-') {
                        d = -d;
                    }
                    pc = checkCircular(pc+d);
                }else{
                    pc = checkCircular(pc+1);
                }
            }
            if(a2 == '*' && b2 == 'd' && a3 == 'd' && b3 == '-'){
                int c1 = Integer.parseInt(b);
                if (b3 == '-'){
                    c1 = -c1;
                }
                if(board.inst[checkCircular(pc+c1)].b == "0") {
                    int c = Integer.parseInt(a);
                    int d = Integer.parseInt(board.inst[checkCircular(pc+c)].a);
                    if (board.inst[checkCircular(pc+c)].a3 == '-') {
                        d = -d;
                    }
                    pc = checkCircular(pc+d);
                }else{
                    pc = checkCircular(pc+1);
                }
            }
            if(a2 == '*' && b2 == '@' && a3 == 'd' && b3 == '-'){
                int c1 = Integer.parseInt(b);
                if (b3 == '-'){
                    c1 = -c1;
                }
                int d1 = Integer.parseInt(board.inst[checkCircular(pc+c1)].b);
                if(board.inst[checkCircular(pc+c1)].b3 == '-'){
                    d1 = -d1;
                }
                if(board.inst[checkCircular(pc+d1)].b == "0") {
                    int c = Integer.parseInt(a);
                    int d = Integer.parseInt(board.inst[checkCircular(pc+c)].a);
                    if (board.inst[checkCircular(pc+c)].a3 == '-') {
                        d = -d;
                    }
                    pc = checkCircular(pc+d);
                }else {
                    pc = checkCircular(pc+1);
                }
            }
            if(a2 == 'd' && b2 == '#' && a3 == 'd' && b3 == '-'){
                if(b == "0") {
                    int c = Integer.parseInt(a);
                    pc = checkCircular(pc+c);
                }else {
                    pc = checkCircular(pc+1);
                }
            }
            if(a2 == 'd' && b2 == 'd' && a3 == 'd' && b3 == '-'){
                int c1 = Integer.parseInt(b);
                if(b3 == '-') {
                    c1 = -c1;
                }
                if(board.inst[checkCircular(pc+c1)].b == "0") {
                    int c = Integer.parseInt(a);
                    pc = checkCircular(pc+c);
                }else {
                    pc = checkCircular(pc+c1);
                }
            }
            if(a2 == 'd' && b2 == '@' && a3 == 'd' && b3 == '-'){
                int c1 = Integer.parseInt(b);
                if(b3 == '-') {
                    c1 = -c1;
                }
                int d1 = Integer.parseInt(board.inst[checkCircular(pc+c1)].b);
                if(board.inst[checkCircular(pc+c1)].b3 == '-'){
                    d1 = -d1;
                }
                if(board.inst[checkCircular(pc+d1)].b == "0") {
                    int c = Integer.parseInt(a);
                    pc = checkCircular(pc+c);
                }else {
                    pc = checkCircular(pc+1);
                }
            }

            // a3 = - and b3 = -
            if(a2 == '*' && b2 == '#' && a3 == '-' && b3 == '-'){
                if(b == "0") {
                    int c = Integer.parseInt(a);
                    if(a3 == '-'){
                        c = -c;
                    }
                    int d = Integer.parseInt(board.inst[checkCircular(pc+c)].a);
                    if (board.inst[checkCircular(pc+c)].a3 == '-') {
                        d = -d;
                    }
                    pc = checkCircular(pc+d);
                }else {
                    pc = checkCircular(pc+1);
                }
            }
            if(a2 == '*' && b2 == 'd' && a3 == '-' && b3 == '-'){
                int c1 = Integer.parseInt(b);
                if(b3 == '-') {
                    c1 = -c1;
                }
                if(board.inst[checkCircular(pc+c1)].b == "0") {
                    int c = Integer.parseInt(a);
                    if(a3 == '-'){
                        c = -c;
                    }
                    int d = Integer.parseInt(board.inst[checkCircular(pc+c)].a);
                    if (board.inst[checkCircular(pc+c)].a3 == '-') {
                        d = -d;
                    }
                    pc = checkCircular(pc+d);
                }else {
                    pc = checkCircular(pc+1);
                }
            }
            if(a2 == '*' && b2 == '@' && a3 == '-' && b3 == '-'){
                int c1 = Integer.parseInt(b);
                if(b3 == '-') {
                    c1 = -c1;
                }
                int d1 = Integer.parseInt(board.inst[checkCircular(pc+c1)].b);
                if(board.inst[checkCircular(pc+c1)].b3 == '-'){
                    d1 = -d1;
                }
                if(board.inst[checkCircular(pc+d1)].b == "0") {
                    int c = Integer.parseInt(a);
                    if(a3 == '-'){
                        c = -c;
                    }
                    int d = Integer.parseInt(board.inst[checkCircular(pc+c)].a);
                    if (board.inst[checkCircular(pc+c)].a3 == '-') {
                        d = -d;
                    }
                    pc = checkCircular(pc+d);
                }else {
                    pc = checkCircular(pc+1);
                }
            }
            if(a2 == 'd' && b2 == '#' && a3 == '-' && b3 == '-'){
                if(b == "0") {
                    int c = Integer.parseInt(a);
                    if(a3 == '-'){
                        c = -c;
                    }
                    pc = checkCircular(pc+c);
                }else {
                    pc = checkCircular(pc+1);
                }
            }
            if(a2 == 'd' && b2 == 'd' && a3 == '-' && b3 == '-'){
                int c1 = Integer.parseInt(b);
                if(b3 == '-') {
                    c1 = -c1;
                }
                if(board.inst[pc+c1].b == "0") {
                    int c = Integer.parseInt(a);
                    if(a3 == '-'){
                        c = -c;
                    }
                    pc = checkCircular(pc+c);
                }else {
                    pc = checkCircular(pc+1);
                }
            }
            if(a2 == 'd' && b2 == '@' && a3 == '-' && b3 == '-'){
                int c1 = Integer.parseInt(b);
                if(b3 == '-') {
                    c1 = -c1;
                }
                int d1 = Integer.parseInt(board.inst[checkCircular(pc+c1)].b);
                if(board.inst[checkCircular(pc+c1)].b3 == '-'){
                    d1 = -d1;
                }
                if(board.inst[checkCircular(pc+d1)].b == "0") {
                    int c = Integer.parseInt(a);
                    if(a3 == '-'){
                        c = -c;
                    }
                    pc = checkCircular(pc+c);
                }else {
                    pc = checkCircular(pc+1);
                }
            }
        }
        else {
            System.out.println("Error");
        }
        return pc;
    }

////////////////////////////////////////////////////////////////////////////////////////////////

    public int DJN(String fullinst, String inst, Board board, int pc, char a2, char a3, String a, char b2, char b3, String b) {
        if((a2 == '*' || a2 == 'd') && (b2 == '#' || b2 == 'd' || b2 == '@') && (a3 == '-' || a3 == 'd') && (b3 == '-' || b3 == 'd')) {
            String result = " ";
            // a3 = d and b3 = d
            if(a2 == '*' && b2 == '#' && a3 == 'd' && b3 == 'd'){
                int c1 = Integer.parseInt(b);
                c1 = c1 - 1;
                if(c1 <0){
                    c1 = -c1;
                    board.inst[pc].b3 = '-';
                }else{
                    board.inst[pc].b3 = 'd';
                }
                board.inst[pc].b = Integer.toString(c1);
                result = changeValues(board.inst[pc].fullinst, board.inst[pc].inst, board, pc, board.inst[pc].a2, board.inst[pc].a3, board.inst[pc].a, board.inst[pc].b2, board.inst[pc].b3, board.inst[pc].b);

                if(c1 != 0){
                    int c = Integer.parseInt(a);
                    int d = Integer.parseInt(board.inst[checkCircular(pc+c)].a);
                    if (board.inst[checkCircular(pc+c)].a3 == '-') {
                        d = -d;
                    }
                    pc = checkCircular(pc+d);
                }else{
                    pc = checkCircular(pc+1);
                }
            }
            if(a2 == '*' && b2 == 'd' && a3 == 'd' && b3 == 'd'){
                int c1 = Integer.parseInt(b);
                int d1 = Integer.parseInt(board.inst[checkCircular(pc+c1)].b);
                if(board.inst[checkCircular(pc+c1)].b3 == '-'){
                    d1 = -d1;
                }
                d1 = d1 - 1;
                if(d1 <0){
                    d1 = -d1;
                    board.inst[checkCircular(pc+c1)].b3 = '-';
                }else{
                    board.inst[checkCircular(pc+c1)].b3 = 'd';
                }
                board.inst[checkCircular(pc+c1)].b = Integer.toString(d1);
                result = changeValues(board.inst[checkCircular(pc+c1)].fullinst, board.inst[checkCircular(pc+c1)].inst, board, pc+c1, board.inst[checkCircular(pc+c1)].a2, board.inst[checkCircular(pc+c1)].a3, board.inst[checkCircular(pc+c1)].a, board.inst[checkCircular(pc+c1)].b2, board.inst[checkCircular(pc+c1)].b3, board.inst[checkCircular(pc+c1)].b);

                if(d1 != 0){
                    int c = Integer.parseInt(a);
                    int d = Integer.parseInt(board.inst[checkCircular(pc+c)].a);
                    if (board.inst[checkCircular(pc+c)].a3 == '-') {
                        d = -d;
                    }
                    pc = checkCircular(pc+d);
                }else{
                    pc = checkCircular(pc+1);
                }
            }
            if(a2 == '*' && b2 == '@' && a3 == 'd' && b3 == 'd'){
                int c1 = Integer.parseInt(b);
                int d1 = Integer.parseInt(board.inst[checkCircular(pc+c1)].b);
                if(board.inst[checkCircular(pc+c1)].b3 == '-'){
                    d1 = -d1;
                }
                int e1 = Integer.parseInt(board.inst[checkCircular(pc+d1)].b);
                if(board.inst[checkCircular(pc+d1)].b3 == '-'){
                    e1 = -e1;
                }
                e1 = e1 - 1;
                if(e1 <0){
                    e1 = -e1;
                    board.inst[checkCircular(pc+d1)].b3 = '-';
                }else{
                    board.inst[checkCircular(pc+d1)].b3 = 'd';
                }
                board.inst[checkCircular(pc+d1)].b = Integer.toString(e1);
                result = changeValues(board.inst[checkCircular(pc+d1)].fullinst, board.inst[checkCircular(pc+d1)].inst, board, pc+d1, board.inst[checkCircular(pc+d1)].a2, board.inst[checkCircular(pc+d1)].a3, board.inst[checkCircular(pc+d1)].a, board.inst[checkCircular(pc+d1)].b2, board.inst[checkCircular(pc+d1)].b3, board.inst[checkCircular(pc+d1)].b);

                if(e1 != 0){
                    int c = Integer.parseInt(a);
                    int d = Integer.parseInt(board.inst[checkCircular(pc+c)].a);
                    if (board.inst[checkCircular(pc+c)].a3 == '-') {
                        d = -d;
                    }
                    pc = checkCircular(pc+d);
                }else{
                    pc = checkCircular(pc+1);
                }
            }
            if(a2 == 'd' && b2 == '#' && a3 == 'd' && b3 == 'd'){
                int c1 = Integer.parseInt(b);
                c1 = c1 - 1;
                if(c1 <0){
                    c1 = -c1;
                    board.inst[pc].b3 = '-';
                }else{
                    board.inst[pc].b3 = 'd';
                }
                board.inst[pc].b = Integer.toString(c1);
                result = changeValues(board.inst[pc].fullinst, board.inst[pc].inst, board, pc, board.inst[pc].a2, board.inst[pc].a3, board.inst[pc].a, board.inst[pc].b2, board.inst[pc].b3, board.inst[pc].b);

                if(c1 != 0){
                    int c = Integer.parseInt(a);
                    int d = Integer.parseInt(board.inst[checkCircular(pc+c)].a);
                    if (board.inst[checkCircular(pc+c)].a3 == '-') {
                        d = -d;
                    }
                    pc = checkCircular(pc+d);
                }else{
                    pc = checkCircular(pc+1);
                }
            }
            if(a2 == 'd' && b2 == 'd' && a3 == 'd' && b3 == 'd'){
                int c1 = Integer.parseInt(b);
                int d1 = Integer.parseInt(board.inst[checkCircular(pc+c1)].b);
                if(board.inst[checkCircular(pc+c1)].b3 == '-'){
                    d1 = -d1;
                }
                d1 = d1 - 1;
                if(d1 <0){
                    d1 = -d1;
                    board.inst[checkCircular(pc+c1)].b3 = '-';
                }else{
                    board.inst[checkCircular(pc+c1)].b3 = 'd';
                }
                board.inst[checkCircular(pc+c1)].b = Integer.toString(d1);
                result = changeValues(board.inst[checkCircular(pc+c1)].fullinst, board.inst[checkCircular(pc+c1)].inst, board, pc+c1, board.inst[checkCircular(pc+c1)].a2, board.inst[checkCircular(pc+c1)].a3, board.inst[checkCircular(pc+c1)].a, board.inst[checkCircular(pc+c1)].b2, board.inst[checkCircular(pc+c1)].b3, board.inst[checkCircular(pc+c1)].b);
                if(d1 != 0){
                    int c = Integer.parseInt(a);

                    pc = checkCircular(pc+c);
                }else{
                    pc = checkCircular(pc+1);
                }
            }
            if(a2 == 'd' && b2 == '@' && a3 == 'd' && b3 == 'd'){
                int c1 = Integer.parseInt(b);
                int d1 = Integer.parseInt(board.inst[checkCircular(pc+c1)].b);
                if(board.inst[checkCircular(pc+c1)].b3 == '-'){
                    d1 = -d1;
                }
                int e1 = Integer.parseInt(board.inst[checkCircular(pc+d1)].b);
                if(board.inst[checkCircular(pc+d1)].b3 == '-'){
                    e1 = -e1;
                }
                e1 = e1 - 1;
                if(e1 <0){
                    e1 = -e1;
                    board.inst[checkCircular(pc+d1)].b3 = '-';
                }else{
                    board.inst[checkCircular(pc+d1)].b3 = 'd';
                }
                board.inst[checkCircular(pc+d1)].b = Integer.toString(e1);
                result = changeValues(board.inst[checkCircular(pc+d1)].fullinst, board.inst[checkCircular(pc+d1)].inst, board, pc+d1, board.inst[checkCircular(pc+d1)].a2, board.inst[checkCircular(pc+d1)].a3, board.inst[checkCircular(pc+d1)].a, board.inst[checkCircular(pc+d1)].b2, board.inst[checkCircular(pc+d1)].b3, board.inst[checkCircular(pc+d1)].b);
                if(e1 != 0){
                    int c = Integer.parseInt(a);
                    pc = checkCircular(pc+c);
                }else{
                    pc = checkCircular(pc+1);
                }
            }

            // a3 = - and b3 = d
            if(a2 == '*' && b2 == '#' && a3 == '-' && b3 == 'd'){
                int c1 = Integer.parseInt(b);
                c1 = c1 - 1;
                if(c1 <0){
                    c1 = -c1;
                    board.inst[pc].b3 = '-';
                }else{
                    board.inst[pc].b3 = 'd';
                }
                board.inst[pc].b = Integer.toString(c1);
                result = changeValues(board.inst[pc].fullinst, board.inst[pc].inst, board, pc, board.inst[pc].a2, board.inst[pc].a3, board.inst[pc].a, board.inst[pc].b2, board.inst[pc].b3, board.inst[pc].b);

                if(c1 != 0){
                    int c = Integer.parseInt(a);
                    int d = Integer.parseInt(board.inst[checkCircular(pc+c)].a);
                    if (board.inst[checkCircular(pc+c)].a3 == '-') {
                        d = -d;
                    }
                    pc = checkCircular(pc+d);
                }else{
                    pc = checkCircular(pc+1);
                }
            }
            if(a2 == '*' && b2 == 'd' && a3 == '-' && b3 == 'd'){
                int c1 = Integer.parseInt(b);
                int d1 = Integer.parseInt(board.inst[checkCircular(pc+c1)].b);
                if(board.inst[checkCircular(pc+c1)].b3 == '-'){
                    d1 = -d1;
                }
                d1 = d1 - 1;
                if(d1 <0){
                    d1 = -d1;
                    board.inst[checkCircular(pc+c1)].b3 = '-';
                }else{
                    board.inst[checkCircular(pc+c1)].b3 = 'd';
                }
                board.inst[checkCircular(pc+c1)].b = Integer.toString(d1);
                result = changeValues(board.inst[checkCircular(pc+c1)].fullinst, board.inst[checkCircular(pc+c1)].inst, board, pc+c1, board.inst[checkCircular(pc+c1)].a2, board.inst[checkCircular(pc+c1)].a3, board.inst[checkCircular(pc+c1)].a, board.inst[checkCircular(pc+c1)].b2, board.inst[checkCircular(pc+c1)].b3, board.inst[checkCircular(pc+c1)].b);

                if(d1 != 0){
                    int c = Integer.parseInt(a);
                    if(a3 == '-'){
                        c = -c;
                    }
                    int d = Integer.parseInt(board.inst[checkCircular(pc+c)].a);
                    if (board.inst[checkCircular(pc+c)].a3 == '-') {
                        d = -d;
                    }
                    pc = checkCircular(pc+d);
                }else{
                    pc = checkCircular(pc+1);
                }
            }
            if(a2 == '*' && b2 == '@' && a3 == '-' && b3 == 'd'){
                int c1 = Integer.parseInt(b);
                int d1 = Integer.parseInt(board.inst[checkCircular(pc+c1)].b);
                if(board.inst[checkCircular(pc+c1)].b3 == '-'){
                    d1 = -d1;
                }
                int e1 = Integer.parseInt(board.inst[checkCircular(pc+d1)].b);
                if(board.inst[checkCircular(pc+d1)].b3 == '-'){
                    e1 = -e1;
                }
                e1 = e1 - 1;
                if(e1 <0){
                    e1 = -e1;
                    board.inst[checkCircular(pc+d1)].b3 = '-';
                }else{
                    board.inst[checkCircular(pc+d1)].b3 = 'd';
                }
                board.inst[checkCircular(pc+d1)].b = Integer.toString(e1);
                result = changeValues(board.inst[checkCircular(pc+d1)].fullinst, board.inst[checkCircular(pc+d1)].inst, board, pc+d1, board.inst[checkCircular(pc+d1)].a2, board.inst[checkCircular(pc+d1)].a3, board.inst[checkCircular(pc+d1)].a, board.inst[checkCircular(pc+d1)].b2, board.inst[checkCircular(pc+d1)].b3, board.inst[checkCircular(pc+d1)].b);

                if(e1 != 0){
                    int c = Integer.parseInt(a);
                    if(a3 == '-'){
                        c = -c;
                    }
                    int d = Integer.parseInt(board.inst[checkCircular(pc+c)].a);
                    if (board.inst[checkCircular(pc+c)].a3 == '-') {
                        d = -d;
                    }
                    pc = checkCircular(pc+d);
                }else{
                    pc = checkCircular(pc+1);
                }
            }
            if(a2 == 'd' && b2 == '#' && a3 == '-' && b3 == 'd'){
                int c1 = Integer.parseInt(b);
                c1 = c1 - 1;
                if(c1 <0){
                    c1 = -c1;
                    board.inst[pc].b3 = '-';
                }else{
                    board.inst[pc].b3 = 'd';
                }
                board.inst[pc].b = Integer.toString(c1);
                result = changeValues(board.inst[pc].fullinst, board.inst[pc].inst, board, pc, board.inst[pc].a2, board.inst[pc].a3, board.inst[pc].a, board.inst[pc].b2, board.inst[pc].b3, board.inst[pc].b);

                if(c1 != 0){
                    int c = Integer.parseInt(a);
                    if(a3 == '-'){
                        c = -c;
                    }
                    int d = Integer.parseInt(board.inst[checkCircular(pc+c)].a);
                    if (board.inst[checkCircular(pc+c)].a3 == '-') {
                        d = -d;
                    }
                    pc = checkCircular(pc+d);
                }else{
                    pc = checkCircular(pc+1);
                }
            }
            if(a2 == 'd' && b2 == 'd' && a3 == '-' && b3 == 'd'){
                int c1 = Integer.parseInt(b);
                int d1 = Integer.parseInt(board.inst[checkCircular(pc+c1)].b);
                if(board.inst[checkCircular(pc+c1)].b3 == '-'){
                    d1 = -d1;
                }
                d1 = d1 - 1;
                if(d1 <0){
                    d1 = -d1;
                    board.inst[checkCircular(pc+c1)].b3 = '-';
                }else{
                    board.inst[checkCircular(pc+c1)].b3 = 'd';
                }
                board.inst[checkCircular(pc+c1)].b = Integer.toString(d1);
                result = changeValues(board.inst[checkCircular(pc+c1)].fullinst, board.inst[checkCircular(pc+c1)].inst, board, pc+c1, board.inst[checkCircular(pc+c1)].a2, board.inst[checkCircular(pc+c1)].a3, board.inst[checkCircular(pc+c1)].a, board.inst[checkCircular(pc+c1)].b2, board.inst[checkCircular(pc+c1)].b3, board.inst[checkCircular(pc+c1)].b);

                if(d1 != 0){
                    int c = Integer.parseInt(a);
                    if(a3 == '-'){
                        c = -c;
                    }
                    pc = checkCircular(pc+c);
                }else{
                    pc = checkCircular(pc+1);
                }
            }
            if(a2 == 'd' && b2 == '@' && a3 == '-' && b3 == 'd'){
                int c1 = Integer.parseInt(b);
                int d1 = Integer.parseInt(board.inst[checkCircular(pc+c1)].b);
                if(board.inst[checkCircular(pc+c1)].b3 == '-'){
                    d1 = -d1;
                }
                int e1 = Integer.parseInt(board.inst[checkCircular(pc+d1)].b);
                if(board.inst[checkCircular(pc+d1)].b3 == '-'){
                    e1 = -e1;
                }
                e1 = e1 - 1;
                if(e1 <0){
                    e1 = -e1;
                    board.inst[checkCircular(pc+d1)].b3 = '-';
                }else{
                    board.inst[checkCircular(pc+d1)].b3 = 'd';
                }
                board.inst[checkCircular(pc+d1)].b = Integer.toString(e1);
                result = changeValues(board.inst[checkCircular(pc+d1)].fullinst, board.inst[checkCircular(pc+d1)].inst, board, pc+d1, board.inst[checkCircular(pc+d1)].a2, board.inst[checkCircular(pc+d1)].a3, board.inst[checkCircular(pc+d1)].a, board.inst[checkCircular(pc+d1)].b2, board.inst[checkCircular(pc+d1)].b3, board.inst[checkCircular(pc+d1)].b);

                if(e1 != 0){
                    int c = Integer.parseInt(a);
                    if(a3 == '-'){
                        c = -c;
                    }
                    pc = checkCircular(pc+c);
                }else{
                    pc = checkCircular(pc+1);
                }
            }

            // a3 = d and b3 = -
            if(a2 == '*' && b2 == '#' && a3 == 'd' && b3 == '-'){
                int c1 = Integer.parseInt(b);
                if(b3 == '-'){
                    c1 = -c1;
                }
                c1 = c1 - 1;
                if(c1 <0){
                    c1 = -c1;
                    board.inst[pc].b3 = '-';
                }else{
                    board.inst[pc].b3 = 'd';
                }
                board.inst[pc].b = Integer.toString(c1);
                result = changeValues(board.inst[pc].fullinst, board.inst[pc].inst, board, pc, board.inst[pc].a2, board.inst[pc].a3, board.inst[pc].a, board.inst[pc].b2, board.inst[pc].b3, board.inst[pc].b);

                if(c1 != 0){
                    int c = Integer.parseInt(a);
                    int d = Integer.parseInt(board.inst[checkCircular(pc+c)].a);
                    if (board.inst[checkCircular(pc+c)].a3 == '-') {
                        d = -d;
                    }
                    pc = checkCircular(pc+d);
                }else{
                    pc = checkCircular(pc+1);
                }
            }
            if(a2 == '*' && b2 == 'd' && a3 == 'd' && b3 == '-'){
                int c1 = Integer.parseInt(b);
                if (b3 == '-') {
                    c1 = -c1;
                }
                int d1 = Integer.parseInt(board.inst[checkCircular(pc+c1)].b);
                if(board.inst[checkCircular(pc+c1)].b3 == '-'){
                    d1 = -d1;
                }
                d1 = d1 - 1;
                if(d1 <0){
                    d1 = -d1;
                    board.inst[checkCircular(pc+c1)].b3 = '-';
                }else{
                    board.inst[checkCircular(pc+c1)].b3 = 'd';
                }
                board.inst[checkCircular(pc+c1)].b = Integer.toString(d1);
                result = changeValues(board.inst[checkCircular(pc+c1)].fullinst, board.inst[checkCircular(pc+c1)].inst, board, pc+c1, board.inst[checkCircular(pc+c1)].a2, board.inst[checkCircular(pc+c1)].a3, board.inst[checkCircular(pc+c1)].a, board.inst[checkCircular(pc+c1)].b2, board.inst[checkCircular(pc+c1)].b3, board.inst[checkCircular(pc+c1)].b);

                if(d1 != 0){
                    int c = Integer.parseInt(a);
                    int d = Integer.parseInt(board.inst[checkCircular(pc+c)].a);
                    if (board.inst[checkCircular(pc+c)].a3 == '-') {
                        d = -d;
                    }
                    pc = checkCircular(pc+d);
                }else{
                    pc = checkCircular(pc+1);
                }
            }
            if(a2 == '*' && b2 == '@' && a3 == 'd' && b3 == '-'){
                int c1 = Integer.parseInt(b);
                if(b3 == '-'){
                    c1 = - c1;
                }
                int d1 = Integer.parseInt(board.inst[checkCircular(pc+c1)].b);
                if(board.inst[checkCircular(pc+c1)].b3 == '-'){
                    d1 = -d1;
                }
                int e1 = Integer.parseInt(board.inst[checkCircular(pc+d1)].b);
                if(board.inst[checkCircular(pc+d1)].b3 == '-'){
                    e1 = -e1;
                }
                e1 = e1 - 1;
                if(e1 <0){
                    e1 = -e1;
                    board.inst[checkCircular(pc+d1)].b3 = '-';
                }else{
                    board.inst[checkCircular(pc+d1)].b3 = 'd';
                }
                board.inst[checkCircular(pc+d1)].b = Integer.toString(e1);
                result = changeValues(board.inst[checkCircular(pc+d1)].fullinst, board.inst[checkCircular(pc+d1)].inst, board, pc+d1, board.inst[checkCircular(pc+d1)].a2, board.inst[checkCircular(pc+d1)].a3, board.inst[checkCircular(pc+d1)].a, board.inst[checkCircular(pc+d1)].b2, board.inst[checkCircular(pc+d1)].b3, board.inst[checkCircular(pc+d1)].b);

                if(e1 != 0){
                    int c = Integer.parseInt(a);
                    int d = Integer.parseInt(board.inst[checkCircular(pc+c)].a);
                    if (board.inst[checkCircular(pc+c)].a3 == '-') {
                        d = -d;
                    }
                    pc = checkCircular(pc+d);
                }else{
                    pc = checkCircular(pc+1);
                }
            }
            if(a2 == 'd' && b2 == '#' && a3 == 'd' && b3 == '-'){
                int c1 = Integer.parseInt(b);
                if(b3 == '-'){
                    c1 = -c1;
                }
                c1 = c1 - 1;
                if(c1 <0){
                    c1 = -c1;
                    board.inst[pc].b3 = '-';
                }else{
                    board.inst[pc].b3 = 'd';
                }
                board.inst[pc].b = Integer.toString(c1);
                result = changeValues(board.inst[pc].fullinst, board.inst[pc].inst, board, pc, board.inst[pc].a2, board.inst[pc].a3, board.inst[pc].a, board.inst[pc].b2, board.inst[pc].b3, board.inst[pc].b);

                if(c1 != 0){
                    int c = Integer.parseInt(a);
                    int d = Integer.parseInt(board.inst[checkCircular(pc+c)].a);
                    if (board.inst[checkCircular(pc+c)].a3 == '-') {
                        d = -d;
                    }
                    pc = checkCircular(pc+d);
                }else{
                    pc = checkCircular(pc+1);
                }
            }
            if(a2 == 'd' && b2 == 'd' && a3 == 'd' && b3 == '-'){
                int c1 = Integer.parseInt(b);
                if (b3 == '-') {
                    c1 = -c1;
                }
                int d1 = Integer.parseInt(board.inst[checkCircular(pc+c1)].b);
                if(board.inst[checkCircular(pc+c1)].b3 == '-'){
                    d1 = -d1;
                }
                d1 = d1 - 1;
                if(d1 <0){
                    d1 = -d1;
                    board.inst[checkCircular(pc+c1)].b3 = '-';
                }else{
                    board.inst[checkCircular(pc+c1)].b3 = 'd';
                }
                board.inst[checkCircular(pc+c1)].b = Integer.toString(d1);
                result = changeValues(board.inst[checkCircular(pc+c1)].fullinst, board.inst[checkCircular(pc+c1)].inst, board, pc+c1, board.inst[checkCircular(pc+c1)].a2, board.inst[checkCircular(pc+c1)].a3, board.inst[checkCircular(pc+c1)].a, board.inst[checkCircular(pc+c1)].b2, board.inst[checkCircular(pc+c1)].b3, board.inst[checkCircular(pc+c1)].b);

                if(d1 != 0){
                    int c = Integer.parseInt(a);
                    pc = checkCircular(pc+c);
                }else{
                    pc = checkCircular(pc+1);
                }
            }
            if(a2 == 'd' && b2 == '@' && a3 == 'd' && b3 == '-'){
                int c1 = Integer.parseInt(b);
                if(b3 == '-'){
                    c1 = - c1;
                }
                int d1 = Integer.parseInt(board.inst[checkCircular(pc+c1)].b);
                if(board.inst[checkCircular(pc+c1)].b3 == '-'){
                    d1 = -d1;
                }
                int e1 = Integer.parseInt(board.inst[checkCircular(pc+d1)].b);
                if(board.inst[checkCircular(pc+d1)].b3 == '-'){
                    e1 = -e1;
                }
                e1 = e1 - 1;
                if(e1 <0){
                    e1 = -e1;
                    board.inst[checkCircular(pc+d1)].b3 = '-';
                }else{
                    board.inst[checkCircular(pc+d1)].b3 = 'd';
                }
                board.inst[checkCircular(pc+d1)].b = Integer.toString(e1);
                result = changeValues(board.inst[checkCircular(pc+d1)].fullinst, board.inst[checkCircular(pc+d1)].inst, board, pc+d1, board.inst[checkCircular(pc+d1)].a2, board.inst[checkCircular(pc+d1)].a3, board.inst[checkCircular(pc+d1)].a, board.inst[checkCircular(pc+d1)].b2, board.inst[checkCircular(pc+d1)].b3, board.inst[checkCircular(pc+d1)].b);

                if(e1 != 0){
                    int c = Integer.parseInt(a);
                    pc = checkCircular(pc+c);
                }else{
                    pc = checkCircular(pc+1);
                }
            }

            // a3 = - and b3 = -
            if(a2 == '*' && b2 == '#' && a3 == '-' && b3 == '-'){
                int c1 = Integer.parseInt(b);
                if(b3 == '-'){
                    c1 = -c1;
                }
                c1 = c1 - 1;
                if(c1 <0){
                    c1 = -c1;
                    board.inst[pc].b3 = '-';
                }else{
                    board.inst[pc].b3 = 'd';
                }
                board.inst[pc].b = Integer.toString(c1);
                result = changeValues(board.inst[pc].fullinst, board.inst[pc].inst, board, pc, board.inst[pc].a2, board.inst[pc].a3, board.inst[pc].a, board.inst[pc].b2, board.inst[pc].b3, board.inst[pc].b);

                if(c1 != 0){
                    int c = Integer.parseInt(a);
                    if(a3 == '-'){
                        c = -c;
                    }
                    int d = Integer.parseInt(board.inst[checkCircular(pc+c)].a);
                    if (board.inst[checkCircular(pc+c)].a3 == '-') {
                        d = -d;
                    }
                    pc = checkCircular(pc+d);
                }else{
                    pc = checkCircular(pc+1);
                }
            }
            if(a2 == '*' && b2 == 'd' && a3 == '-' && b3 == '-'){
                int c1 = Integer.parseInt(b);
                if (b3 == '-') {
                    c1 = -c1;
                }
                int d1 = Integer.parseInt(board.inst[checkCircular(pc+c1)].b);
                if(board.inst[checkCircular(pc+c1)].b3 == '-'){
                    d1 = -d1;
                }
                d1 = d1 - 1;
                if(d1 <0){
                    d1 = -d1;
                    board.inst[checkCircular(pc+c1)].b3 = '-';
                }else{
                    board.inst[checkCircular(pc+c1)].b3 = 'd';
                }
                board.inst[checkCircular(pc+c1)].b = Integer.toString(d1);
                result = changeValues(board.inst[checkCircular(pc+c1)].fullinst, board.inst[checkCircular(pc+c1)].inst, board, pc+c1, board.inst[checkCircular(pc+c1)].a2, board.inst[checkCircular(pc+c1)].a3, board.inst[checkCircular(pc+c1)].a, board.inst[checkCircular(pc+c1)].b2, board.inst[checkCircular(pc+c1)].b3, board.inst[checkCircular(pc+c1)].b);

                if(d1 != 0){
                    int c = Integer.parseInt(a);
                    if(a3 == '-'){
                        c = -c;
                    }
                    int d = Integer.parseInt(board.inst[checkCircular(pc+c)].a);
                    if (board.inst[checkCircular(pc+c)].a3 == '-') {
                        d = -d;
                    }
                    pc = checkCircular(pc+d);
                }else{
                    pc = checkCircular(pc+1);
                }
            }
            if(a2 == '*' && b2 == '@' && a3 == '-' && b3 == '-'){
                int c1 = Integer.parseInt(b);
                if(b3 == '-'){
                    c1 = - c1;
                }
                int d1 = Integer.parseInt(board.inst[checkCircular(pc+c1)].b);
                if(board.inst[checkCircular(pc+c1)].b3 == '-'){
                    d1 = -d1;
                }
                int e1 = Integer.parseInt(board.inst[checkCircular(pc+d1)].b);
                if(board.inst[checkCircular(pc+d1)].b3 == '-'){
                    e1 = -e1;
                }
                e1 = e1 - 1;
                if(e1 <0){
                    e1 = -e1;
                    board.inst[checkCircular(pc+d1)].b3 = '-';
                }else{
                    board.inst[checkCircular(pc+d1)].b3 = 'd';
                }
                board.inst[checkCircular(pc+d1)].b = Integer.toString(e1);
                result = changeValues(board.inst[checkCircular(pc+d1)].fullinst, board.inst[checkCircular(pc+d1)].inst, board, pc+d1, board.inst[checkCircular(pc+d1)].a2, board.inst[checkCircular(pc+d1)].a3, board.inst[checkCircular(pc+d1)].a, board.inst[checkCircular(pc+d1)].b2, board.inst[checkCircular(pc+d1)].b3, board.inst[checkCircular(pc+d1)].b);

                if(e1 != 0){
                    int c = Integer.parseInt(a);
                    if(a3 == '-'){
                        c = -c;
                    }
                    int d = Integer.parseInt(board.inst[checkCircular(pc+c)].a);
                    if (board.inst[checkCircular(pc+c)].a3 == '-') {
                        d = -d;
                    }
                    pc = checkCircular(pc+d);
                }else{
                    pc = checkCircular(pc+1);
                }
            }
            if(a2 == 'd' && b2 == '#' && a3 == '-' && b3 == '-'){
                int c1 = Integer.parseInt(b);
                if(b3 == '-'){
                    c1 = -c1;
                }
                c1 = c1 - 1;
                if(c1 <0){
                    c1 = -c1;
                    board.inst[pc].b3 = '-';
                }else{
                    board.inst[pc].b3 = 'd';
                }
                board.inst[pc].b = Integer.toString(c1);
                result = changeValues(board.inst[pc].fullinst, board.inst[pc].inst, board, pc, board.inst[pc].a2, board.inst[pc].a3, board.inst[pc].a, board.inst[pc].b2, board.inst[pc].b3, board.inst[pc].b);

                if(c1 != 0){
                    int c = Integer.parseInt(a);
                    if(a3 == '-'){
                        c = -c;
                    }
                    int d = Integer.parseInt(board.inst[checkCircular(pc+c)].a);
                    if (board.inst[checkCircular(pc+c)].a3 == '-') {
                        d = -d;
                    }
                    pc = checkCircular(pc+d);
                }else{
                    pc = checkCircular(pc+1);
                }
            }
            if(a2 == 'd' && b2 == 'd' && a3 == '-' && b3 == '-'){
                int c1 = Integer.parseInt(b);
                if (b3 == '-') {
                    c1 = -c1;
                }
                int d1 = Integer.parseInt(board.inst[checkCircular(pc+c1)].b);
                if(board.inst[checkCircular(pc+c1)].b3 == '-'){
                    d1 = -d1;
                }
                d1 = d1 - 1;
                if(d1 <0){
                    d1 = -d1;
                    board.inst[checkCircular(pc+c1)].b3 = '-';
                }else{
                    board.inst[checkCircular(pc+c1)].b3 = 'd';
                }
                board.inst[checkCircular(pc+c1)].b = Integer.toString(d1);
                result = changeValues(board.inst[checkCircular(pc+c1)].fullinst, board.inst[checkCircular(pc+c1)].inst, board, pc+c1, board.inst[checkCircular(pc+c1)].a2, board.inst[checkCircular(pc+c1)].a3, board.inst[checkCircular(pc+c1)].a, board.inst[checkCircular(pc+c1)].b2, board.inst[checkCircular(pc+c1)].b3, board.inst[checkCircular(pc+c1)].b);

                if(d1 != 0){
                    int c = Integer.parseInt(a);
                    if(a3 == '-'){
                        c = -c;
                    }
                    pc = checkCircular(pc+c);
                }else{
                    pc = checkCircular(pc+1);
                }
            }
            if(a2 == 'd' && b2 == '@' && a3 == '-' && b3 == '-'){
                int c1 = Integer.parseInt(b);
                if(b3 == '-'){
                    c1 = - c1;
                }
                int d1 = Integer.parseInt(board.inst[checkCircular(pc+c1)].b);
                if(board.inst[checkCircular(pc+c1)].b3 == '-'){
                    d1 = -d1;
                }
                int e1 = Integer.parseInt(board.inst[checkCircular(pc+d1)].b);
                if(board.inst[checkCircular(pc+d1)].b3 == '-'){
                    e1 = -e1;
                }
                e1 = e1 - 1;
                if(e1 <0){
                    e1 = -e1;
                    board.inst[checkCircular(pc+d1)].b3 = '-';
                }else{
                    board.inst[checkCircular(pc+d1)].b3 = 'd';
                }
                board.inst[checkCircular(pc+d1)].b = Integer.toString(e1);
                result = changeValues(board.inst[checkCircular(pc+d1)].fullinst, board.inst[checkCircular(pc+d1)].inst, board, pc+d1, board.inst[checkCircular(pc+d1)].a2, board.inst[checkCircular(pc+d1)].a3, board.inst[checkCircular(pc+d1)].a, board.inst[checkCircular(pc+d1)].b2, board.inst[checkCircular(pc+d1)].b3, board.inst[checkCircular(pc+d1)].b);

                if(e1 != 0){
                    int c = Integer.parseInt(a);
                    if(a3 == '-'){
                        c = -c;
                    }
                    pc = checkCircular(pc+c);
                }else{
                    pc = checkCircular(pc+1);
                }
            }
        }
        else {
            System.out.println("Error");
        }
        return pc;
    }

////////////////////////////////////////////////////////////////////////////////////////////////

    public int CMP(String fullinst, String inst, Board board, int pc, char a2, char a3, String a, char b2, char b3, String b) {
        if((a2 == '#' || a2 == '*' || a2 == 'd') && (b2 == 'd' || b2 == '@') && (a3 == '-' || a3 == 'd') && (b3 == '-' || b3 == 'd')) {
            //if a is immediate compares contents of b at b location
            //if a is anything else compares the entire instruction specified by a to the entire instruction specified by b

            // a3 = d and b3 = d
            if(a2 == '#' && b2 == 'd' && a3 == 'd' && b3 == 'd'){
                int d = Integer.parseInt(a);
                int c = Integer.parseInt(b);
                int e = Integer.parseInt(board.inst[checkCircular(pc+c)].b);
                if(board.inst[checkCircular(pc+c)].b3 == '-') {
                    e = -e;
                }
                if(d==e){
                    pc = checkCircular(pc+2);
                }
                else{
                    pc = checkCircular(pc+1);
                }

            }

            if(a2 == '#' && b2 == '@' && a3 == 'd' && b3 == 'd'){
                int d = Integer.parseInt(a);
                int c = Integer.parseInt(b);
                int e = Integer.parseInt(board.inst[checkCircular(pc+c)].b);
                if(board.inst[checkCircular(pc+c)].b3 == '-') {
                    e = -e;
                }
                int g = Integer.parseInt(board.inst[checkCircular(pc+c+e)].b);
                if(board.inst[checkCircular(pc+c+e)].b3 == '-'){
                    g = -g;
                }
                if(d==g){
                    pc = checkCircular(pc+2);
                }
                else{
                    pc = checkCircular(pc+1);
                }
            }
            if(a2 == '*' && b2 == 'd' && a3 == 'd' && b3 == 'd'){
                int d = Integer.parseInt(a);
                int c = Integer.parseInt(b);
                int e = Integer.parseInt(board.inst[checkCircular(pc+c)].b); // final b
                if(board.inst[checkCircular(pc+c)].b3 == '-') {
                    e = -e;
                }
                int g = Integer.parseInt(board.inst[checkCircular(pc+d)].a);
                if(board.inst[checkCircular(pc+d)].a3 == '-'){
                    g = -g;
                }
                int h = Integer.parseInt(board.inst[checkCircular(pc+d+g)].a); // final a
                if(board.inst[checkCircular(pc+d+g)].a3 == '-'){
                    h = -h;
                }

                if(board.inst[checkCircular(pc+d+g)].fullinst.equals(board.inst[checkCircular(pc+c)].fullinst)){
                    pc = checkCircular(pc+2);
                }

                else{
                    pc = checkCircular(pc+1);
                }

            }
            if(a2 == '*' && b2 == '@' && a3 == 'd' && b3 == 'd'){
                int d = Integer.parseInt(a);
                int c = Integer.parseInt(b);
                int e = Integer.parseInt(board.inst[checkCircular(pc+c)].b);
                if(board.inst[checkCircular(pc+c)].b3 == '-') {
                    e = -e;
                }
                int i = Integer.parseInt(board.inst[checkCircular(pc+c+e)].b); // final b
                if(board.inst[checkCircular(pc+c+e)].b3 == '-') {
                    i = -i;
                }
                int g = Integer.parseInt(board.inst[checkCircular(pc+d)].a);
                if(board.inst[checkCircular(pc+d)].a3 == '-'){
                    g = -g;
                }
                int h = Integer.parseInt(board.inst[checkCircular(pc+d+g)].a); // final a
                if(board.inst[checkCircular(pc+d+g)].a3 == '-'){
                    h = -h;
                }

                if(board.inst[checkCircular(pc+d+g)].fullinst.equals(board.inst[checkCircular(pc+d+g)].fullinst)){
                    pc = checkCircular(pc+2);
                }

                else{
                    pc = checkCircular(pc+1);
                }
            }
            if(a2 == 'd' && b2 == 'd' && a3 == 'd' && b3 == 'd'){
                int d = Integer.parseInt(a);
                int c = Integer.parseInt(b);
                int e = Integer.parseInt(board.inst[checkCircular(pc+c)].b); // final b
                if(board.inst[checkCircular(pc+c)].b3 == '-') {
                    e = -e;
                }
                int g = Integer.parseInt(board.inst[checkCircular(pc+d)].a); // final a
                if(board.inst[checkCircular(pc+d)].a3 == '-'){
                    g = -g;
                }

                if(board.inst[checkCircular(pc+c)].fullinst.equals(board.inst[checkCircular(pc+d)].fullinst)){
                    pc = checkCircular(pc+2);
                }

                else{
                    pc = checkCircular(pc+1);
                }
            }
            if(a2 == 'd' && b2 == '@' && a3 == 'd' && b3 == 'd'){
                int d = Integer.parseInt(a);
                int c = Integer.parseInt(b);
                int e = Integer.parseInt(board.inst[checkCircular(pc+c)].b);
                if(board.inst[checkCircular(pc+c)].b3 == '-') {
                    e = -e;
                }
                int i = Integer.parseInt(board.inst[checkCircular(pc+c+e)].b); // final b
                if(board.inst[checkCircular(pc+c+e)].b3 == '-') {
                    i = -i;
                }
                int g = Integer.parseInt(board.inst[checkCircular(pc+d)].a); // final a
                if(board.inst[checkCircular(pc+d)].a3 == '-'){
                    g = -g;
                }

                if(board.inst[checkCircular(pc+c+e)].fullinst.equals(board.inst[checkCircular(pc+d)].fullinst)){
                    pc = checkCircular(pc+2);
                }

                else{
                    pc = checkCircular(pc+1);
                }
            }

            // a3 = - and b3 = d
            if(a2 == '#' && b2 == 'd' && a3 == '-' && b3 == 'd'){
                int d = Integer.parseInt(a);
                if(board.inst[pc].a3 == '-'){
                    d = -d;
                }
                int c = Integer.parseInt(b);
                int e = Integer.parseInt(board.inst[checkCircular(pc+c)].b);
                if(board.inst[checkCircular(pc+c)].b3 == '-') {
                    e = -e;
                }
                if(d==e){
                    pc = checkCircular(pc+2);
                }
                else{
                    pc = checkCircular(pc+1);
                }
            }
            if(a2 == '#' && b2 == '@' && a3 == '-' && b3 == 'd'){
                int d = Integer.parseInt(a);
                if(board.inst[pc].a3 == '-'){
                    d = -d;
                }
                int c = Integer.parseInt(b);
                int e = Integer.parseInt(board.inst[checkCircular(pc+c)].b);
                if(board.inst[checkCircular(pc+c)].b3 == '-') {
                    e = -e;
                }
                int g = Integer.parseInt(board.inst[checkCircular(pc+c+e)].b);
                if(board.inst[checkCircular(pc+c+e)].b3 == '-'){
                    g = -g;
                }
                if(d==g){
                    pc = checkCircular(pc+2);
                }
                else{
                    pc = checkCircular(pc+1);
                }
            }
            if(a2 == '*' && b2 == 'd' && a3 == '-' && b3 == 'd'){
                int d = Integer.parseInt(a);
                if(board.inst[pc].a3 == '-'){
                    d = -d;
                }
                int c = Integer.parseInt(b);
                int e = Integer.parseInt(board.inst[checkCircular(pc+c)].b); // final b
                if(board.inst[checkCircular(pc+c)].b3 == '-') {
                    e = -e;
                }
                int g = Integer.parseInt(board.inst[checkCircular(pc+d)].a);
                if(board.inst[checkCircular(pc+d)].a3 == '-'){
                    g = -g;
                }
                int h = Integer.parseInt(board.inst[checkCircular(pc+d+g)].a); // final a
                if(board.inst[checkCircular(pc+d+g)].a3 == '-'){
                    h = -h;
                }

                if(board.inst[checkCircular(pc+d+g)].fullinst.equals(board.inst[checkCircular(pc+c)].fullinst)){
                    pc = checkCircular(pc+2);
                }

                else{
                    pc = checkCircular(pc+1);
                }
            }
            if(a2 == '*' && b2 == '@' && a3 == '-' && b3 == 'd'){
                int d = Integer.parseInt(a);
                if(board.inst[pc].a3 == '-'){
                    d = -d;
                }
                int c = Integer.parseInt(b);
                int e = Integer.parseInt(board.inst[checkCircular(pc+c)].b);
                if(board.inst[checkCircular(pc+c)].b3 == '-') {
                    e = -e;
                }
                int i = Integer.parseInt(board.inst[checkCircular(pc+c+e)].b); // final b
                if(board.inst[checkCircular(pc+c+e)].b3 == '-') {
                    i = -i;
                }
                int g = Integer.parseInt(board.inst[checkCircular(pc+d)].a);
                if(board.inst[checkCircular(pc+d)].a3 == '-'){
                    g = -g;
                }
                int h = Integer.parseInt(board.inst[checkCircular(pc+d+g)].a); // final a
                if(board.inst[checkCircular(pc+d+g)].a3 == '-'){
                    h = -h;
                }

                if(board.inst[checkCircular(pc+c+e)].fullinst.equals(board.inst[checkCircular(pc+d+g)].fullinst)){
                    pc = checkCircular(pc+2);
                }

                else{
                    pc = checkCircular(pc+1);
                }
            }
            if(a2 == 'd' && b2 == 'd' && a3 == '-' && b3 == 'd'){
                int d = Integer.parseInt(a);
                if(board.inst[pc].a3 == '-'){
                    d = -d;
                }
                int c = Integer.parseInt(b);
                int e = Integer.parseInt(board.inst[checkCircular(pc+c)].b); // final b
                if(board.inst[checkCircular(pc+c)].b3 == '-') {
                    e = -e;
                }
                int g = Integer.parseInt(board.inst[checkCircular(pc+d)].a); // final a
                if(board.inst[checkCircular(pc+d)].a3 == '-'){
                    g = -g;
                }

                if(board.inst[checkCircular(pc+c)].fullinst.equals(board.inst[checkCircular(pc+d)].fullinst)){
                    pc = checkCircular(pc+2);
                }

                else{
                    pc = checkCircular(pc+1);
                }
            }
            if(a2 == 'd' && b2 == '@' && a3 == '-' && b3 == 'd'){
                int d = Integer.parseInt(a);
                if(board.inst[pc].a3 == '-'){
                    d = -d;
                }
                int c = Integer.parseInt(b);
                int e = Integer.parseInt(board.inst[checkCircular(pc+c)].b);
                if(board.inst[checkCircular(pc+c)].b3 == '-') {
                    e = -e;
                }
                int i = Integer.parseInt(board.inst[checkCircular(pc+c+e)].b); // final b
                if(board.inst[checkCircular(pc+c+e)].b3 == '-') {
                    i = -i;
                }
                int g = Integer.parseInt(board.inst[checkCircular(pc+d)].a); // final a
                if(board.inst[checkCircular(pc+d)].a3 == '-'){
                    g = -g;
                }

                if(board.inst[checkCircular(pc+c+e)].fullinst.equals(board.inst[checkCircular(pc+d)].fullinst)){
                    pc = checkCircular(pc+2);
                }

                else{
                    pc = checkCircular(pc+1);
                }
            }

            // a3 = d and b3 = -
            if(a2 == '#' && b2 == 'd' && a3 == 'd' && b3 == '-'){
                int d = Integer.parseInt(a);
                int c = Integer.parseInt(b);
                if(board.inst[pc].b3 == '-'){
                    c = -c;
                }
                int e = Integer.parseInt(board.inst[checkCircular(pc+c)].b);
                if(board.inst[checkCircular(pc+c)].b3 == '-') {
                    e = -e;
                }
                if(d==e){
                    pc = checkCircular(pc+2);
                }
                else{
                    pc = checkCircular(pc+1);
                }
            }
            if(a2 == '#' && b2 == '@' && a3 == 'd' && b3 == '-'){
                int d = Integer.parseInt(a);
                int c = Integer.parseInt(b);
                if(board.inst[pc].b3 == '-'){
                    c = -c;
                }
                int e = Integer.parseInt(board.inst[checkCircular(pc+c)].b);
                if(board.inst[checkCircular(pc+c)].b3 == '-') {
                    e = -e;
                }
                int g = Integer.parseInt(board.inst[checkCircular(pc+c+e)].b);
                if(board.inst[checkCircular(pc+c+e)].b3 == '-'){
                    g = -g;
                }
                if(d==g){
                    pc = checkCircular(pc+2);
                }
                else{
                    pc = checkCircular(pc+1);
                }
            }
            if(a2 == '*' && b2 == 'd' && a3 == 'd' && b3 == '-'){
                int d = Integer.parseInt(a);
                int c = Integer.parseInt(b);
                if(board.inst[pc].b3 == '-'){
                    c = -c;
                }
                int e = Integer.parseInt(board.inst[checkCircular(pc+c)].b); // final b
                if(board.inst[checkCircular(pc+c)].b3 == '-') {
                    e = -e;
                }
                int g = Integer.parseInt(board.inst[checkCircular(pc+d)].a);
                if(board.inst[checkCircular(pc+d)].a3 == '-'){
                    g = -g;
                }
                int h = Integer.parseInt(board.inst[checkCircular(pc+d+g)].a); // final a
                if(board.inst[checkCircular(pc+d+g)].a3 == '-'){
                    h = -h;
                }

                if(board.inst[checkCircular(pc+d+g)].fullinst.equals(board.inst[checkCircular(pc+c)].fullinst)){
                    pc = checkCircular(pc+2);
                }

                else{
                    pc = checkCircular(pc+1);
                }
            }
            if(a2 == '*' && b2 == '@' && a3 == 'd' && b3 == '-'){
                int d = Integer.parseInt(a);
                int c = Integer.parseInt(b);
                if(board.inst[pc].b3 == '-'){
                    c = -c;
                }
                int e = Integer.parseInt(board.inst[checkCircular(pc+c)].b);
                if(board.inst[checkCircular(pc+c)].b3 == '-') {
                    e = -e;
                }
                int i = Integer.parseInt(board.inst[checkCircular(pc+c+e)].b); // final b
                if(board.inst[checkCircular(pc+c+e)].b3 == '-') {
                    i = -i;
                }
                int g = Integer.parseInt(board.inst[checkCircular(pc+d)].a);
                if(board.inst[pc+d].a3 == '-'){
                    g = -g;
                }
                int h = Integer.parseInt(board.inst[pc+d+g].a); // final a
                if(board.inst[checkCircular(pc+d+g)].a3 == '-'){
                    h = -h;
                }

                if(board.inst[checkCircular(pc+c+e)].fullinst.equals(board.inst[checkCircular(pc+d+g)].fullinst)){
                    pc = checkCircular(pc+2);
                }

                else{
                    pc = checkCircular(pc+1);
                }
            }
            if(a2 == 'd' && b2 == 'd' && a3 == 'd' && b3 == '-'){
                int d = Integer.parseInt(a);
                int c = Integer.parseInt(b);
                if(board.inst[pc].b3 == '-'){
                    c = -c;
                }
                int e = Integer.parseInt(board.inst[checkCircular(pc+c)].b); // final b
                if(board.inst[checkCircular(pc+c)].b3 == '-') {
                    e = -e;
                }
                int g = Integer.parseInt(board.inst[checkCircular(pc+d)].a); // final a
                if(board.inst[checkCircular(pc+d)].a3 == '-'){
                    g = -g;
                }

                if(board.inst[checkCircular(pc+c)].fullinst.equals(board.inst[checkCircular(pc+d)].fullinst)){
                    pc = checkCircular(pc+2);
                }

                else{
                    pc = checkCircular(pc+1);
                }
            }
            if(a2 == 'd' && b2 == '@' && a3 == 'd' && b3 == '-'){
                int d = Integer.parseInt(a);
                int c = Integer.parseInt(b);
                if(board.inst[pc].b3 == '-'){
                    c = -c;
                }
                int e = Integer.parseInt(board.inst[checkCircular(pc+c)].b);
                if(board.inst[checkCircular(pc+c)].b3 == '-') {
                    e = -e;
                }
                int i = Integer.parseInt(board.inst[checkCircular(pc+c+e)].b); // final b
                if(board.inst[checkCircular(pc+c+e)].b3 == '-') {
                    i = -i;
                }
                int g = Integer.parseInt(board.inst[checkCircular(pc+d)].a); // final a
                if(board.inst[checkCircular(pc+d)].a3 == '-'){
                    g = -g;
                }

                if(board.inst[checkCircular(pc+c+e)].fullinst.equals(board.inst[checkCircular(pc+d)].fullinst)){
                    pc = checkCircular(pc+2);
                }

                else{
                    pc = checkCircular(pc+1);
                }
            }

            // a3 = - and b3 = -
            if(a2 == '#' && b2 == 'd' && a3 == '-' && b3 == '-'){
                int d = Integer.parseInt(a);
                if(board.inst[pc].a3 == '-'){
                    d = -d;
                }
                int c = Integer.parseInt(b);
                if(board.inst[pc].b3 == '-'){
                    c = -c;
                }
                int e = Integer.parseInt(board.inst[checkCircular(pc+c)].b);
                if(board.inst[checkCircular(pc+c)].b3 == '-') {
                    e = -e;
                }
                if(d==e){
                    pc = checkCircular(pc+2);
                }
                else{
                    pc = checkCircular(pc+1);
                }
            }
            if(a2 == '#' && b2 == '@' && a3 == '-' && b3 == '-'){
                int d = Integer.parseInt(a);
                if(board.inst[pc].a3 == '-'){
                    d = -d;
                }
                int c = Integer.parseInt(b);
                if(board.inst[pc].b3 == '-'){
                    c = -c;
                }
                int e = Integer.parseInt(board.inst[checkCircular(pc+c)].b);
                if(board.inst[checkCircular(pc+c)].b3 == '-') {
                    e = -e;
                }
                int g = Integer.parseInt(board.inst[checkCircular(pc+c+e)].b);
                if(board.inst[checkCircular(pc+c+e)].b3 == '-'){
                    g = -g;
                }
                if(d==g){
                    pc = checkCircular(pc+2);
                }
                else{
                    pc = checkCircular(pc+1);
                }
            }
            if(a2 == '*' && b2 == 'd' && a3 == '-' && b3 == '-'){
                int d = Integer.parseInt(a);
                if(board.inst[pc].a3 == '-'){
                    d = -d;
                }
                int c = Integer.parseInt(b);
                if(board.inst[pc].b3 == '-'){
                    c = -c;
                }
                int e = Integer.parseInt(board.inst[checkCircular(pc+c)].b); // final b
                if(board.inst[checkCircular(pc+c)].b3 == '-') {
                    e = -e;
                }
                int g = Integer.parseInt(board.inst[checkCircular(pc+d)].a);
                if(board.inst[checkCircular(pc+d)].a3 == '-'){
                    g = -g;
                }
                int h = Integer.parseInt(board.inst[checkCircular(pc+d+g)].a); // final a
                if(board.inst[checkCircular(pc+d+g)].a3 == '-'){
                    h = -h;
                }

                if(board.inst[checkCircular(pc+d+g)].fullinst.equals(board.inst[checkCircular(pc+c)].fullinst)){
                    pc = checkCircular(pc+2);
                }

                else{
                    pc = checkCircular(pc+1);
                }
            }
            if(a2 == '*' && b2 == '@' && a3 == '-' && b3 == '-'){
                int d = Integer.parseInt(a);
                if(board.inst[pc].a3 == '-'){
                    d = -d;
                }
                int c = Integer.parseInt(b);
                if(board.inst[pc].b3 == '-'){
                    c = -c;
                }
                int e = Integer.parseInt(board.inst[checkCircular(pc+c)].b);
                if(board.inst[checkCircular(pc+c)].b3 == '-') {
                    e = -e;
                }
                int i = Integer.parseInt(board.inst[checkCircular(pc+c+e)].b); // final b
                if(board.inst[checkCircular(pc+c+e)].b3 == '-') {
                    i = -i;
                }
                int g = Integer.parseInt(board.inst[checkCircular(pc+d)].a);
                if(board.inst[checkCircular(pc+d)].a3 == '-'){
                    g = -g;
                }
                int h = Integer.parseInt(board.inst[checkCircular(pc+d+g)].a); // final a
                if(board.inst[checkCircular(pc+d+g)].a3 == '-'){
                    h = -h;
                }

                if(board.inst[checkCircular(pc+c+e)].fullinst.equals(board.inst[checkCircular(pc+d+g)].fullinst)){
                    pc = checkCircular(pc+2);
                }

                else{
                    pc = checkCircular(pc+1);
                }
            }
            if(a2 == 'd' && b2 == 'd' && a3 == '-' && b3 == '-'){
                int d = Integer.parseInt(a);
                if(board.inst[pc].a3 == '-'){
                    d = -d;
                }
                int c = Integer.parseInt(b);
                if(board.inst[pc].b3 == '-'){
                    c = -c;
                }
                int e = Integer.parseInt(board.inst[checkCircular(pc+c)].b); // final b
                if(board.inst[checkCircular(pc+c)].b3 == '-') {
                    e = -e;
                }
                int g = Integer.parseInt(board.inst[checkCircular(pc+d)].a); // final a
                if(board.inst[checkCircular(pc+d)].a3 == '-'){
                    g = -g;
                }

                if(board.inst[checkCircular(pc+c)].fullinst.equals(board.inst[checkCircular(pc+d)].fullinst)){
                    pc = checkCircular(pc+2);
                }

                else{
                    pc = checkCircular(pc+1);
                }
            }
            if(a2 == 'd' && b2 == '@' && a3 == '-' && b3 == '-'){
                int d = Integer.parseInt(a);
                if(board.inst[pc].a3 == '-'){
                    d = -d;
                }
                int c = Integer.parseInt(b);
                if(board.inst[pc].b3 == '-'){
                    c = -c;
                }
                int e = Integer.parseInt(board.inst[checkCircular(pc+c)].b);
                if(board.inst[checkCircular(pc+c)].b3 == '-') {
                    e = -e;
                }
                int i = Integer.parseInt(board.inst[checkCircular(pc+c+e)].b); // final b
                if(board.inst[checkCircular(pc+c+e)].b3 == '-') {
                    i = -i;
                }
                int g = Integer.parseInt(board.inst[checkCircular(pc+d)].a); // final a
                if(board.inst[checkCircular(pc+d)].a3 == '-'){
                    g = -g;
                }

                if(board.inst[checkCircular(pc+c+e)].fullinst.equals(board.inst[checkCircular(pc+d)].fullinst)){
                    pc = checkCircular(pc+2);
                }

                else{
                    pc = checkCircular(pc+1);
                }
            }

        }
        else {
            System.out.println("Error");
        }
        return pc;

    }



////////////////////////////////////////////////////////////////////////////////////////////////

    public int SPL(String fullinst, String inst, Board board, int pc, char a2, char a3, String a) {
        if((a2 == '*' || a2 == 'd') && (a3 == '-' || a3 == 'd')){

            // a3 = d
            if(a2 == '*' && a3 == 'd'){
                int c = Integer.parseInt(a);
                int d = Integer.parseInt(board.inst[checkCircular(pc + c)].a);
                if (board.inst[checkCircular(pc + c)].a3 == '-') {
                    d = -d;
                }
                pc = checkCircular(pc + d);
            }
            if(a2 == 'd' && a3 == 'd'){
                int c = Integer.parseInt(a);
                pc = checkCircular(pc + c);
            }

            // a3 = -
            if(a2 == '*' && a3 == '-'){
                int c = Integer.parseInt(a);
                if(a3 == '-'){
                    c = -c;
                }
                int d = Integer.parseInt(board.inst[checkCircular(pc + c)].a);
                if (board.inst[checkCircular(pc + c)].a3 == '-') {
                    d = -d;
                }
                pc = checkCircular(pc + d);

            }
            if(a2 == 'd' && a3 == '-'){
                int c = Integer.parseInt(a);
                if(a3 == '-'){
                    c = -c;
                }
                pc = checkCircular(pc + c);

            }

        }
        else {
            System.out.println("Error");
        }
        return pc;
    }


    public int checkCircular(int pc){
        while((pc > 7999) || (pc <0)) {
            if (pc > 7999) {
                pc = pc - 8000;
            }
            if (pc < 0) {
                pc = pc + 8000;
            }
        }
        return pc;
    }

    public String changeValues(String fullinst, String inst, Board board, int pc, char a2, char a3, String a, char b2, char b3, String b){
        board.inst[pc].a2 = a2;
        board.inst[pc].a3 = a3;
        board.inst[pc].a = a;
        board.inst[pc].b2 = b2;
        board.inst[pc].b3 = b3;
        board.inst[pc].b = b;
        board.inst[pc].inst = inst;

        if(board.inst[pc].inst.equals("JMP") || board.inst[pc].inst.equals("SPL")){
            //a3 == d b3 == d

            if(a2 == 'd' && b2 != 'd' && a3 == 'd' && b3 == 'd'){
                board.inst[pc].fullinst = "" + board.inst[pc].inst + ' ' + board.inst[pc].a;
            }
            if(b2 == 'd' && a2 != 'd' && a3 == 'd' && b3 == 'd'){
                board.inst[pc].fullinst = "" + board.inst[pc].inst + ' ' + board.inst[pc].a2 + board.inst[pc].a;
            }
            if(b2 == 'd' && a2 == 'd' && a3 == 'd' && b3 == 'd'){
                board.inst[pc].fullinst = "" + board.inst[pc].inst + ' ' + board.inst[pc].a;
            }
            if(b2 != 'd' && a2 != 'd' && a3 == 'd' && b3 == 'd'){
                board.inst[pc].fullinst = "" + board.inst[pc].inst + ' ' + board.inst[pc].a2 + board.inst[pc].a;
            }
            //a3 == d b3 !=d

            if(a2 == 'd' && b2 != 'd' && a3 == 'd' && b3 != 'd'){
                board.inst[pc].fullinst = "" + board.inst[pc].inst + ' ' + board.inst[pc].a;
            }
            if(b2 == 'd' && a2 != 'd' && a3 == 'd' && b3 != 'd'){
                board.inst[pc].fullinst = "" + board.inst[pc].inst + ' ' + board.inst[pc].a2 + board.inst[pc].a;
            }
            if(b2 == 'd' && a2 == 'd' && a3 == 'd' && b3 != 'd'){
                board.inst[pc].fullinst = "" + board.inst[pc].inst + ' ' + board.inst[pc].a;
            }
            if(b2 != 'd' && a2 != 'd' && a3 == 'd' && b3 != 'd'){
                board.inst[pc].fullinst = "" + board.inst[pc].inst + ' ' + board.inst[pc].a2 + board.inst[pc].a;
            }
            //a3 != d b3 == d

            if(a2 == 'd' && b2 != 'd' && a3 != 'd' && b3 == 'd'){
                board.inst[pc].fullinst = "" + board.inst[pc].inst + ' ' + board.inst[pc].a3 + board.inst[pc].a;
            }
            if(b2 == 'd' && a2 != 'd' && a3 != 'd' && b3 == 'd'){
                board.inst[pc].fullinst = "" + board.inst[pc].inst + ' ' + board.inst[pc].a2 + board.inst[pc].a3 + board.inst[pc].a;
            }
            if(b2 == 'd' && a2 == 'd' && a3 != 'd' && b3 == 'd'){
                board.inst[pc].fullinst = "" + board.inst[pc].inst + ' ' + board.inst[pc].a3 + board.inst[pc].a;
            }
            if(b2 != 'd' && a2 != 'd' && a3 != 'd' && b3 == 'd'){
                board.inst[pc].fullinst = "" + board.inst[pc].inst + ' ' + board.inst[pc].a2 + board.inst[pc].a3 + board.inst[pc].a;
            }
            //a3 != d b3 != d

            if(a2 == 'd' && b2 != 'd' && a3 != 'd' && b3 != 'd'){
                board.inst[pc].fullinst = "" + board.inst[pc].inst + ' ' + board.inst[pc].a3 + board.inst[pc].a;
            }
            if(b2 == 'd' && a2 != 'd' && a3 != 'd' && b3 != 'd'){
                board.inst[pc].fullinst = "" + board.inst[pc].inst + ' ' + board.inst[pc].a2 + board.inst[pc].a3 + board.inst[pc].a;
            }
            if(b2 == 'd' && a2 == 'd' && a3 != 'd' && b3 != 'd'){
                board.inst[pc].fullinst = "" + board.inst[pc].inst + ' ' + board.inst[pc].a3 + board.inst[pc].a;
            }
            if(b2 != 'd' && a2 != 'd' && a3 != 'd' && b3 != 'd'){
                board.inst[pc].fullinst = "" + board.inst[pc].inst + ' ' + board.inst[pc].a2 + board.inst[pc].a3 + board.inst[pc].a;
            }
        }else if(board.inst[pc].inst.equals("DAT")){
            //a3 == d b3 == d
            if(a2 == 'd' && b2 != 'd' && a3 == 'd' && b3 == 'd'){
                board.inst[pc].fullinst = "" + board.inst[pc].inst + ' ' + board.inst[pc].b2 + board.inst[pc].b;
            }
            if(b2 == 'd' && a2 != 'd' && a3 == 'd' && b3 == 'd'){
                board.inst[pc].fullinst = "" + board.inst[pc].inst + ' ' + board.inst[pc].b;
            }
            if(b2 == 'd' && a2 == 'd' && a3 == 'd' && b3 == 'd'){
                board.inst[pc].fullinst = "" + board.inst[pc].inst + ' ' + board.inst[pc].b;
            }
            if(b2 != 'd' && a2 != 'd' && a3 == 'd' && b3 == 'd'){
                board.inst[pc].fullinst = "" + board.inst[pc].inst + ' ' + board.inst[pc].b2 + board.inst[pc].b;
            }
            //a3 == d b3 !=d

            if(a2 == 'd' && b2 != 'd' && a3 == 'd' && b3 != 'd'){
                board.inst[pc].fullinst = "" + board.inst[pc].inst + ' ' + board.inst[pc].b2 + board.inst[pc].b3 + board.inst[pc].b;
            }
            if(b2 == 'd' && a2 != 'd' && a3 == 'd' && b3 != 'd'){
                board.inst[pc].fullinst = "" + board.inst[pc].inst + ' ' + board.inst[pc].b3 + board.inst[pc].b;
            }
            if(b2 == 'd' && a2 == 'd' && a3 == 'd' && b3 != 'd'){
                board.inst[pc].fullinst = "" + board.inst[pc].inst + ' ' + board.inst[pc].b3 + board.inst[pc].b;
            }
            if(b2 != 'd' && a2 != 'd' && a3 == 'd' && b3 != 'd'){
                board.inst[pc].fullinst = "" + board.inst[pc].inst + ' ' + board.inst[pc].b2 + board.inst[pc].b3 + board.inst[pc].b;
            }
            //a3 != d b3 == d

            if(a2 == 'd' && b2 != 'd' && a3 != 'd' && b3 == 'd'){
                board.inst[pc].fullinst = "" + board.inst[pc].inst + ' ' + board.inst[pc].b2 + board.inst[pc].b;
            }
            if(b2 == 'd' && a2 != 'd' && a3 != 'd' && b3 == 'd'){
                board.inst[pc].fullinst = "" + board.inst[pc].inst + ' ' + board.inst[pc].b;
            }
            if(b2 == 'd' && a2 == 'd' && a3 != 'd' && b3 == 'd'){
                board.inst[pc].fullinst = "" + board.inst[pc].inst + ' ' + board.inst[pc].b;
            }
            if(b2 != 'd' && a2 != 'd' && a3 != 'd' && b3 == 'd'){
                board.inst[pc].fullinst = "" + board.inst[pc].inst + ' ' + board.inst[pc].b2 + board.inst[pc].b;
            }
            //a3 != d b3 != d

            if(a2 == 'd' && b2 != 'd' && a3 != 'd' && b3 != 'd'){
                board.inst[pc].fullinst = "" + board.inst[pc].inst + ' ' + board.inst[pc].b2 + board.inst[pc].b3 + board.inst[pc].b;
            }
            if(b2 == 'd' && a2 != 'd' && a3 != 'd' && b3 != 'd'){
                board.inst[pc].fullinst = "" + board.inst[pc].inst + ' ' + board.inst[pc].b3 + board.inst[pc].b;
            }
            if(b2 == 'd' && a2 == 'd' && a3 != 'd' && b3 != 'd'){
                board.inst[pc].fullinst = "" + board.inst[pc].inst + ' ' + board.inst[pc].b3 + board.inst[pc].b;
            }
            if(b2 != 'd' && a2 != 'd' && a3 != 'd' && b3 != 'd'){
                board.inst[pc].fullinst = "" + board.inst[pc].inst + ' ' + board.inst[pc].b2 + board.inst[pc].b3 + board.inst[pc].b;
            }
        }else{



            //a3 == d b3 == d

            if(a2 == 'd' && b2 != 'd' && a3 == 'd' && b3 == 'd'){
                board.inst[pc].fullinst = "" + board.inst[pc].inst + ' ' + board.inst[pc].a + ',' + ' ' + board.inst[pc].b2 + board.inst[pc].b;
            }
            if(b2 == 'd' && a2 != 'd' && a3 == 'd' && b3 == 'd'){
                board.inst[pc].fullinst = "" + board.inst[pc].inst + ' ' + board.inst[pc].a2 + board.inst[pc].a + ',' + ' ' + board.inst[pc].b;
            }
            if(b2 == 'd' && a2 == 'd' && a3 == 'd' && b3 == 'd'){
                board.inst[pc].fullinst = "" + board.inst[pc].inst + ' ' + board.inst[pc].a + ',' + ' ' + board.inst[pc].b;
            }
            if(b2 != 'd' && a2 != 'd' && a3 == 'd' && b3 == 'd'){
                board.inst[pc].fullinst = "" + board.inst[pc].inst + ' ' + board.inst[pc].a2 + board.inst[pc].a + ',' + ' ' + board.inst[pc].b2 + board.inst[pc].b;
            }
            //a3 == d b3 !=d

            if(a2 == 'd' && b2 != 'd' && a3 == 'd' && b3 != 'd'){

                board.inst[pc].fullinst = "" + board.inst[pc].inst + ' ' + board.inst[pc].a + ',' + ' ' + board.inst[pc].b2 + board.inst[pc].b3 + board.inst[pc].b;
            }
            if(b2 == 'd' && a2 != 'd' && a3 == 'd' && b3 != 'd'){
                board.inst[pc].fullinst = "" + board.inst[pc].inst + ' ' + board.inst[pc].a2 + board.inst[pc].a + ',' + ' ' + board.inst[pc].b3 + board.inst[pc].b;
            }
            if(b2 == 'd' && a2 == 'd' && a3 == 'd' && b3 != 'd'){
                board.inst[pc].fullinst = "" + board.inst[pc].inst + ' ' + board.inst[pc].a + ',' + ' ' + board.inst[pc].b3 + board.inst[pc].b;
            }
            if(b2 != 'd' && a2 != 'd' && a3 == 'd' && b3 != 'd'){
                board.inst[pc].fullinst = "" + board.inst[pc].inst + ' ' + board.inst[pc].a2 + board.inst[pc].a + ',' + ' ' + board.inst[pc].b2 + board.inst[pc].b3 + board.inst[pc].b;
            }
            //a3 != d b3 == d

            if(a2 == 'd' && b2 != 'd' && a3 != 'd' && b3 == 'd'){
                board.inst[pc].fullinst = "" + board.inst[pc].inst + ' ' + board.inst[pc].a3 + board.inst[pc].a + ',' + ' ' + board.inst[pc].b2 + board.inst[pc].b;
            }
            if(b2 == 'd' && a2 != 'd' && a3 != 'd' && b3 == 'd'){
                board.inst[pc].fullinst = "" + board.inst[pc].inst + ' ' + board.inst[pc].a2 + board.inst[pc].a3 + board.inst[pc].a + ',' + ' ' + board.inst[pc].b;
            }
            if(b2 == 'd' && a2 == 'd' && a3 != 'd' && b3 == 'd'){
                board.inst[pc].fullinst = "" + board.inst[pc].inst + ' ' + board.inst[pc].a3 + board.inst[pc].a + ',' + ' ' + board.inst[pc].b;
            }
            if(b2 != 'd' && a2 != 'd' && a3 != 'd' && b3 == 'd'){
                board.inst[pc].fullinst = "" + board.inst[pc].inst + ' ' + board.inst[pc].a2 + board.inst[pc].a3 + board.inst[pc].a + ',' + ' ' + board.inst[pc].b2 + board.inst[pc].b;
            }
            //a3 != d b3 != d

            if(a2 == 'd' && b2 != 'd' && a3 != 'd' && b3 != 'd'){
                board.inst[pc].fullinst = "" + board.inst[pc].inst + ' ' + board.inst[pc].a3 + board.inst[pc].a + ',' + ' ' + board.inst[pc].b2 + board.inst[pc].b3 + board.inst[pc].b;
            }
            if(b2 == 'd' && a2 != 'd' && a3 != 'd' && b3 != 'd'){
                board.inst[pc].fullinst = "" + board.inst[pc].inst + ' ' + board.inst[pc].a2 + board.inst[pc].a3 + board.inst[pc].a + ',' + ' ' + board.inst[pc].b3 + board.inst[pc].b;
            }
            if(b2 == 'd' && a2 == 'd' && a3 != 'd' && b3 != 'd'){
                board.inst[pc].fullinst = "" + board.inst[pc].inst + ' ' + board.inst[pc].a3 + board.inst[pc].a + ',' + ' ' + board.inst[pc].b3 + board.inst[pc].b;
            }
            if(b2 != 'd' && a2 != 'd' && a3 != 'd' && b3 != 'd'){
                board.inst[pc].fullinst = "" + board.inst[pc].inst + ' ' + board.inst[pc].a2 + board.inst[pc].a3 + board.inst[pc].a + ',' + ' ' + board.inst[pc].b2 + board.inst[pc].b3 + board.inst[pc].b;
            }
        }
        return board.inst[pc].fullinst;
    }

}
