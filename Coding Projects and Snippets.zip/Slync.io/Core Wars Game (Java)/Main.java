package com.company;

import java.util.*;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;

public class Main {

    public static void main(String[] args)throws Exception {
	// write your code here


        File warriorOne = new File(args[0]);
        File warriorTwo = new File(args[1]);
        String [] arr1;
        String [] arr2;


            BufferedReader reader1 = new BufferedReader(new FileReader(warriorOne));
            String test1;
            List<String> lines1 = new ArrayList<String>();
            while((test1 = reader1.readLine())!=null){

                lines1.add(test1);
            }
            arr1 = lines1.toArray(new String[0]);
            reader1.close();


            BufferedReader reader2 = new BufferedReader(new FileReader(warriorTwo));
            String test2;
            List<String> lines2 = new ArrayList<String>();
            while((test2 = reader2.readLine())!=null){

                lines2.add(test2);
            }
            arr2 = lines2.toArray(new String[0]);
            reader2.close();



        Board board = new Board();
        board.inst = board.createBoard(board.inst);


        Instructions[] player1 = new Instructions[arr1.length];
        Instructions[] player2 = new Instructions[arr2.length];

        Random rand = new Random();
        int pointer1 = rand.nextInt(8000);
        int pointer2 = rand.nextInt(8000);



        for(int i = 0; i<player1.length; i++){
            player1[i] = new Instructions();
            String player_inst = arr1[i];
           //String player_inst = args[i];
            String[] parsedval = parseInput(player_inst);
            String instruction = parsedval[0];
            String operand1 = parsedval[1];
            String[] splitoperand1 = parseOperand(operand1);
            if(instruction.equals("JMP") || instruction.equals("SPL")){
                if (splitoperand1[0].charAt(0) == '-'){ // negative relative
                    for(int j= 1; j<splitoperand1.length; j++) {
                        if(j==1){
                            player1[i].a = "" + splitoperand1[j].charAt(0);
                        }else {
                            player1[i].a = player1[i].a + splitoperand1[j].charAt(0);
                        }

                    }
                    player1[i].a3 = splitoperand1[0].charAt(0);
                }else if (((splitoperand1[0].charAt(0) == '*')|| (splitoperand1[0].charAt(0) == '#'))&& splitoperand1[1].charAt(0) != '-'){ //positive and either immediate or indirect
                    for(int j= 1; j<splitoperand1.length; j++) {
                        if(j==1){
                            player1[i].a = "" + splitoperand1[j].charAt(0);
                        }else {
                            player1[i].a = player1[i].a + splitoperand1[j].charAt(0);
                        }
                    }
                    player1[i].a2 = splitoperand1[0].charAt(0);
                }else if(((splitoperand1[0].charAt(0) == '*')|| (splitoperand1[0].charAt(0) == '#')) && splitoperand1[1].charAt(0) == '-'){//negative and either immediate or indirect
                    for(int j= 2; j<splitoperand1.length; j++) {
                        if(j==2){
                            player1[i].a = "" + splitoperand1[j].charAt(0);
                        }else {
                            player1[i].a = player1[i].a + splitoperand1[j].charAt(0);
                        }
                    }
                    player1[i].a3 = splitoperand1[1].charAt(0);
                    player1[i].a2 = splitoperand1[0].charAt(0);
                }else{ //positive ralative
                    for(int j= 0; j<splitoperand1.length; j++) {
                        if(j==0){
                            player1[i].a = "" + splitoperand1[j].charAt(0);
                        }else {
                            player1[i].a = player1[i].a + splitoperand1[j].charAt(0);
                        }
                    }
                }
                player1[i].b = "0";
                player1[i].b2 = 'd';
                player1[i].b3 = 'd';
                player1[i].fullinst = player_inst;
                player1[i].inst = instruction;
                continue;
            }

            if(instruction.equals("DAT")) {
                    String operand2 = parsedval[1];  //b operand but only one value still
                    String[] splitoperand2 = parseOperand(operand2);

                    if (splitoperand2[0].charAt(0) == '-'){
                        for(int j= 1; j<splitoperand2.length; j++) {
                            if(j==1){
                                player1[i].b = "" + splitoperand2[j].charAt(0);
                            }else {
                                player1[i].b = player1[i].b + splitoperand2[j].charAt(0);
                            }
                        }
                        player1[i].b3 = splitoperand2[0].charAt(0);
                    }else if (((splitoperand2[0].charAt(0) == '@')|| (splitoperand2[0].charAt(0) == '#')) && splitoperand2[1].charAt(0) != '-'){
                        for(int j= 1; j<splitoperand2.length; j++) {
                            if(j==1){
                                player1[i].b = "" + splitoperand2[j].charAt(0);
                            }else {
                                player1[i].b = player1[i].b + splitoperand2[j].charAt(0);
                            }
                        }
                        player1[i].b2 = splitoperand2[0].charAt(0);
                    }else if(((splitoperand2[0].charAt(0) == '@')|| (splitoperand2[0].charAt(0) == '#')) && splitoperand2[1].charAt(0) == '-'){
                        for(int j= 2; j<splitoperand2.length; j++) {
                            if(j==2){
                                player1[i].b = "" + splitoperand2[j].charAt(0);
                            }else {
                                player1[i].b = player1[i].b + splitoperand2[j].charAt(0);
                            }
                        }
                        player1[i].b3 = splitoperand2[1].charAt(0);
                        player1[i].b2 = splitoperand2[0].charAt(0);
                    }else{
                        for(int j= 0; j<splitoperand2.length; j++) {
                            if(j==0){
                                player1[i].b = "" + splitoperand2[j].charAt(0);
                            }else {
                                player1[i].b = player1[i].b + splitoperand2[j].charAt(0);
                            }
                        }
                    }

                player1[i].a = "0";
                player1[i].a2 = 'd';
                player1[i].a3 = 'd';
                player1[i].fullinst = player_inst;
                player1[i].inst = instruction;
                continue;
            } else{
                String operand2 = parsedval[2];
                String[] splitoperand2 = parseOperand(operand2);

                if (splitoperand2[0].charAt(0) == '-') {
                    for (int j = 1; j < splitoperand2.length; j++) {
                        if (j == 1) {
                            player1[i].b = "" + splitoperand2[j].charAt(0);
                        } else {
                            player1[i].b = player1[i].b + splitoperand2[j].charAt(0);
                        }
                    }
                    player1[i].b3 = splitoperand2[0].charAt(0);
                } else if (((splitoperand2[0].charAt(0) == '@')|| (splitoperand2[0].charAt(0) == '#')) && splitoperand2[1].charAt(0) != '-' ) {
                    for (int j = 1; j < splitoperand2.length; j++) {
                        if (j == 1) {
                            player1[i].b = "" + splitoperand2[j].charAt(0);
                        } else {
                            player1[i].b = player1[i].b + splitoperand2[j].charAt(0);
                        }
                    }
                    player1[i].b2 = splitoperand2[0].charAt(0);
                } else if (((splitoperand2[0].charAt(0) == '@')|| (splitoperand2[0].charAt(0) == '#'))&& splitoperand2[1].charAt(0) == '-') {
                    for (int j = 2; j < splitoperand2.length; j++) {
                        if (j == 2) {
                            player1[i].b = "" + splitoperand2[j].charAt(0);
                        } else {
                            player1[i].b = player1[i].b + splitoperand2[j].charAt(0);
                        }
                    }
                    player1[i].b3 = splitoperand2[1].charAt(0);
                    player1[i].b2 = splitoperand2[0].charAt(0);
                } else {
                    for (int j = 0; j < splitoperand2.length; j++) {
                        if (j == 0) {
                            player1[i].b = "" + splitoperand2[j].charAt(0);
                        } else {
                            player1[i].b = player1[i].b + splitoperand2[j].charAt(0);
                        }
                    }
                }

                player1[i].fullinst = player_inst;
                player1[i].inst = instruction;

                if (splitoperand1[0].charAt(0) == '-') {
                    for (int j = 1; j < splitoperand1.length; j++) {
                        if (j == 1) {
                            player1[i].a = "" + splitoperand1[j].charAt(0);
                        } else {
                            player1[i].a = player1[i].a + splitoperand1[j].charAt(0);
                        }
                    }
                    player1[i].a3 = splitoperand1[0].charAt(0);
                } else if (((splitoperand1[0].charAt(0) == '*')|| (splitoperand1[0].charAt(0) == '#'))&& splitoperand1[1].charAt(0) != '-') {
                    for (int j = 1; j < splitoperand1.length; j++) {
                        if (j == 1) {
                            player1[i].a = "" + splitoperand1[j].charAt(0);
                        } else {
                            player1[i].a = player1[i].a + splitoperand1[j].charAt(0);
                        }
                    }
                    player1[i].a2 = splitoperand1[0].charAt(0);
                } else if (((splitoperand1[0].charAt(0) == '*')|| (splitoperand1[0].charAt(0) == '#'))&& splitoperand1[1].charAt(0) == '-') {
                    for (int j = 2; j < splitoperand1.length; j++) {
                        if (j == 2) {
                            player1[i].a = "" + splitoperand1[j].charAt(0);
                        } else {
                            player1[i].a = player1[i].a + splitoperand1[j].charAt(0);
                        }
                    }
                    player1[i].a3 = splitoperand1[1].charAt(0);
                    player1[i].a2 = splitoperand1[0].charAt(0);
                } else {
                    for (int j = 0; j < splitoperand1.length; j++) {
                        if (j == 0) {
                            player1[i].a = "" + splitoperand1[j].charAt(0);
                        } else {
                            player1[i].a = player1[i].a + splitoperand1[j].charAt(0);
                        }
                    }
                }
            }

        }


        for(int i=0; i<player1.length; i++){
            if(pointer1 > 7999){
                pointer1 = 0;
            }
            board.inst[pointer1].fullinst = player1[i].fullinst;
            board.inst[pointer1].inst = player1[i].inst;
            board.inst[pointer1].a2 = player1[i].a2;
            board.inst[pointer1].a3 = player1[i].a3;
            board.inst[pointer1].a = player1[i].a;
            board.inst[pointer1].b2 = player1[i].b2;
            board.inst[pointer1].b3 = player1[i].b3;
            board.inst[pointer1].b = player1[i].b;



            pointer1++; //in final iteration is the program counter right on the instruction after the first
            //System.out.println(pointer1);
        }
        int pc1 = pointer1-player1.length; // used to start program from top of player1 instructions set



        int testpc1 = pointer1-player1.length; //used for condition check in program printer

        for(int i = 0; i<player2.length; i++){
            player2[i] = new Instructions();
            String player_inst = arr2[i];
            //String player_inst = args[i];
            String[] parsedval = parseInput(player_inst);
            String instruction = parsedval[0];
            String operand1 = parsedval[1];
            String[] splitoperand1 = parseOperand(operand1);
            if(instruction.equals("JMP") || instruction.equals("SPL")){
                if (splitoperand1[0].charAt(0) == '-'){ // negative relative
                    for(int j= 1; j<splitoperand1.length; j++) {
                        if(j==1){
                            player2[i].a = "" + splitoperand1[j].charAt(0);
                        }else {
                            player2[i].a = player2[i].a + splitoperand1[j].charAt(0);
                        }

                    }
                    player2[i].a3 = splitoperand1[0].charAt(0);
                }else if (((splitoperand1[0].charAt(0) == '*')|| (splitoperand1[0].charAt(0) == '#')) && splitoperand1[1].charAt(0) != '-'){ //positive and either immediate or indirect
                    for(int j= 1; j<splitoperand1.length; j++) {
                        if(j==1){
                            player2[i].a = "" + splitoperand1[j].charAt(0);
                        }else {
                            player2[i].a = player2[i].a + splitoperand1[j].charAt(0);
                        }
                    }
                    player2[i].a2 = splitoperand1[0].charAt(0);
                }else if(((splitoperand1[0].charAt(0) == '*')|| (splitoperand1[0].charAt(0) == '#'))&& splitoperand1[1].charAt(0) == '-'){//negative and either immediate or indirect
                    for(int j= 2; j<splitoperand1.length; j++) {
                        if(j==2){
                            player2[i].a = "" + splitoperand1[j].charAt(0);
                        }else {
                            player2[i].a = player2[i].a + splitoperand1[j].charAt(0);
                        }
                    }
                    player2[i].a3 = splitoperand1[1].charAt(0);
                    player2[i].a2 = splitoperand1[0].charAt(0);
                }else{ //positive ralative
                    for(int j= 0; j<splitoperand1.length; j++) {
                        if(j==0){
                            player2[i].a = "" + splitoperand1[j].charAt(0);
                        }else {
                            player2[i].a = player2[i].a + splitoperand1[j].charAt(0);
                        }
                    }
                }
                player2[i].b = "0";
                player2[i].b2 = 'd';
                player2[i].b3 = 'd';
                player2[i].fullinst = player_inst;
                player2[i].inst = instruction;
                continue;
            }

            if(instruction.equals("DAT")) {
                String operand2 = parsedval[1];  //b operand but only one value still
                String[] splitoperand2 = parseOperand(operand2);

                if (splitoperand2[0].charAt(0) == '-'){
                    for(int j= 1; j<splitoperand2.length; j++) {
                        if(j==1){
                            player2[i].b = "" + splitoperand2[j].charAt(0);
                        }else {
                            player2[i].b = player2[i].b + splitoperand2[j].charAt(0);
                        }
                    }
                    player2[i].b3 = splitoperand2[0].charAt(0);
                }else if (((splitoperand2[0].charAt(0) == '@')|| (splitoperand2[0].charAt(0) == '#'))&& splitoperand2[1].charAt(0) != '-'){
                    for(int j= 1; j<splitoperand2.length; j++) {
                        if(j==1){
                            player2[i].b = "" + splitoperand2[j].charAt(0);
                        }else {
                            player2[i].b = player2[i].b + splitoperand2[j].charAt(0);
                        }
                    }
                    player2[i].b2 = splitoperand2[0].charAt(0);
                }else if(((splitoperand2[0].charAt(0) == '@')|| (splitoperand2[0].charAt(0) == '#'))&& splitoperand2[1].charAt(0) == '-'){
                    for(int j= 2; j<splitoperand2.length; j++) {
                        if(j==2){
                            player2[i].b = "" + splitoperand2[j].charAt(0);
                        }else {
                            player2[i].b = player2[i].b + splitoperand2[j].charAt(0);
                        }
                    }
                    player2[i].b3 = splitoperand2[1].charAt(0);
                    player2[i].b2 = splitoperand2[0].charAt(0);
                }else{
                    for(int j= 0; j<splitoperand2.length; j++) {
                        if(j==0){
                            player2[i].b = "" + splitoperand2[j].charAt(0);
                        }else {
                            player2[i].b = player2[i].b + splitoperand2[j].charAt(0);
                        }
                    }
                }

                player2[i].a = "0";
                player2[i].a2 = 'd';
                player2[i].a3 = 'd';
                player2[i].fullinst = player_inst;
                player2[i].inst = instruction;
                continue;
            } else{
                String operand2 = parsedval[2];
                String[] splitoperand2 = parseOperand(operand2);

                if (splitoperand2[0].charAt(0) == '-') {
                    for (int j = 1; j < splitoperand2.length; j++) {
                        if (j == 1) {
                            player2[i].b = "" + splitoperand2[j].charAt(0);
                        } else {
                            player2[i].b = player2[i].b + splitoperand2[j].charAt(0);
                        }
                    }
                    player2[i].b3 = splitoperand2[0].charAt(0);
                } else if (((splitoperand2[0].charAt(0) == '@')|| (splitoperand2[0].charAt(0) == '#'))&& splitoperand2[1].charAt(0) != '-') {
                    for (int j = 1; j < splitoperand2.length; j++) {
                        if (j == 1) {
                            player2[i].b = "" + splitoperand2[j].charAt(0);
                        } else {
                            player2[i].b = player2[i].b + splitoperand2[j].charAt(0);
                        }
                    }
                    player2[i].b2 = splitoperand2[0].charAt(0);
                } else if (((splitoperand2[0].charAt(0) == '@')|| (splitoperand2[0].charAt(0) == '#'))&& splitoperand2[1].charAt(0) == '-') {
                    for (int j = 2; j < splitoperand2.length; j++) {
                        if (j == 2) {
                            player2[i].b = "" + splitoperand2[j].charAt(0);
                        } else {
                            player2[i].b = player2[i].b + splitoperand2[j].charAt(0);
                        }
                    }
                    player2[i].b3 = splitoperand2[1].charAt(0);
                    player2[i].b2 = splitoperand2[0].charAt(0);
                } else {
                    for (int j = 0; j < splitoperand2.length; j++) {
                        if (j == 0) {
                            player2[i].b = "" + splitoperand2[j].charAt(0);
                        } else {
                            player2[i].b = player2[i].b + splitoperand2[j].charAt(0);
                        }
                    }
                }

                player2[i].fullinst = player_inst;
                player2[i].inst = instruction;

                if (splitoperand1[0].charAt(0) == '-') {
                    for (int j = 1; j < splitoperand1.length; j++) {
                        if (j == 1) {
                            player2[i].a = "" + splitoperand1[j].charAt(0);
                        } else {
                            player2[i].a = player2[i].a + splitoperand1[j].charAt(0);
                        }
                    }
                    player2[i].a3 = splitoperand1[0].charAt(0);
                } else if (((splitoperand1[0].charAt(0) == '*')|| (splitoperand1[0].charAt(0) == '#'))&& splitoperand1[1].charAt(0) != '-') {
                    for (int j = 1; j < splitoperand1.length; j++) {
                        if (j == 1) {
                            player2[i].a = "" + splitoperand1[j].charAt(0);
                        } else {
                            player2[i].a = player2[i].a + splitoperand1[j].charAt(0);
                        }
                    }
                    player2[i].a2 = splitoperand1[0].charAt(0);
                } else if (((splitoperand1[0].charAt(0) == '*')|| (splitoperand1[0].charAt(0) == '#'))&& splitoperand1[1].charAt(0) == '-') {
                    for (int j = 2; j < splitoperand1.length; j++) {
                        if (j == 2) {
                            player2[i].a = "" + splitoperand1[j].charAt(0);
                        } else {
                            player2[i].a = player2[i].a + splitoperand1[j].charAt(0);
                        }
                    }
                    player2[i].a3 = splitoperand1[1].charAt(0);
                    player2[i].a2 = splitoperand1[0].charAt(0);
                } else {
                    for (int j = 0; j < splitoperand1.length; j++) {
                        if (j == 0) {
                            player2[i].a = "" + splitoperand1[j].charAt(0);
                        } else {
                            player2[i].a = player2[i].a + splitoperand1[j].charAt(0);
                        }
                    }
                }
            }
        }


        for(int i=0; i<player1.length; i++){
            for(int j = 0; j<player2.length; j++){
                if((pointer1 + i) == (pointer2 + j)){
                    System.out.println("i is:" +i);
                    System.out.println("j is: " + j);
                    pointer2 = rand.nextInt(8000);
                    i = 0;
                    j = 0;
                    System.out.println("pc2 has changed");
                    break;
                }
            }
        }
        for(int i=0; i<player2.length; i++){
            if(pointer2 > 7999){
                pointer2 = 0;
            }
            board.inst[pointer2].fullinst = player2[i].fullinst;
            board.inst[pointer2].inst = player2[i].inst;
            board.inst[pointer2].a2 = player2[i].a2;
            board.inst[pointer2].a3 = player2[i].a3;
            board.inst[pointer2].a = player2[i].a;
            board.inst[pointer2].b2 = player2[i].b2;
            board.inst[pointer2].b3 = player2[i].b3;
            board.inst[pointer2].b = player2[i].b;




            pointer2++; //in final iteration is the program counter right on the instruction after the first
        }
        int pc2 = pointer2-player2.length; // used to start program from top of player1 instructions set









        int turncounter = 1;
        String gameresult= "";
        // The last line of the program output should say which program wins
        List<Integer> splitpc1 = new ArrayList<>();
        splitpc1.add(pc1);
        List<Integer> splitpc2 = new ArrayList<>();
        splitpc2.add(pc2);
        System.out.println("Turn 0");
        System.out.println();
        printPC(splitpc1.get(0), player2, board);
        System.out.println();
        printPC(splitpc2.get(0), player2, board);
        System.out.println();
        int x =0;
        int y =0;
        while(true){
            System.out.println("Turn " + turncounter);
            System.out.println();



                    if (splitpc1.get(x) > 7999) {
                        splitpc1.set(x, splitpc1.get(x) - 8000);
                    }
                    if (splitpc1.get(x) < 0) {
                        splitpc1.set(x, splitpc1.get(x) + 8000);
                    }
                    if(board.inst[splitpc1.get(x)].inst.equals("SPL")){

                        if(board.inst[board.inst[splitpc1.get(x)].chooseInstruction(board.inst[splitpc1.get(x)].fullinst, board.inst[splitpc1.get(x)].inst, board, splitpc1.get(x), board.inst[splitpc1.get(x)].a, board.inst[splitpc1.get(x)].b, board.inst[splitpc1.get(x)].a2, board.inst[splitpc1.get(x)].b2, board.inst[splitpc1.get(x)].a3, board.inst[splitpc1.get(x)].b3)].inst.equals("DAT")){
                            System.out.println("Player created on a dat thus not created");
                            System.out.println();
                            splitpc1.set(x, splitpc1.get(x) + 1);
                        }else {
                            splitpc1.add(board.inst[splitpc1.get(x)].chooseInstruction(board.inst[splitpc1.get(x)].fullinst, board.inst[splitpc1.get(x)].inst, board, splitpc1.get(x), board.inst[splitpc1.get(x)].a, board.inst[splitpc1.get(x)].b, board.inst[splitpc1.get(x)].a2, board.inst[splitpc1.get(x)].b2, board.inst[splitpc1.get(x)].a3, board.inst[splitpc1.get(x)].b3));
                            splitpc1.set(x, splitpc1.get(x) + 1);

                        }
                    }else{
                    splitpc1.set(x, board.inst[splitpc1.get(x)].chooseInstruction(board.inst[splitpc1.get(x)].fullinst, board.inst[splitpc1.get(x)].inst, board, splitpc1.get(x), board.inst[splitpc1.get(x)].a, board.inst[splitpc1.get(x)].b, board.inst[splitpc1.get(x)].a2, board.inst[splitpc1.get(x)].b2, board.inst[splitpc1.get(x)].a3, board.inst[splitpc1.get(x)].b3));
                    }
                    System.out.println("Player 1 version " + x + ":");
                    System.out.println();
                    printPC(splitpc1.get(x), player1, board);
                    System.out.println();

                    if(board.inst[splitpc1.get(x)].inst.equals("DAT")){
                        splitpc1.remove(x);
                        if(splitpc1.size() != 0){
                            System.out.println("Player1 version " + x + " has died but other versions still remain");
                            System.out.println();
                        }
                    }


                    if(splitpc1.isEmpty() == true){
                        splitpc2.set(y, board.inst[splitpc2.get(y)].chooseInstruction(board.inst[splitpc2.get(y)].fullinst, board.inst[splitpc2.get(y)].inst, board, splitpc2.get(y), board.inst[splitpc2.get(y)].a, board.inst[splitpc2.get(y)].b, board.inst[splitpc2.get(y)].a2, board.inst[splitpc2.get(y)].b2, board.inst[splitpc2.get(y)].a3, board.inst[splitpc2.get(y)].b3));
                        System.out.println("Player2 version " + y +":");
                        System.out.println();
                        printPC(splitpc2.get(y), player2, board);
                        System.out.println();
                        gameresult = "Player2 wins on turn " + turncounter;
                        break;
                    }

                    if(x < splitpc1.size()-1) {
                        x = x + 1;
                    }else {

                        x = 0;
                    }

                    if (splitpc2.get(y) > 7999) {
                        splitpc2.set(y, splitpc2.get(y) - 8000);
                    }
                    if (splitpc2.get(y) < 0) {
                        splitpc2.set(y, splitpc2.get(y) + 8000);
                    }

                    if(board.inst[splitpc2.get(y)].inst.equals("SPL")){

                        if(board.inst[board.inst[splitpc2.get(y)].chooseInstruction(board.inst[splitpc2.get(y)].fullinst, board.inst[splitpc2.get(y)].inst, board, splitpc2.get(y), board.inst[splitpc2.get(y)].a, board.inst[splitpc2.get(y)].b, board.inst[splitpc2.get(y)].a2, board.inst[splitpc2.get(y)].b2, board.inst[splitpc2.get(y)].a3, board.inst[splitpc2.get(y)].b3)].inst.equals("DAT")) {
                            System.out.println("Player created on a dat thus not created");
                            System.out.println();
                            splitpc2.set(y, splitpc2.get(y) + 1);
                        }else {
                            splitpc2.add(board.inst[splitpc2.get(y)].chooseInstruction(board.inst[splitpc2.get(y)].fullinst, board.inst[splitpc2.get(y)].inst, board, splitpc2.get(y), board.inst[splitpc2.get(y)].a, board.inst[splitpc2.get(y)].b, board.inst[splitpc2.get(y)].a2, board.inst[splitpc2.get(y)].b2, board.inst[splitpc2.get(y)].a3, board.inst[splitpc2.get(y)].b3));
                            splitpc2.set(y, splitpc2.get(y) + 1);
                        }
                    }else{
                        splitpc2.set(y, board.inst[splitpc2.get(y)].chooseInstruction(board.inst[splitpc2.get(y)].fullinst, board.inst[splitpc2.get(y)].inst, board, splitpc2.get(y), board.inst[splitpc2.get(y)].a, board.inst[splitpc2.get(y)].b, board.inst[splitpc2.get(y)].a2, board.inst[splitpc2.get(y)].b2, board.inst[splitpc2.get(y)].a3, board.inst[splitpc2.get(y)].b3));
                    }
                    System.out.println("Player 2 version " + y + ":");
                    System.out.println();
                    printPC(splitpc2.get(y), player2, board);
                    System.out.println();
                    if(board.inst[splitpc2.get(y)].inst.equals("DAT")){

                        splitpc2.remove(y);
                        if(splitpc2.size() != 0){
                            System.out.println("Player2 version " + y + " has died but other versions still remain");
                            System.out.println();
                        }
                    }

                    if(splitpc2.isEmpty() == true){
                        gameresult = "Player1 wins on turn " + turncounter;
                        break;
                    }


                    if(y < splitpc2.size()-1) {
                        y = y + 1;
                    }else {
                        y = 0;
                    }

            if(turncounter == 800000){
                //System.out.println("It is a draw");
                gameresult = "It is a draw";
                break;
            }
            turncounter = turncounter + 1;
        }



        System.out.println();
        System.out.println(gameresult);


    }



    public static void printPC(int testpc1, Instructions[] player, Board board){
        if(testpc1 < 0){
            testpc1 = testpc1 + 8000;
        }
        int testpcc1 = testpc1; // used for condition check in program printer
        for(int i= testpc1-5; i<testpc1+5+1; i++){
            if(i>7999){
                if (testpcc1<5){
                    testpc1 = (8000 - testpc1);
                }else{
                    testpc1 = -(8000 - testpc1);
                }
                i= 0;

            }
            if(i<0){
                testpc1 = (8000-testpc1);
                i = 8000+i;
            }
            System.out.println(board.inst[i].fullinst);

        }
    }

    public static String[] parseInput(String str){
        String[] parsedinput = str.split(" ");
        parsedinput[1] = parsedinput[1].replace(",","");
        return parsedinput;
    }

    public static String[] parseOperand(String operand){
        return operand.split("");

    }
}
