SigmaSummation (Assembly): Simple Implementation of the mathematical Sigma Function with RISC V assembly code.

Simple Frontend Form (Python, HTML, JS): Simple Frontend localhost run page collecting form data of two images and their descriptions specifed by the user and then displaying them on a new page allowing for the user to switch between the two images (and their respective data) at will.

ProcessorDesign (System Verilog): Developed processor for running RISC V assembly code reading in instruction sets as binary and routing results to appropriate memory locations.

Image Manipulation (C): Pixel by pixel manipulation of images allowing shifts, rotations, and flips as well as color filtering. Utilizes RGB color system.

Tetris Game (Java): A remake of the popular puzzle block game Tetris using Android studio for app design.

Core Wars Game (Java): A game pseudo-mimicking assembly language instruction sets to compete against one another to see which instruction set can last the longest before running into a "DAT" instruction. Multiple instruction sets can go head to head. Utilize link below for more details on the game. Game instruction set is displayed below: 

DAT	data		DJN	decrement and jump if not zero
MOV	move / copy	SPL	split
ADD	add		CMP	compare
SUB	subtract	
JMP	jump	
JMZ	jump if zero	
	 	  
Full Stack Internship Project Pictures (Java, SQL, TS, Angular, Node, Spring, HTML, CSS): These pictures show the functionality of the Employee Recognition and Awards web application allowing employees to nominate other employees for specific awards or send kind messages via "STAR" cards. There is a nominations management tab hidden from users without permissions for the award committess to handle the nominations and decide a winner.

