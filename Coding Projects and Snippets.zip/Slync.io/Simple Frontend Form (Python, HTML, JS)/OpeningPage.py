import cgi

print("Content-Type: text/html")
print()
print("<TITLE>CGI script output</TITLE>")
print("<html>")
print("<body bgcolor=grey>")
print("<H1>Please Upload Two Images</H1>")


FORM = cgi.FieldStorage()


print("<H2>Upload first image and relavant information<H2>")


      
print("<form action='/test/cgi-bin/test2.py' method='POST' >")
print("Image URL:")
print("<input type = 'text' name = 'img1' />")
print("<br>")
print("<br>")
print("Image Title:")
print("<input type = 'text' name = 'title1' />")
print("<br>")
print("<br>")
print("Year:")
print("<input type = 'text' name = 'year1'/>")
print("<br>")
print("<br>")
print("Artist:")
print("<input type = 'text' name = 'artist1'/>")
print("<br>")
print("<br>")
print("Description:")
print("<input type = 'text' name = 'desc1'/>")
print("<br>")
print("<br>")

print("<H4>Upload second image and relavant information<H4>")
print("Image URL:")
print("<input type = 'text' name = 'img2' />")
print("<br>")
print("<br>")
print("Image Title:")
print("<input type = 'text' name = 'title2' />")
print("<br>")
print("<br>")
print("Year:")
print("<input type = 'text' name = 'year2'/>")
print("<br>")
print("<br>")
print("Artist:")
print("<input type = 'text' name = 'artist2'/>")
print("<br>")
print("<br>")
print("Description:")
print("<input type = 'text' name = 'desc2'/>")
print("<br>")
print("<br>")

print("<input type='submit' name='button' value='Click' onclick='typedText(this.form)'/>")
print("</form>")
print("</body>")
print("</html>")


