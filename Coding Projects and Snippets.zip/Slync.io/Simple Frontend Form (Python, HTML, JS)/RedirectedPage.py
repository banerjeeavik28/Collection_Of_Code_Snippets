import cgi

print("Content-Type: text/html")
print()
print("<TITLE>CGI script output</TITLE>")
print("<H1>Here are the Images!</H1>")

FORM = cgi.FieldStorage()



img1 = FORM["img1"].value
title1 = FORM["title1"].value
artist1 = FORM["artist1"].value
year1 = FORM["year1"].value
desc1 = FORM["desc1"].value

img2 = FORM["img2"].value
title2 = FORM["title2"].value
artist2 = FORM["artist2"].value
year2 = FORM["year2"].value
desc2 = FORM["desc2"].value


print("<br>")
print ("<img src = {img} id = 'img'  height='300' width='300'> ".format(img=img1))
print ("<H2 id = 'title'> Title: {title} </H2> ".format(title=title1))
print ("<H2 id = 'year'> Year: {year} </H2>".format(year=year1))
print ("<H2 id = 'artist'> Artist: {artist} </H2> ".format(artist=artist1))
print ("<H2 id = 'desc'> Description: {desc} </H2>".format(desc=desc1))


print("<button onclick='Image1()'> Image1 </button>")
print("<button onclick='Image2()'> Image2 </button>")


print("""<script>
function Image1(){
    document.getElementById("img").src = "%s";
    document.getElementById("title").innerHTML = "Title: " + "%s";
    document.getElementById("artist").innerHTML = "Artist: " + "%s";
    document.getElementById("year").innerHTML = "Year: " + "%s";
    document.getElementById("desc").innerHTML = "Description: " + "%s";
}""" % (img1, title1, artist1, year1, desc1) )
print("""</script>""")
print("""<script>
function Image2(){
    document.getElementById("img").src = "%s";
    document.getElementById("title").innerHTML = "Title: " + "%s";
    document.getElementById("artist").innerHTML = "Artist: " + "%s";
    document.getElementById("year").innerHTML = "Year: " + "%s";
    document.getElementById("desc").innerHTML = "Description: " + "%s";
}""" % ( img2, title2, artist2, year2, desc2) )
print("""</script>""")
